#!/usr/bin/env bash
# Create (or repair) the Python virtual environment and start the FastAPI backend on :8000.
# Safe to re-run: a half-created or moved .venv is detected and rebuilt.
set -euo pipefail
cd "$(dirname "$0")/backend"
PY=${PYTHON:-python3}
VENV_PY=.venv/bin/python
IMPORTS="import fastapi, uvicorn, numpy, sklearn, yaml"

fail() { echo; echo "ERROR: $*" >&2; exit 1; }

command -v "$PY" >/dev/null || fail "'$PY' not found. Install Python 3.10+ or run: PYTHON=/path/to/python3 ./run_backend.sh"
"$PY" -c 'import sys; sys.exit(sys.version_info < (3, 10))' \
  || fail "Python 3.10+ is required, found $("$PY" --version 2>&1). Run: PYTHON=python3.11 ./run_backend.sh (or newer)"

make_venv() {
  rm -rf .venv
  echo "Creating virtual environment in backend/.venv ..."
  if ! "$PY" -m venv .venv; then
    rm -rf .venv
    PYV=$("$PY" -c 'import sys; print(f"{sys.version_info[0]}.{sys.version_info[1]}")')
    fail "Could not create the virtual environment.
On Debian/Ubuntu install the venv package first, then re-run this script:
    sudo apt install python3-venv python${PYV}-venv"
  fi
}

# A venv is healthy when its interpreter runs and has pip (a failed or moved venv often has neither).
if [ ! -x "$VENV_PY" ] || ! "$VENV_PY" -m pip --version >/dev/null 2>&1; then
  [ -d .venv ] && echo "backend/.venv is incomplete or broken; rebuilding it."
  make_venv
fi

# Install dependencies when they are missing or requirements.txt changed since the last install.
STAMP=.venv/.requirements.sha
WANT=$("$PY" -c 'import hashlib,sys; print(hashlib.sha256(open("requirements.txt","rb").read()).hexdigest())')
install_deps() {
  echo "Installing Python dependencies (first run takes a minute) ..."
  "$VENV_PY" -m pip install --upgrade pip >/dev/null || true
  "$VENV_PY" -m pip install -r requirements.txt \
    || fail "pip install failed (see the messages above). Check your internet/proxy access, then re-run this script."
}
if [ "$(cat "$STAMP" 2>/dev/null || true)" != "$WANT" ] || ! "$VENV_PY" -c "$IMPORTS" 2>/dev/null; then
  install_deps
  if ! "$VENV_PY" -c "$IMPORTS" 2>/dev/null; then
    echo "Installed packages still cannot be imported; rebuilding backend/.venv from scratch."
    make_venv
    install_deps
    "$VENV_PY" -c "$IMPORTS" || fail "Dependencies cannot be imported even in a fresh venv (see the error above)."
  fi
  echo "$WANT" > "$STAMP"
fi

echo "Starting backend on http://localhost:${PORT:-8000}"
exec "$VENV_PY" -m uvicorn app.main:app --host 0.0.0.0 --port "${PORT:-8000}"
