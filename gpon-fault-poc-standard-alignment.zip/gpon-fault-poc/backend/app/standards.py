"""Standards alignment of the ontology: OpenConfig, BBF TR-383/TR-385, ITU-T G.709 and RFC 8345.

The ontology keeps its own class names (scenarios, playbooks and policy key on them). This module
  * attaches a `std` block to every entity (standard identities, YANG paths and instance names),
  * derives the TR-385 xPON interface stack (channel-group/partition/pair/termination, v-ani/ani,
    v-enets, T-CONTs and GEM ports) and the G.709 OTN server layer of the core links,
  * checks the topology against the rules those standards impose (`validate`), and
  * exports standard JSON instance documents (RFC 7951 encoding): TR-385 config per OLT, OpenConfig
    config per IP/OTN/CES element, and an RFC 8345 multi-layer network topology.
"""
from __future__ import annotations

import re
from pathlib import Path

import yaml

CONFIG_DIR = Path(__file__).resolve().parent.parent / "config"
SERIAL_RE = re.compile(r"^[ -~]{4}[0-9a-fA-F]{8}$")  # bbf-xpon-types:onu-serial-number
PORT_RE = re.compile(r"(\d+/\d+/\d+)")
GPON_MAX_ONU_ID = 253          # G.984.3 / TR-385 v-ani onu-id range for G-PON
GPON_ALLOC_ID = (256, 4095)    # bbf-xpongemtcont alloc-id range for G-PON
GPON_MAX_REACH_KM = 20         # G.984.1 differential reach (maximum-differential-xpon-distance 20 | 40)

# T-CONT traffic descriptors (bits per second) per service family. CES needs fixed bandwidth (type 1 T-CONT).
TRAFFIC_PROFILES = {
    "TDP-CES-E1": {"fixed-bandwidth": "2304000", "maximum-bandwidth": "2304000", "additional-bw-eligibility-indicator": "none"},
    "TDP-MBH-4G": {"assured-bandwidth": "200000000", "maximum-bandwidth": "1000000000", "additional-bw-eligibility-indicator": "non-assured-sharing"},
    "TDP-ENT-L2VPN": {"assured-bandwidth": "50000000", "maximum-bandwidth": "500000000", "additional-bw-eligibility-indicator": "best-effort-sharing"},
}
SERVICE_PROFILE = {"MobileBackhaulService": ("TDP-CES-E1", 6), "EthernetBackhaulService": ("TDP-MBH-4G", 5),
                   "EnterpriseService": ("TDP-ENT-L2VPN", 2)}
JSON_MODULE = {"oc-opt-types:": "openconfig-transport-types:", "oc-platform-types:": "openconfig-platform-types:",
               "oc-ni-types:": "openconfig-network-instance-types:"}
LINK_IF_TYPE = {"CoreLink": "iana-if-type:ethernetCsmacd", "EthernetUplink": "iana-if-type:ieee8023adLag",
                "STM1Link": "iana-if-type:sonet", "E3Trunk": "iana-if-type:ds3", "E1Circuit": "iana-if-type:ds1"}


def load_standards() -> dict:
    with open(CONFIG_DIR / "standards.yaml", "r", encoding="utf-8") as fh:
        return yaml.safe_load(fh)


class Standards:
    def __init__(self, topo, spec: dict | None = None):
        self.topo = topo
        self.spec = spec or load_standards()
        self.E = topo.entities
        self._derive()

    # ----------------------------------------------------------------- derive
    def _of(self, cls: str) -> list[str]:
        return [k for k, e in self.E.items() if e["class"] == cls]

    def _derive(self) -> None:
        E = self.E
        fibres = self._of("FiberSegment")
        # PON ports: OLT and frame/slot/port from the port name
        self.pon: dict[str, dict] = {}
        for p in self._of("PONPort"):
            m = PORT_RE.search(E[p]["name"])
            self.pon[p] = {"olt": E[p]["depends_on"][0] if E[p]["depends_on"] else None,
                           "port": m.group(1) if m else p, "odn": p, "role": "unprotected"}
        # ODN trees: one per splitter; Type-B standby feeders join the working port's tree
        self.odn: dict[str, dict] = {}
        for s in self._of("Splitter"):
            feeders = [f for f in fibres if E[f].get("b") == s]
            prot = E[s].get("protection") or {}
            working = prot.get("working") or next((f for f in feeders if E[f].get("role") != "protection-standby"), None)
            standby = prot.get("standby")
            drops = [f for f in fibres if E[f].get("a") == s]
            onts = [E[d]["b"] for d in drops if E.get(E[d]["b"], {}).get("class") == "ONT"]
            feed = float(E[working].get("length_km", 0)) if working else 0.0
            dist = {E[d]["b"]: feed + float(E[d].get("length_km", 0)) for d in drops if E[E[d]["b"]]["class"] == "ONT"}
            self.odn[s] = {"splitter": s, "working_feeder": working, "standby_feeder": standby,
                           "working_port": E[working]["a"] if working else None,
                           "standby_port": E[standby]["a"] if standby else None,
                           "onts": onts, "distance_km": dist}
            for f, role in ((working, "type-b-primary" if standby else "working"), (standby, "type-b-secondary")):
                if f and E[f]["a"] in self.pon:
                    self.pon[E[f]["a"]].update(odn=s, role=role)
        # ONTs: onu-id per channel partition (1.. in topology order), services carried
        self.ont: dict[str, dict] = {}
        for s, o in self.odn.items():
            for i, ont in enumerate(o["onts"], start=1):
                self.ont[ont] = {"odn": s, "onu_id": i, "serial": E[ont]["meta"].get("serial"),
                                 "distance_km": round(o["distance_km"][ont], 2),
                                 "services": [k for k, e in E.items() if e["kind"] == "service" and self._service_ont(k) == ont],
                                 "e1": [k for k, e in E.items() if e["class"] == "E1Circuit" and e.get("a") == ont]}
        # T-CONT / GEM allocation (unique per channel termination; GPON alloc-id 256..4095)
        for ont, o in self.ont.items():
            base = 1024 + o["onu_id"] * 16
            o["tconts"] = []
            for k, svc in enumerate(o["services"]):
                prof, tc = SERVICE_PROFILE.get(E[svc]["class"], ("TDP-ENT-L2VPN", 0))
                o["tconts"].append({"service": svc, "alloc_id": base + k, "gemport_id": base + k,
                                    "profile": prof, "traffic_class": tc})

    def _service_ont(self, svc: str) -> str | None:
        anc = self.topo.ancestors(svc)
        onts = [(d, a) for a, d in anc.items() if self.E[a]["class"] == "ONT"]
        return min(onts)[1] if onts else None

    # ----------------------------------------------------------- names / std
    @staticmethod
    def if_names(pid: str, odn: str) -> dict:
        return {"cg": f"CG-{odn}", "cpart": f"CPart-{odn}", "cp": f"CP-{pid}", "ct": f"CT-{pid}"}

    def otn_stack(self, lid: str) -> dict | None:
        e = self.E[lid]
        o = e.get("otn")
        if not o:
            return None
        g = self.spec["g709"]
        return {**o, "client_rate_gbps": g["client_rate"].get(o["client"]), "opu_payload_gbps": g["opu_payload"].get(o["opu"]),
                "odu_rate_gbps": g["odu_rate"].get(o["odu"]), "otu_rate_gbps": g["otu_rate"].get(o["otu"]),
                "layers": [f'{o["client"]} (client)', f'{o["opu"]} ({o["mapping"]})', o["odu"], f'{o["otu"]} FEC {o.get("fec", "")}'.strip(), o.get("line", "OCh")],
                "oc_trib_protocol": g["oc_protocol"].get(o["client"]), "oc_odu_protocol": g["oc_protocol"].get(o["odu"]),
                "oc_otu_protocol": g["oc_protocol"].get(o["otu"]), "defects_on_failure": g["defects"]}

    def std_for(self, eid: str) -> dict:
        e = self.E[eid]
        cls = e["class"]
        m = self.spec["classes"].get(cls, {})
        out: dict = {}

        def fmt(s: str) -> str:
            return s.format(id=eid, a=e.get("a", ""), b=e.get("b", ""), olt=self.pon.get(eid, {}).get("olt", ""),
                            port=self.pon.get(eid, {}).get("port", ""), odn=self.pon.get(eid, {}).get("odn", ""))
        if "oc" in m:
            oc = {k: (fmt(v) if isinstance(v, str) else v) for k, v in m["oc"].items()}
            if cls in LINK_IF_TYPE:
                oc["if_type"] = LINK_IF_TYPE[cls].replace("iana-if-type:", "ianaift:")
            out["openconfig"] = oc
        if cls == "PONPort":
            p = self.pon[eid]
            n = self.if_names(eid, p["odn"])
            out["bbf_tr385"] = {"hardware": f'{p["olt"]}-tl-{p["port"]}', "channel_group": n["cg"], "channel_partition": n["cpart"],
                                "channel_pair": n["cp"], "channel_termination": n["ct"], "type_b_role": p["role"],
                                "channel_pair_type": "bbf-xpon-types:gpon"}
        elif cls == "ONT" and eid in self.ont:
            o = self.ont[eid]
            od = self.odn[o["odn"]]
            out["bbf_tr385"] = {"v_ani": f"vANI-{eid}", "ani": f"ANI-{eid}", "olt_v_enet": f"oltVENET-{eid}",
                                "onu_v_enet": f"onuVENET-{eid}", "onu_id": o["onu_id"], "expected_serial_number": o["serial"],
                                "channel_partition": f'CPart-{o["odn"]}',
                                "preferred_channel_pair": f'CP-{od["working_port"]}',
                                "protection_channel_pair": f'CP-{od["standby_port"]}' if od["standby_port"] else None,
                                "tconts": [{"name": f'TCONT-{eid}-{t["service"]}', "alloc_id": t["alloc_id"], "gemport_id": t["gemport_id"],
                                            "profile": t["profile"]} for t in o["tconts"]],
                                "distance_km": o["distance_km"]}
        elif cls == "Splitter" and eid in self.odn:
            od = self.odn[eid]
            dist = list(od["distance_km"].values()) or [0]
            out["bbf_tr385"] = {"channel_group": f"CG-{eid}", "channel_partition": f"CPart-{eid}",
                                "closest_onu_distance_km": int(min(dist)), "maximum_differential_xpon_distance_km": GPON_MAX_REACH_KM,
                                "measured_differential_km": round(max(dist) - min(dist), 2)}
        elif "bbf" in m:
            out["bbf"] = {k: (fmt(v) if isinstance(v, str) else v) for k, v in m["bbf"].items()}
        if "ietf" in m:
            out["ietf"] = {k: (fmt(v) if isinstance(v, str) else v) for k, v in m["ietf"].items()}
        otn = self.otn_stack(eid) if e["kind"] == "link" else None
        if otn:
            out["g709"] = otn
        elif "g709" in m:
            out["g709"] = {"note": m["g709"]}
        if "rfc8345" in m:
            out["rfc8345"] = m["rfc8345"]
        if "note" in m:
            out["note"] = m["note"]
        return out

    def annotate(self) -> None:
        for eid in self.E:
            self.E[eid]["std"] = self.std_for(eid)

    # --------------------------------------------------------------- validate
    def validate(self) -> list[dict]:
        """Rules from the standards that the topology must satisfy. level: error | warning | info."""
        E, out = self.E, []

        def add(level, rule, ent, msg):
            out.append({"level": level, "rule": rule, "entity": ent, "msg": msg})
        for k, e in E.items():
            if e["class"] not in self.spec["classes"]:
                add("error", "mapping", k, f'class {e["class"]} has no standards mapping')
            if e["kind"] == "link" and e["class"] != "Pseudowire":
                for end in ("a", "b"):
                    if e.get(end) not in E:
                        add("error", "rfc8345-link-endpoint", k, f"{end}-end {e.get(end)} is not a node")
        # TR-385 / G.984
        for ont, o in self.ont.items():
            if not o["serial"] or not SERIAL_RE.match(o["serial"]):
                add("error", "tr385-onu-serial-number", ont, f'serial {o["serial"]!r} does not match bbf-xpon-types:onu-serial-number')
            if not 0 <= o["onu_id"] <= GPON_MAX_ONU_ID:
                add("error", "tr385-onu-id", ont, f'onu-id {o["onu_id"]} outside 0..{GPON_MAX_ONU_ID} (G-PON)')
            if o["distance_km"] > GPON_MAX_REACH_KM:
                add("error", "g984-reach", ont, f'ONT at {o["distance_km"]} km exceeds {GPON_MAX_REACH_KM} km')
            for t in o["tconts"]:
                if not GPON_ALLOC_ID[0] <= t["alloc_id"] <= GPON_ALLOC_ID[1]:
                    add("error", "tr385-alloc-id", ont, f'alloc-id {t["alloc_id"]} outside {GPON_ALLOC_ID}')
        serials = [o["serial"] for o in self.ont.values()]
        for s in {x for x in serials if serials.count(x) > 1}:
            add("error", "tr385-onu-serial-unique", s, "duplicate expected-serial-number")
        for s, od in self.odn.items():
            d = list(od["distance_km"].values()) or [0]
            if max(d) - min(d) > GPON_MAX_REACH_KM:
                add("error", "tr385-differential-distance", s, "differential reach above 20 km")
            if od["standby_port"]:
                wo, so = self.pon[od["working_port"]]["olt"], self.pon[od["standby_port"]]["olt"]
                if wo == so and self.pon[od["working_port"]]["port"].split("/")[1] == self.pon[od["standby_port"]]["port"].split("/")[1]:
                    add("warning", "type-b-diversity", s, "Type-B working and standby ports share a line card")
                add("info", "type-b", s, f'Type-B: CT-{od["working_port"]} primary, CT-{od["standby_port"]} secondary in CPart-{s}')
        for p, v in self.pon.items():
            if v["odn"] == p:
                add("info", "tr385-spare-port", p, "no ODN attached: channel termination configured, no v-ani")
        # G.709
        for k, e in E.items():
            o = self.otn_stack(k) if e["kind"] == "link" else None
            if not o:
                continue
            if None in (o["client_rate_gbps"], o["opu_payload_gbps"]):
                add("error", "g709-stack", k, "unknown client or OPU in otn stack")
            elif o["client_rate_gbps"] > o["opu_payload_gbps"]:
                add("error", "g709-capacity", k, f'{o["client"]} {o["client_rate_gbps"]} Gb/s exceeds {o["opu"]} payload {o["opu_payload_gbps"]} Gb/s')
            if o["opu"][3:] != o["odu"][3:] or o["odu"][3:] != o["otu"][3:].rstrip("e"):
                add("error", "g709-stack", k, f'{o["opu"]}/{o["odu"]}/{o["otu"]} orders do not match')
            tti = o.get("tti") or {}
            if {tti.get("sapi"), tti.get("dapi")} != {e["a"], e["b"]}:
                add("error", "g709-tti", k, "TTI SAPI/DAPI do not name the link ends (would raise dTIM)")
        for lid in self._of("CoreLink"):
            if not E[lid].get("otn") and E[E[lid]["a"]]["meta"].get("site") != E[E[lid]["b"]]["meta"].get("site"):
                add("warning", "g709-server-layer", lid, "inter-site core link has no OTN server layer")
        # alarm catalogue
        cats = self.spec["alarm_categories"]
        for t, a in self.topo_catalog_alarms().items():
            if a.get("category") not in cats:
                add("warning", "x733", t, f'category {a.get("category")} has no X.733 event type')
        return out

    def topo_catalog_alarms(self) -> dict:
        with open(CONFIG_DIR / "alarm_catalog.yaml", "r", encoding="utf-8") as fh:
            return yaml.safe_load(fh)["alarms"]

    def alarm_std(self, atype: str, category: str, severity: str) -> dict:
        s = dict(self.spec["alarms"].get(atype, {}))
        s["x733_event_type"] = self.spec["alarm_categories"].get(category, {}).get("x733")
        sev = self.spec["severities"].get(severity, {})
        s["rfc8632_severity"], s["oc_severity"] = sev.get("rfc8632"), sev.get("oc")
        return s

    # ---------------------------------------------------------------- exports
    def bbf_xpon(self, olt: str) -> dict:
        """TR-385 (combined-NE mode) + TR-383 hardware configuration for one OLT, RFC 7951 JSON."""
        E = self.E
        ports = [p for p, v in self.pon.items() if v["olt"] == olt]
        hw = [{"name": olt, "class": "iana-hardware:chassis", "alias": E[olt]["name"]}]
        ifs, tconts, gems, links = [], [], [], []
        boards = sorted({self.pon[p]["port"].rsplit("/", 1)[0] for p in ports})
        for b in boards:
            hw.append({"name": f"{olt}-board-{b}", "class": "bbf-hardware-types:board", "parent": olt, "parent-rel-pos": int(b.split("/")[1])})
        seen_odn = set()
        for p in ports:
            v = self.pon[p]
            port, odn = v["port"], v["odn"]
            n = self.if_names(p, odn)
            board = f'{olt}-board-{port.rsplit("/", 1)[0]}'
            pos = int(port.rsplit("/", 1)[1])
            hw += [{"name": f"{olt}-cage-{port}", "class": "bbf-hardware-types:cage", "parent": board, "parent-rel-pos": pos},
                   {"name": f"{olt}-xcvr-{port}", "class": "bbf-hardware-types:transceiver", "parent": f"{olt}-cage-{port}", "parent-rel-pos": 1},
                   {"name": f"{olt}-tl-{port}", "class": "bbf-hardware-types-xpon:transceiver-link-gpon", "parent": f"{olt}-xcvr-{port}", "parent-rel-pos": 1}]
            if odn not in seen_odn:
                seen_odn.add(odn)
                dist = list(self.odn[odn]["distance_km"].values()) if odn in self.odn else [0]
                ifs += [{"name": n["cg"], "description": f"ODN {odn}", "type": "bbf-xpon-if-type:channel-group", "enabled": True,
                         "bbf-xpon:channel-group": {"polling-period": 100}},
                        {"name": n["cpart"], "description": f"ODN {odn}", "type": "bbf-xpon-if-type:channel-partition", "enabled": True,
                         "bbf-xpon:channel-partition": {"channel-group-ref": n["cg"], "channel-partition-index": 0,
                                                        "closest-onu-distance": int(min(dist) if dist else 0),
                                                        "maximum-differential-xpon-distance": GPON_MAX_REACH_KM,
                                                        "authentication-method": "serial-number"}}]
            ifs += [{"name": n["cp"], "description": E[p]["name"], "type": "bbf-xpon-if-type:channel-pair", "enabled": True,
                     "bbf-xpon:channel-pair": {"channel-group-ref": n["cg"], "channel-partition-ref": n["cpart"],
                                               "channel-pair-type": "bbf-xpon-types:gpon"}},
                    {"name": n["ct"], "description": E[p]["name"], "type": "bbf-xpon-if-type:channel-termination", "enabled": True,
                     "bbf-hardware:hardware-component": {"port-layer-if": [f"{olt}-tl-{port}"]},
                     "bbf-xpon:channel-termination": {"channel-pair-ref": n["cp"], "channel-termination-type": "bbf-xpon-types:gpon",
                                                      "meant-for-type-b-primary-role": v["role"] != "type-b-secondary",
                                                      "gpon-pon-id": f"{sum(map(ord, p)):014x}",
                                                      "location": "bbf-xpon-types:inside-olt"}}]
        for ont, o in self.ont.items():
            od = self.odn[o["odn"]]
            if self.pon.get(od["working_port"], {}).get("olt") != olt:
                continue
            vani = {"onu-id": o["onu_id"], "channel-partition": f'CPart-{o["odn"]}', "expected-serial-number": o["serial"],
                    "preferred-channel-pair": f'CP-{od["working_port"]}'}
            if od["standby_port"]:
                vani["protection-channel-pair"] = f'CP-{od["standby_port"]}'
            ifs += [{"name": f"vANI-{ont}", "description": E[ont]["name"], "type": "bbf-xpon-if-type:v-ani", "enabled": True, "bbf-xponvani:v-ani": vani},
                    {"name": f"ANI-{ont}", "description": E[ont]["name"], "type": "bbf-xpon-if-type:ani", "enabled": True,
                     "bbf-xponani:ani": {"upstream-fec": False, "onu-id": o["onu_id"]}},
                    {"name": f"oltVENET-{ont}", "type": "bbf-xpon-if-type:olt-v-enet", "enabled": True,
                     "bbf-xponvani:olt-v-enet": {"lower-layer-interface": f"vANI-{ont}"}},
                    {"name": f"onuVENET-{ont}", "type": "bbf-xpon-if-type:onu-v-enet", "enabled": True,
                     "bbf-xponani:onu-v-enet": {"ani": f"ANI-{ont}"}}]
            for e1 in o["e1"]:
                ifs.append({"name": f"{ont}:{e1}", "description": f'{E[e1]["name"] if "name" in E[e1] else e1} G.704 CRC-4 (OMCI PPTP CES UNI)',
                            "type": "iana-if-type:ds1", "enabled": True})
            links += [{"from-interface": f"vANI-{ont}", "to-interface": [f"ANI-{ont}"]},
                      {"from-interface": f"oltVENET-{ont}", "to-interface": [f"onuVENET-{ont}"]}]
            for t in o["tconts"]:
                tn = f'TCONT-{ont}-{t["service"]}'
                tconts.append({"name": tn, "alloc-id": t["alloc_id"], "interface-reference": f"vANI-{ont}", "traffic-descriptor-profile-ref": t["profile"]})
                gems.append({"name": f'GEM-{ont}-{t["service"]}', "gemport-id": t["gemport_id"], "interface": f"oltVENET-{ont}",
                             "traffic-class": t["traffic_class"], "tcont-ref": tn})
        tdps = [{"name": k, "priority": 1 if k == "TDP-CES-E1" else 3, "weight": 1,
                 **v} for k, v in TRAFFIC_PROFILES.items()]  # uint64 leaves are JSON strings (RFC 7951)
        return {"ietf-hardware:hardware": {"component": hw},
                "ietf-interfaces:interfaces": {"interface": ifs},
                "bbf-link-table:link-table": {"link-table": links},
                "bbf-xpongemtcont:xpongemtcont": {"traffic-descriptor-profiles": {"traffic-descriptor-profile": tdps},
                                                  "tconts": {"tcont": tconts}, "gemports": {"gemport": gems}}}

    @staticmethod
    def json_id(ident: str | None) -> str | None:
        """YANG prefix -> module name, as RFC 7951 requires for identityref values."""
        for p, m in JSON_MODULE.items():
            if ident and ident.startswith(p):
                return m + ident[len(p):]
        return ident

    def openconfig(self, dev: str) -> dict:
        """OpenConfig config for an IP/OTN/CES element: components, interfaces, OTN logical channels, CES pseudowires."""
        E = self.E
        links = [k for k, e in E.items() if e["kind"] == "link" and dev in (e.get("a"), e.get("b")) and e["class"] in LINK_IF_TYPE]
        comps = [{"name": dev, "config": {"name": dev}}]
        ifs, chans = [], []
        for i, lid in enumerate(links, start=1):
            e = E[lid]
            pname = f"{dev}-port-{i}"
            comps.append({"name": pname, "config": {"name": pname}})
            comps.append({"name": f"{pname}-xcvr", "config": {"name": f"{pname}-xcvr"}})
            ifs.append({"name": f"{dev}:{lid}", "config": {"name": f"{dev}:{lid}", "type": LINK_IF_TYPE[e["class"]],
                                                          "description": f'{e["class"]} {lid} to {e["b"] if e["a"] == dev else e["a"]} ({e.get("rate", "")})',
                                                          "enabled": True}})
            o = self.otn_stack(lid)
            if o:
                peer = e["b"] if e["a"] == dev else e["a"]
                base = 100 * i
                och = f"{pname}-och"
                comps.append({"name": och, "config": {"name": och}})
                chans += [
                    {"index": base + 1, "config": {"index": base + 1, "description": f'{lid} client {o["client"]}', "admin-state": "ENABLED",
                                                   "rate-class": self.json_id(self.spec["g709"]["oc_rate_class"][o["client"]]), "trib-protocol": self.json_id(o["oc_trib_protocol"]),
                                                   "logical-channel-type": "openconfig-transport-types:PROT_ETHERNET"},
                     "ingress": {"config": {"transceiver": f"{pname}-xcvr", "interface": f"{dev}:{lid}"}},
                     "logical-channel-assignments": {"assignment": [{"index": 1, "config": {"index": 1, "assignment-type": "LOGICAL_CHANNEL",
                                                                                            "logical-channel": base + 2, "allocation": "100", "mapping": "openconfig-transport-types:GMP"}}]}},
                    {"index": base + 2, "config": {"index": base + 2, "description": f'{lid} {o["odu"]}', "admin-state": "ENABLED",
                                                   "trib-protocol": self.json_id(o["oc_odu_protocol"]), "logical-channel-type": "openconfig-transport-types:PROT_OTN"},
                     "otn": {"config": {"tti-msg-transmit": f"{dev}>{peer}", "tti-msg-expected": f"{peer}>{dev}", "tti-msg-auto": False}},
                     "logical-channel-assignments": {"assignment": [{"index": 1, "config": {"index": 1, "assignment-type": "LOGICAL_CHANNEL",
                                                                                            "logical-channel": base + 3, "allocation": "100"}}]}},
                    {"index": base + 3, "config": {"index": base + 3, "description": f'{lid} {o["otu"]} FEC {o.get("fec", "")}', "admin-state": "ENABLED",
                                                   "trib-protocol": self.json_id(o["oc_otu_protocol"]), "logical-channel-type": "openconfig-transport-types:PROT_OTN"},
                     "otn": {"config": {"tti-msg-transmit": f"{dev}>{peer}", "tti-msg-expected": f"{peer}>{dev}", "tti-msg-auto": False}},
                     "logical-channel-assignments": {"assignment": [{"index": 1, "config": {"index": 1, "assignment-type": "OPTICAL_CHANNEL",
                                                                                            "optical-channel": och, "allocation": "100"}}]}}]
        doc = {"openconfig-platform:components": {"component": comps},
               "openconfig-interfaces:interfaces": {"interface": ifs}}
        if chans:
            doc["openconfig-terminal-device:terminal-device"] = {"logical-channels": {"channel": chans}}
        pws = [k for k, e in E.items() if e["class"] == "Pseudowire" and e.get("b") == dev]
        if pws:
            stm1 = next((f"{dev}:{k}" for k in links if E[k]["class"] == "STM1Link"), None)
            cps = []
            for pw in pws:
                e1 = E[pw]["a"]
                ont = E[e1]["a"]
                vc = int(re.sub(r"\D", "", pw) or 0)
                cps.append({"connection-point-id": pw, "config": {"connection-point-id": pw},
                            "endpoints": {"endpoint": [
                                {"endpoint-id": "local", "config": {"endpoint-id": "local", "precedence": 1, "type": "openconfig-network-instance-types:LOCAL"},
                                 "local": {"config": {"interface": stm1}}},
                                {"endpoint-id": "remote", "config": {"endpoint-id": "remote", "precedence": 1, "type": "openconfig-network-instance-types:REMOTE"},
                                 "remote": {"config": {"remote-system": f"10.255.{self.ont.get(ont, {}).get('onu_id', 0)}.{vc % 250}",
                                                       "virtual-circuit-identifier": vc}}}]}})
            doc["openconfig-network-instance:network-instances"] = {"network-instance": [
                {"name": f"CES-{dev}", "config": {"name": f"CES-{dev}", "type": "openconfig-network-instance-types:L2P2P",
                                                  "description": "CESoPSN (RFC 5086) E1 pseudowires to cell-site ONTs"},
                 "connection-points": {"connection-point": cps}}]}
        return doc

    def ietf_network(self) -> dict:
        """RFC 8345 multi-layer topology: physical -> otn -> ip-eth, physical -> xpon, {xpon, ip-eth, physical} -> tdm.

        Identifiers are inet:uri values; ietf-inet-types (RFC 9911) requires a scheme, so they are written urn:poc:<id>.
        """
        E = self.E

        def u(x: str) -> str:
            return f"urn:poc:{x}"
        devices = [k for k, e in E.items() if e["kind"] in ("device", "passive")]
        nets: dict[str, dict] = {n: {"network-id": u(n), "network-types": {}, "node": {}, "ietf-network-topology:link": []}
                                 for n in ("physical", "otn", "ip-eth", "xpon", "tdm")}
        sup = {"otn": ["physical"], "ip-eth": ["otn", "physical"], "xpon": ["physical"], "tdm": ["xpon", "ip-eth", "physical"]}
        for n, s in sup.items():
            nets[n]["supporting-network"] = [{"network-ref": u(x)} for x in s]

        def node(net, nid):
            nd = nets[net]["node"].setdefault(nid, {"node-id": u(nid), "ietf-network-topology:termination-point": []})
            if net != "physical" and "supporting-node" not in nd:
                nd["supporting-node"] = [{"network-ref": u("physical"), "node-ref": u(nid)}]
            return nd

        def tp(net, nid, tpid):
            tps = node(net, nid)["ietf-network-topology:termination-point"]
            if not any(t["tp-id"] == u(tpid) for t in tps):
                tps.append({"tp-id": u(tpid)})

        def link(net, lid, a, b, supporting=()):
            tp(net, a, lid)
            tp(net, b, lid)
            L = {"link-id": u(lid), "source": {"source-node": u(a), "source-tp": u(lid)},
                 "destination": {"dest-node": u(b), "dest-tp": u(lid)}}
            if supporting:
                L["supporting-link"] = [{"network-ref": u(n), "link-ref": u(r)} for n, r in supporting]
            nets[net]["ietf-network-topology:link"].append(L)
        for d in devices:
            node("physical", d)
        for k, e in E.items():
            if e["kind"] == "link" and e["class"] != "Pseudowire":
                link("physical", k, e["a"], e["b"])
        for k, e in E.items():
            o = self.otn_stack(k) if e["kind"] == "link" else None
            if o:
                link("otn", f'{o["odu"]}:{k}', e["a"], e["b"], [("physical", k)])
            if e["class"] in ("CoreLink", "EthernetUplink"):
                link("ip-eth", k, e["a"], e["b"], [("otn", f'{o["odu"]}:{k}')] if o else [("physical", k)])
        for ont, o in self.ont.items():
            od = self.odn[o["odn"]]
            olt = self.pon[od["working_port"]]["olt"]
            drop = next(k for k, e in E.items() if e["class"] == "FiberSegment" and e.get("b") == ont)
            sup_l = [("physical", od["working_feeder"]), ("physical", drop)]
            if od["standby_feeder"]:
                sup_l.append(("physical", od["standby_feeder"]))
            link("xpon", f"PON:{ont}", olt, ont, sup_l)
        for k, e in E.items():
            if e["class"] in ("E1Circuit", "STM1Link", "E3Trunk"):
                link("tdm", k, e["a"], e["b"], [("physical", k)])
        for k, e in E.items():
            if e["class"] != "Pseudowire":
                continue
            ont, gw = E[e["a"]]["a"], e["b"]
            ip_path = [p for p in self.topo.path_to_core(ont) if E[p]["class"] in ("EthernetUplink", "CoreLink")]
            ip_path += [p for p in self.topo.path_to_core(gw) if E[p]["class"] == "CoreLink"]
            sup_l = [("xpon", f"PON:{ont}")] + [("ip-eth", p) for p in dict.fromkeys(ip_path)]
            link("tdm", k, ont, gw, sup_l)
        for n in nets.values():
            n["node"] = list(n["node"].values())
        return {"ietf-network:networks": {"network": list(nets.values())}}

    def documents(self) -> dict[str, dict]:
        docs = {f"bbf-xpon_{o}.json": self.bbf_xpon(o) for o in self._of("OLT")}
        for d in ("CR-1", "CR-2", "AGG-1", "AGG-2", "CESGW-1"):
            if d in self.E:
                docs[f"openconfig_{d}.json"] = self.openconfig(d)
        docs["ietf-network_topology.json"] = self.ietf_network()
        return docs

    def summary(self) -> dict:
        findings = self.validate()
        return {"references": self.spec["references"], "classes": self.spec["classes"],
                "alarms": {t: self.alarm_std(t, a.get("category"), a.get("severity")) for t, a in self.topo_catalog_alarms().items()},
                "validation": {"errors": sum(f["level"] == "error" for f in findings),
                               "warnings": sum(f["level"] == "warning" for f in findings), "findings": findings},
                "documents": sorted(self.documents().keys())}
