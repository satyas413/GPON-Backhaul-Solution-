"""G.702 + GPON backhaul ontology and topology graph.

Every device, port, passive ODN element, link, pseudowire and service is a first-class entity.
`depends_on` edges point upstream (toward the core); impact analysis walks them in reverse.
"""
from __future__ import annotations

from collections import deque
from pathlib import Path
from typing import Iterable

import yaml

from .standards import Standards

CONFIG_DIR = Path(__file__).resolve().parent.parent / "config"

# Fixed drawing rows for the topology view (row index per class).
DRAW_ROW = {
    "CoreRouter": 0, "CESGateway": 0, "BSC": 0,
    "AggregationSwitch": 1, "G702Mux": 1,
    "OLT": 2, "PONPort": 3, "Splitter": 4, "ONT": 5, "BTS": 6,
}
NON_SHARED_RISK = {"OLT", "AggregationSwitch", "CoreRouter", "CESGateway", "BSC", "G702Mux", "CoreLink"}
DRAWABLE_LINKS = {"CoreLink", "EthernetUplink", "STM1Link", "E3Trunk", "FiberSegment", "E1Circuit"}


def load_yaml(name: str) -> dict:
    with open(CONFIG_DIR / name, "r", encoding="utf-8") as fh:
        return yaml.safe_load(fh)


class Topology:
    def __init__(self, spec: dict | None = None):
        spec = spec or load_yaml("topology.yaml")
        self.ontology = spec["ontology"]
        self.classes: dict = self.ontology["classes"]
        self.entities: dict[str, dict] = {}
        for group in ("devices", "links", "services"):
            for raw in spec.get(group, []):
                e = dict(raw)
                cls = self.classes[e["class"]]
                e.setdefault("depends_on", [])
                e.setdefault("meta", {})
                e["layer"] = cls["layer"]
                e["kind"] = cls["kind"]
                e["domain"] = cls["domain"]
                e["policy_class"] = cls["policy_class"]
                e["observable"] = cls.get("observable", True)
                e["group"] = group
                self.entities[e["id"]] = e
        self._rebuild()
        # OpenConfig / BBF TR-383, TR-385 / ITU-T G.709 / RFC 8345 identities for every entity
        self.standards = Standards(self)
        self.standards.annotate()

    # ------------------------------------------------------------------ graph
    def _rebuild(self) -> None:
        self.dependents: dict[str, list[str]] = {k: [] for k in self.entities}
        for eid, e in self.entities.items():
            for p in e["depends_on"]:
                self.dependents.setdefault(p, []).append(eid)
        self._anc_cache: dict[str, dict[str, int]] = {}
        self._desc_cache: dict[str, dict[str, int]] = {}

    def set_dependencies(self, eid: str, deps: list[str]) -> None:
        """Re-point an entity (used by protection switching)."""
        self.entities[eid]["depends_on"] = list(deps)
        self._rebuild()

    def cls(self, eid: str) -> str:
        return self.entities[eid]["class"]

    def ancestors(self, eid: str) -> dict[str, int]:
        """Upstream closure with hop distance."""
        if eid in self._anc_cache:
            return self._anc_cache[eid]
        dist: dict[str, int] = {}
        q = deque([(eid, 0)])
        while q:
            cur, d = q.popleft()
            for p in self.entities.get(cur, {}).get("depends_on", []):
                if p not in dist:
                    dist[p] = d + 1
                    q.append((p, d + 1))
        self._anc_cache[eid] = dist
        return dist

    def descendants(self, eid: str) -> dict[str, int]:
        """Downstream closure (everything that depends on eid) with hop distance."""
        if eid in self._desc_cache:
            return self._desc_cache[eid]
        dist: dict[str, int] = {}
        q = deque([(eid, 0)])
        while q:
            cur, d = q.popleft()
            for c in self.dependents.get(cur, []):
                if c not in dist:
                    dist[c] = d + 1
                    q.append((c, d + 1))
        self._desc_cache[eid] = dist
        return dist

    def is_ancestor(self, a: str, b: str) -> bool:
        return a in self.ancestors(b)

    def affinity(self, a: str, b: str) -> float:
        """Topological relatedness in [0,1] used by the correlator."""
        if a == b:
            return 1.0
        anc_b = self.ancestors(b)
        if a in anc_b:
            return 1.0 / (1.0 + 0.1 * anc_b[a])
        anc_a = self.ancestors(a)
        if b in anc_a:
            return 1.0 / (1.0 + 0.1 * anc_a[b])
        best = 0.0
        for c, da in anc_a.items():
            db = anc_b.get(c)
            if db is None:
                continue
            if self.entities[c]["class"] in NON_SHARED_RISK:
                continue  # siblings under a whole chassis or the core are not a shared-risk group
            best = max(best, 0.9 ** (da + db))
        return best

    def impacted(self, eid: str) -> dict:
        desc = self.descendants(eid)
        services = sorted(d for d in desc if self.entities[d]["kind"] == "service")
        devices = sorted(d for d in desc if self.entities[d]["kind"] in ("device", "port"))
        cell_sites = sorted(d for d in desc if self.entities[d]["class"] == "BTS")
        subs = sum(int(self.entities[s]["meta"].get("subscribers", 0)) for s in services)
        return {"services": services, "devices": devices, "cell_sites": cell_sites,
                "entities": sorted(desc), "subscribers": subs}

    def path_to_core(self, eid: str) -> list[str]:
        """Primary upstream path (first dependency each hop) for enrichment."""
        path, cur, seen = [], eid, set()
        while cur and cur not in seen:
            seen.add(cur)
            path.append(cur)
            deps = self.entities[cur]["depends_on"]
            cur = deps[0] if deps else None
        return path

    def nearest(self, eid: str, cls: str) -> str | None:
        anc = self.ancestors(eid)
        cands = [(d, a) for a, d in anc.items() if self.entities[a]["class"] == cls]
        return min(cands)[1] if cands else None

    def manager_of(self, eid: str) -> str:
        """Element manager that executes actions for an entity (management-plane path)."""
        e = self.entities[eid]
        if e["kind"] in ("device",) and e["class"] not in ("ONT", "BTS"):
            return eid
        if e["class"] == "Pseudowire":
            return "CESGW-1"
        if e["class"] in ("EthernetUplink", "CoreLink", "STM1Link", "E3Trunk"):
            return e["a"]  # the upstream end configures the link
        if e["class"] == "Splitter" or (e["class"] == "FiberSegment"):
            olt = self.nearest(eid, "OLT")
            return olt or eid
        olt = self.nearest(eid, "OLT")
        if olt:
            return olt
        mux = self.nearest(eid, "G702Mux")
        return mux or eid

    # ----------------------------------------------------------------- layout
    def layout(self) -> dict:
        """Hierarchical layout: fixed rows per class, leaf-ordered columns."""
        drawable = [k for k, e in self.entities.items() if e["class"] in DRAW_ROW]
        dset = set(drawable)

        def draw_parent(eid: str) -> str | None:
            q = deque(self.entities[eid]["depends_on"])
            seen = set()
            while q:
                p = q.popleft()
                if p in seen:
                    continue
                seen.add(p)
                if p in dset:
                    return p
                q.extend(self.entities[p]["depends_on"])
            return None

        parent = {d: draw_parent(d) for d in drawable}
        children: dict[str | None, list[str]] = {}
        for d in drawable:
            children.setdefault(parent[d], []).append(d)
        order = list(self.entities.keys())
        for k in children:
            children[k].sort(key=order.index)
        x: dict[str, float] = {}
        counter = [0]

        def place(n: str) -> float:
            kids = children.get(n, [])
            if not kids:
                x[n] = counter[0]
                counter[0] += 1
            else:
                xs = [place(c) for c in kids]
                x[n] = sum(xs) / len(xs)
            return x[n]

        for r in children.get(None, []):
            place(r)
        n_cols = max(counter[0], 1)
        W, H, top, rowh = 1500.0, 640.0, 40.0, 92.0
        # keep wide upper-row boxes from overlapping (e.g. CES gateway and the BSC it feeds)
        for row in (0, 1, 2):
            members = sorted((d for d in drawable if DRAW_ROW[self.entities[d]["class"]] == row), key=lambda d: x[d])
            for prev, cur in zip(members, members[1:]):
                if x[cur] - x[prev] < 1.3:
                    x[cur] = x[prev] + 1.3
        nodes = []
        for d in drawable:
            e = self.entities[d]
            nodes.append({"id": d, "class": e["class"], "name": e["name"], "layer": e["layer"],
                          "domain": e["domain"], "x": round(60 + x[d] * (W - 120) / max(n_cols - 1, 1), 1),
                          "y": top + DRAW_ROW[e["class"]] * rowh})
        edges = []
        for k, e in self.entities.items():
            if e["class"] in DRAWABLE_LINKS and e.get("a") in dset and e.get("b") in dset:
                edges.append({"id": k, "class": e["class"], "a": e["a"], "b": e["b"],
                              "subtype": e.get("subtype"), "role": e.get("role")})
        for d in drawable:
            if self.entities[d]["class"] == "PONPort":
                edges.append({"id": f"contain:{d}", "class": "Containment", "a": parent[d], "b": d})
        return {"width": W, "height": H, "nodes": nodes, "edges": edges}

    def describe(self) -> dict:
        return {
            "ontology": self.ontology,
            "entities": list(self.entities.values()),
            "layout": self.layout(),
        }


class AlarmCatalog:
    def __init__(self):
        spec = load_yaml("alarm_catalog.yaml")
        self.alarms: dict = spec["alarms"]
        self.rank: dict = spec["severity_rank"]

    def get(self, t: str) -> dict:
        return self.alarms.get(t, {"category": "performance", "severity": "minor", "domain": "unknown", "ref": t})

    def implicates(self, t: str, detail: dict | None = None) -> dict:
        entry = self.get(t)
        for rule in entry.get("when", []):
            if detail and all(str(detail.get(k)) == str(v) for k, v in rule["detail"].items()):
                return rule["implicates"]
        return entry.get("implicates", {})

    def sev_rank(self, s: str) -> int:
        return self.rank.get(s, 1)


def iter_ids(entities: Iterable[dict]) -> list[str]:
    return [e["id"] for e in entities]
