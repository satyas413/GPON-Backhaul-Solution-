"""FastAPI application: REST API for the dashboard, northbound ingestion endpoints and operator actions."""
from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import Body, FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .runtime import DRILLS, SCENARIOS, Runtime

rt: Runtime | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global rt
    rt = Runtime()
    await rt.start()
    yield
    await rt.stop()


app = FastAPI(title="GPON / G.702 Backhaul AI Fault Management PoC", version="1.0.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.get("/api/health")
async def health():
    sup = rt.supervisor.snapshot()
    return {"status": "ok" if sup["leader"] else "degraded", "correlation": sup["status"], "leader": sup["leader"],
            "ai": "up" if rt.ai.up else "down (safe mode)", "ingestion": rt.gateway.state}


@app.get("/api/topology")
async def topology():
    return rt.topo.describe()


@app.get("/api/standards")
async def standards():
    """Class-to-standard mapping, alarm identities, topology rule check and the list of exportable documents."""
    return rt.topo.standards.summary()


@app.get("/api/standards/bbf-xpon/{olt}")
async def standards_bbf_xpon(olt: str):
    """BBF TR-385 (combined-NE) + TR-383 hardware configuration of one OLT, RFC 7951 JSON."""
    if rt.topo.entities.get(olt, {}).get("class") != "OLT":
        raise HTTPException(404, "unknown OLT")
    return rt.topo.standards.bbf_xpon(olt)


@app.get("/api/standards/openconfig/{device}")
async def standards_openconfig(device: str):
    """OpenConfig components, interfaces, OTN logical channels (G.709) and CES pseudowires of one element."""
    if device not in rt.topo.entities or rt.topo.entities[device]["kind"] != "device":
        raise HTTPException(404, "unknown device")
    return rt.topo.standards.openconfig(device)


@app.get("/api/standards/ietf-network")
async def standards_ietf_network():
    """RFC 8345 multi-layer topology (physical, otn, ip-eth, xpon, tdm)."""
    return rt.topo.standards.ietf_network()


@app.get("/api/snapshot")
async def snapshot():
    return rt.snapshot()


@app.get("/api/incidents/{inc_id}")
async def incident(inc_id: str):
    st = rt.state()
    if not st or inc_id not in st["incidents"]:
        raise HTTPException(404, "incident not found")
    inc = st["incidents"][inc_id]
    return {**inc, "alarm_records": [st["alarms"][a] for a in inc["alarms"] if a in st["alarms"]]}


@app.post("/api/incidents/{inc_id}/{op}")
async def incident_op(inc_id: str, op: str, body: dict = Body(default={})):
    try:
        res = rt.loop.operator(inc_id, op, (body or {}).get("note", ""))
    except KeyError:
        raise HTTPException(404, "incident not found")
    except (ValueError, RuntimeError) as exc:
        raise HTTPException(409, str(exc))
    return {"ok": True, "result": res}


@app.get("/api/policy")
async def policy():
    return rt.loop.policy.spec


@app.put("/api/policy/matrix")
async def set_matrix(body: dict = Body(...)):
    try:
        rt.loop.policy.set_level(body["device_class"], body["category"], body["level"])
    except (KeyError, ValueError) as exc:
        raise HTTPException(400, str(exc))
    rt.log_event("policy", f'Autonomy {body["device_class"]} x {body["category"]} set to {body["level"]}')
    return rt.loop.policy.spec


@app.put("/api/policy/guardrails")
async def set_guardrail(body: dict = Body(...)):
    try:
        rt.loop.policy.set_guardrail(body["key"], body["value"])
    except (KeyError, ValueError) as exc:
        raise HTTPException(400, str(exc))
    rt.log_event("policy", f'Guardrail {body["key"]} set to {body["value"]}')
    return rt.loop.policy.spec


@app.post("/api/policy/reset")
async def reset_policy():
    rt.loop.policy.reset()
    rt.log_event("policy", "Autonomy policy reset to defaults")
    return rt.loop.policy.spec


@app.get("/api/scenarios")
async def scenarios():
    return {"scenarios": SCENARIOS, "drills": DRILLS}


@app.post("/api/scenarios/{name}")
async def run_scenario(name: str):
    if name == "guided_demo":
        asyncio.get_event_loop().create_task(rt.guided_demo())
        return {"ok": True}
    try:
        return rt.run_scenario(name)
    except KeyError:
        raise HTTPException(404, f"unknown scenario {name}")


@app.post("/api/drills/{name}")
async def drill(name: str):
    try:
        return rt.drill(name)
    except KeyError:
        raise HTTPException(404, f"unknown drill {name}")


@app.post("/api/reset")
async def reset(body: dict = Body(default={})):
    rt.reset(bool((body or {}).get("full")))
    return {"ok": True}


@app.post("/api/noise/{state}")
async def noise(state: str):
    rt.noise = state == "on"
    return {"noise": rt.noise}


@app.get("/api/history/trends")
async def trends():
    return {"daily": rt.history.daily_trends()}


@app.post("/api/ingest/{source}")
async def ingest(source: str, request: Request):
    """Northbound ingestion for external collectors: snmp | syslog | stream | telemetry.

    Returns 202 when accepted, 429 + Retry-After under backpressure, 400 for malformed input (dead-lettered).
    """
    if source == "syslog" and "json" not in request.headers.get("content-type", ""):
        raw = (await request.body()).decode("utf-8", errors="replace")
    else:
        raw = await request.json()
        if source == "syslog" and isinstance(raw, dict):
            raw = raw.get("line", "")
    res = rt.gateway.submit(source, raw)
    if res["status"] == "accepted":
        return JSONResponse(res, status_code=202)
    if res["status"] == "rejected":
        return JSONResponse(res, status_code=429, headers={"Retry-After": str(max(1, int(res.get("retry_after", 1))))})
    return JSONResponse(res, status_code=400)


DIST = Path(__file__).resolve().parents[2] / "frontend" / "dist"
if DIST.exists():
    app.mount("/assets", StaticFiles(directory=DIST / "assets"), name="assets")

    @app.get("/")
    async def index():
        return FileResponse(DIST / "index.html")
