"""Check the topology against the standards it is aligned with, and export standard instance documents.

1. Topology rules (always): TR-385 ONU serial/onu-id/alloc-id ranges, G.984 reach, Type-B grouping,
   G.709 client/OPU capacity and TTI, X.733 mapping of the alarm catalogue (app/standards.py).
2. Writes the generated documents (TR-385 per OLT, OpenConfig per element, RFC 8345 topology) to --out.
3. Schema check (with --yang-root and pyang installed): every node of every document must exist in the
   published YANG (including augments), list keys and mandatory leaves must be present, values must match
   their types (ranges, patterns, enums, identityref bases, RFC 7951 number/string encoding), 'when'
   conditions on interface types must hold, and absolute leafrefs must point at existing instances.

Usage:
  python scripts/validate_standards.py [--out ../docs/standards-samples] [--yang-root DIR]
DIR holds the clones:  DIR/bbf-yang  (github.com/BroadbandForum/yang)
                       DIR/openconfig (github.com/openconfig/public)
                       DIR/yang       (github.com/YangModels/yang, needs standard/ietf/RFC and standard/iana)
Exit code 0 when there are no errors.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app.ontology import Topology  # noqa: E402
from app.standards import Standards  # noqa: E402

DOC_MODULES = {
    "bbf-xpon": ["ietf-interfaces", "ietf-hardware", "iana-if-type", "iana-hardware", "bbf-hardware", "bbf-hardware-types",
                 "bbf-hardware-types-xpon", "bbf-xpon", "bbf-xpon-if-type", "bbf-xpon-types", "bbf-xponvani", "bbf-xponani",
                 "bbf-xpongemtcont", "bbf-link-table"],
    "openconfig": ["openconfig-platform", "openconfig-platform-transceiver", "openconfig-interfaces", "openconfig-terminal-device",
                   "openconfig-transport-types", "openconfig-network-instance", "openconfig-network-instance-types", "iana-if-type"],
    "ietf-network": ["ietf-network", "ietf-network-topology"],
}


def yang_dirs(root: Path, family: str) -> list[str]:
    def walk(p: Path):
        return [str(d) for d in [p, *p.rglob("*")] if d.is_dir() and any(d.glob("*.yang"))] if p.exists() else []
    ietf = [str(root / "yang/standard/ietf/RFC"), str(root / "yang/standard/iana")]
    if family == "bbf-xpon":
        return walk(root / "bbf-yang/standard") + ietf
    if family == "openconfig":
        return walk(root / "openconfig/release/models") + walk(root / "openconfig/third_party") + ietf
    return ietf


class SchemaChecker:
    """Validates an RFC 7951 JSON config document against YANG modules compiled with pyang."""

    def __init__(self, dirs: list[str], modules: list[str]):
        from pyang import context, repository
        self.ctx = context.Context(repository.FileRepository(":".join(dirs), use_env=False))
        self.mods = {}
        for m in modules:
            mod = self.ctx.search_module(None, m)
            if mod is None:
                raise RuntimeError(f"YANG module {m} not found under {dirs[:2]}...")
            self.mods[m] = mod
        self.ctx.validate()
        self.errors: list[str] = []
        self.features: set[str] = set()
        self.checked = 0
        self.when_stats = {True: 0, False: 0}  # evaluated / not evaluable by this checker
        self.doc: dict = {}

    # -- helpers
    def module(self, name):
        return self.ctx.get_module(name) or self.mods.get(name)

    def identity(self, value: str, default_mod: str):
        mod, _, name = value.rpartition(":")
        m = self.module(mod or default_mod)
        return m.i_identities.get(name) if m is not None else None

    @staticmethod
    def derived(ident, base, self_ok=True) -> bool:
        if self_ok and ident is base:
            return True
        return any(b.i_identity is not None and SchemaChecker.derived(b.i_identity, base) for b in ident.search("base"))

    @staticmethod
    def base_type(t):
        while getattr(t, "i_typedef", None) is not None:
            t = t.i_typedef.search_one("type")
        return t

    def find_child(self, stmt, name, modname):
        for ch in getattr(stmt, "i_children", []):
            if ch.keyword in ("choice", "case"):
                r = self.find_child(ch, name, modname)
                if r is not None:
                    return r
            elif ch.arg == name and ch.i_module.i_modulename == modname:
                return ch
        return None

    def whens(self, node):
        """(expression, context) pairs: own 'when' evaluates on the node, augment/uses 'when' on the parent."""
        out = []
        w = node.search_one("when")
        if w is not None:
            out.append((w.arg, "self", node))
        for owner in [getattr(node, "i_augment", None), *(getattr(node, "i_uses", None) or [])]:
            w = owner.search_one("when") if owner is not None else None
            if w is not None:
                out.append((w.arg, "parent", owner))
        p = node.parent
        while p is not None and p.keyword in ("case", "choice"):
            w = p.search_one("when")
            if w is not None:
                out.append((w.arg, "parent", p))
            p = p.parent
        return out

    def eval_when(self, expr, where, stmt, parent_inst) -> bool | None:
        expr = " ".join(expr.split())
        terms = [t.strip() for t in re.split(r"\s+or\s+", expr)]
        res = []
        for t in terms:
            m = re.fullmatch(r"(derived-from-or-self|derived-from)\(\s*([^,]+?)\s*,\s*'([^']+)'\s*\)", t) or \
                re.fullmatch(r"()([^=\s]+)\s*=\s*'([^']+)'", t)
            if not m:
                return None
            fn, path, ident = m.groups()
            segs = [s.split(":")[-1] for s in path.split("/") if s]
            if where == "self":
                if not segs or segs[0] != "..":
                    return None
                segs = segs[1:]
            if any(s == ".." for s in segs) or len(segs) != 1:
                return None
            val = parent_inst.get(segs[0]) if isinstance(parent_inst, dict) else None
            if val is None:
                res.append(False)
                continue
            pfx, _, nm = ident.rpartition(":")
            mod = getattr(stmt, "i_orig_module", None) or stmt.i_module
            target_mod = mod.i_prefixes.get(pfx, (stmt.i_module.i_modulename,))[0] if pfx else stmt.i_module.i_modulename
            base = self.identity(f"{target_mod}:{nm}", target_mod)
            have = self.identity(val, target_mod)
            if base is None or have is None:
                return None
            res.append(self.derived(have, base, self_ok=fn != "derived-from"))
        return any(res)

    # -- type checks
    def check_value(self, leaf, value, path):
        self.checked += 1
        t = leaf.search_one("type")
        self.check_typed(t, value, path, leaf)

    def check_typed(self, t, value, path, leaf) -> bool:
        from pyang import types as pt
        ts = t.i_type_spec
        bt = self.base_type(t).arg
        if isinstance(ts, pt.UnionTypeSpec) or bt == "union":
            saved = list(self.errors)
            for sub in self.base_type(t).search("type"):
                self.errors = []
                if self.check_typed(sub, value, path, leaf) and not self.errors:
                    self.errors = saved
                    return True
            self.errors = saved + [f"{path}: {value!r} matches no member of the union"]
            return False
        if bt == "identityref":
            if not isinstance(value, str):
                self.errors.append(f"{path}: identityref must be a JSON string")
                return False
            ident = self.identity(value, leaf.i_module.i_modulename)
            if ident is None:
                self.errors.append(f"{path}: unknown identity {value}")
                return False
            bases = [b.i_identity for b in self.base_type(t).search("base")]
            if not all(self.derived(ident, b) for b in bases if b is not None):
                self.errors.append(f"{path}: {value} is not derived from {[b.arg for b in bases]}")
                return False
            return True
        if bt == "leafref":
            p = self.base_type(t).search_one("path").arg
            if p.startswith("/") and "[" not in p:
                vals = self.collect(p)
                if vals is not None and value not in vals:
                    self.errors.append(f"{path}: leafref {value!r} -> {p} has no such instance")
                    return False
            target = getattr(ts, "i_target_node", None)
            if target is not None and target.search_one("type") is not None:
                return self.check_typed(target.search_one("type"), value, path, target)
            return True
        if bt in ("int64", "uint64", "decimal64") and not isinstance(value, str):
            self.errors.append(f"{path}: {bt} must be a JSON string (RFC 7951)")
            return False
        if bt in ("int8", "int16", "int32", "uint8", "uint16", "uint32") and (isinstance(value, bool) or not isinstance(value, int)):
            self.errors.append(f"{path}: {bt} must be a JSON number (RFC 7951)")
            return False
        if bt == "boolean":
            if not isinstance(value, bool):
                self.errors.append(f"{path}: boolean must be true/false")
                return False
            return True
        if bt == "empty":
            return value == [None]
        s = value if isinstance(value, str) else str(value)
        errs: list = []
        v = ts.str_to_val(errs, t.pos, s, t.i_module)
        if v is None or not ts.validate(errs, t.pos, v, t.i_module, ""):
            self.errors.append(f"{path}: {value!r} is not a valid {bt} ({t.arg}) {[e[1:] for e in errs][:1]}")
            return False
        return True

    def collect(self, abspath: str):
        """Values at an absolute schema path (no predicates) in the current document; None if not in this doc."""
        segs = [s for s in abspath.split("/") if s]
        names = [s.split(":")[-1] for s in segs]
        top = next((k for k in self.doc if k.split(":")[-1] == names[0]), None)
        if top is None:
            return None
        cur = [self.doc[top]]
        for n in names[1:]:
            nxt = []
            for c in cur:
                if isinstance(c, list):
                    c = {"_": c}
                for k, v in (c.items() if isinstance(c, dict) else []):
                    if k.split(":")[-1] == n or k == "_":
                        if k == "_":
                            nxt += [x.get(n) for x in v if isinstance(x, dict) and n in x]
                        else:
                            nxt += v if isinstance(v, list) else [v]
            cur = nxt
        return {x for x in cur if isinstance(x, (str, int))}

    # -- tree walk
    def walk(self, stmt, inst, path, parent_inst=None):
        kw = stmt.keyword
        for f in stmt.search("if-feature"):
            self.features.add(f.arg if ":" in f.arg else f"{stmt.i_module.i_modulename}:{f.arg}")
        if getattr(stmt, "i_config", True) is False:
            self.errors.append(f"{path}: read-only (config false) node in a configuration document")
        for expr, where, owner in self.whens(stmt):
            ok = self.eval_when(expr, where, owner, parent_inst)
            self.when_stats[ok is not None] += 1
            if ok is False:
                self.errors.append(f"{path}: 'when {expr}' is false here")
        if kw == "leaf":
            self.check_value(stmt, inst, path)
        elif kw == "leaf-list":
            for i, v in enumerate(inst if isinstance(inst, list) else [inst]):
                self.check_value(stmt, v, f"{path}[{i}]")
        elif kw == "list":
            if not isinstance(inst, list):
                self.errors.append(f"{path}: list must be a JSON array")
                return
            keys = [k.arg for k in getattr(stmt, "i_key", []) or []]
            seen = set()
            for i, entry in enumerate(inst):
                kv = tuple(entry.get(k) for k in keys)
                if None in kv:
                    self.errors.append(f"{path}[{i}]: missing list key(s) {keys}")
                if kv in seen:
                    self.errors.append(f"{path}[{i}]: duplicate key {kv}")
                seen.add(kv)
                self.walk_members(stmt, entry, f"{path}[{','.join(map(str, kv))}]")
        elif kw == "container":
            self.walk_members(stmt, inst, path)

    def walk_members(self, stmt, inst, path):
        if not isinstance(inst, dict):
            self.errors.append(f"{path}: expected a JSON object")
            return
        parent_mod = stmt.i_module.i_modulename
        for k, v in inst.items():
            mod, _, name = k.rpartition(":")
            ch = self.find_child(stmt, name, mod or parent_mod)
            if ch is None:
                self.errors.append(f"{path}/{k}: no such schema node")
                continue
            self.walk(ch, v, f"{path}/{k}", inst)
        for ch in self.leaves_in(stmt):
            m = ch.search_one("mandatory")
            if m is not None and m.arg == "true" and ch.arg not in {k.rpartition(':')[2] for k in inst}:
                if all(self.eval_when(e, w, o, inst) is not False for e, w, o in self.whens(ch)) and getattr(ch, "i_config", True):
                    self.errors.append(f"{path}: mandatory leaf '{ch.arg}' missing")

    def leaves_in(self, stmt):
        for ch in getattr(stmt, "i_children", []):
            if ch.keyword == "leaf":
                yield ch

    def check(self, doc: dict) -> list[str]:
        self.errors, self.doc = [], doc
        for k, v in doc.items():
            mod, _, name = k.partition(":")
            m = self.mods.get(mod) or self.module(mod)
            top = self.find_child(m, name, mod) if m is not None else None
            if top is None:
                self.errors.append(f"/{k}: no such top-level node")
                continue
            self.walk(top, v, f"/{k}", doc)
        return self.errors


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=str(Path(__file__).resolve().parents[2] / "docs" / "standards-samples"))
    ap.add_argument("--yang-root", default=None)
    args = ap.parse_args()

    topo = Topology()
    std = Standards(topo)
    findings = std.validate()
    errors = 0
    print("== Topology rules (TR-385 / G.984 / G.709 / X.733)")
    for f in findings:
        print(f"[{f['level'].upper():7}] {f['rule']:28} {f['entity']:12} {f['msg']}")
        errors += f["level"] == "error"
    print(f"   {sum(f['level'] == 'error' for f in findings)} error(s), {sum(f['level'] == 'warning' for f in findings)} warning(s)")

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    docs = std.documents()
    for name, doc in docs.items():
        (out / name).write_text(json.dumps(doc, indent=2) + "\n", encoding="utf-8")
    print(f"== Wrote {len(docs)} standard documents to {out}")

    if args.yang_root:
        root = Path(args.yang_root)
        try:
            import pyang  # noqa: F401
        except ImportError:
            print("pyang is not installed (pip install pyang); schema check skipped")
            return 1 if errors else 0
        print("== YANG schema check")
        checkers: dict[str, SchemaChecker] = {}
        for name, doc in docs.items():
            fam = name.split("_")[0]
            if fam not in checkers:
                checkers[fam] = SchemaChecker(yang_dirs(root, fam), DOC_MODULES[fam])
            c = checkers[fam]
            before = c.checked
            errs = c.check(doc)
            errors += len(errs)
            print(f"[{'PASS' if not errs else 'FAIL'}] {name:32} {c.checked - before} leaf values checked against {fam} YANG")
            for e in errs[:25]:
                print("        ", e)
        for fam, c in checkers.items():
            print(f"   {fam}: {c.when_stats[True]} 'when' conditions evaluated, {c.when_stats[False]} too complex for this checker")
            if c.features:
                print(f"   {fam}: uses optional YANG features {sorted(c.features)}")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
