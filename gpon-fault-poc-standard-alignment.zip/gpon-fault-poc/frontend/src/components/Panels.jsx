import { Fragment } from 'react'
import { fmtSec, fmtTime, PHASE_LABEL, SEV_COLOR } from '../api.js'

export function IncidentCard({ inc, selected, onClick }) {
  return (
    <div className={`inc ${selected ? 'sel' : ''}`} style={{ borderLeftColor: inc.status === 'resolved' ? 'var(--ok)' : SEV_COLOR[inc.severity] }}
      onClick={onClick}>
      <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
        <span className="t" style={{ flex: 1 }}>{inc.title || `${inc.id} · correlating…`}</span>
        <span className={`badge phase-${inc.phase}`}>{PHASE_LABEL[inc.phase] || inc.phase}</span>
      </div>
      <div className="m">
        <span>{inc.id}</span>
        {inc.kind !== 'reactive' && <span className="badge">{inc.kind}</span>}
        <span>{inc.alarms.length} alarms</span>
        {inc.impact && <span>blast {inc.impact.blast_radius} svc</span>}
        {inc.rca?.hypotheses?.[0]?.confidence != null && <span>RCA {Math.round(inc.rca.hypotheses[0].confidence * 100)}%</span>}
        <span>MTTD {fmtSec(inc.metrics.mttd_s)}</span>
        {inc.metrics.mttr_s !== undefined && <span>MTTR {fmtSec(inc.metrics.mttr_s)}</span>}
        {inc.resolved_by && <span>· {inc.resolved_by}</span>}
      </div>
    </div>
  )
}

export function IncidentList({ incidents, selectedId, onSelect }) {
  const open = incidents.filter((i) => i.status !== 'resolved')
  const closed = incidents.filter((i) => i.status === 'resolved').slice(0, 12)
  return (
    <div>
      {open.length === 0 && <div className="muted small" style={{ marginBottom: 8 }}>No open incidents. Launch a scenario above.</div>}
      {open.map((i) => <IncidentCard key={i.id} inc={i} selected={i.id === selectedId} onClick={() => onSelect(i.id)} />)}
      {closed.length > 0 && <div className="muted small" style={{ margin: '10px 0 6px' }}>Recently resolved</div>}
      {closed.map((i) => <IncidentCard key={i.id} inc={i} selected={i.id === selectedId} onClick={() => onSelect(i.id)} />)}
    </div>
  )
}

export function AlarmFeed({ alarms, onSelectIncident, filter }) {
  const rows = filter ? alarms.filter((a) => a.state === 'active') : alarms
  return (
    <div className="scroll" style={{ maxHeight: 330 }}>
      <table>
        <thead>
          <tr><th>Time</th><th>Severity</th><th>Alarm</th><th>Entity</th><th>Layer</th><th>Reporter · source</th><th>Incident</th><th>State</th></tr>
        </thead>
        <tbody>
          {rows.slice(0, 120).map((a) => (
            <tr key={a.id} className={`click ${a.state === 'cleared' ? 'cleared' : ''}`} onClick={() => a.incident && onSelectIncident(a.incident)}>
              <td className="mono">{fmtTime(a.first_ts)}</td>
              <td><span className="badge sev" style={{ background: SEV_COLOR[a.severity] }}>{a.severity}</span></td>
              <td title={a.ref}>{a.type}{a.late && <span className="badge" style={{ marginLeft: 4 }}>late</span>}</td>
              <td className="mono">{a.entity}</td>
              <td>{a.layer}</td>
              <td>{a.reporter} · {a.source}</td>
              <td className="mono">{a.incident || '–'}</td>
              <td>{a.state}{a.count > 1 ? ` ×${a.count}` : ''}{a.flaps ? ` (${a.flaps} flaps)` : ''}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export function EventLog({ events }) {
  return (
    <div className="events">
      {[...events].reverse().map((e, i) => (
        <div key={i}><span className="muted mono">{fmtTime(e.ts)}</span> <span className="k">{e.kind}</span>{e.msg}</div>
      ))}
    </div>
  )
}

function standardsRows(std) {
  if (!std) return []
  const rows = []
  const oc = std.openconfig
  if (oc) rows.push(['OpenConfig', [oc.path, oc.type, oc.if_type, oc.gap && `gap: ${oc.gap}`].filter(Boolean).join(' · ')])
  const b = std.bbf_tr385
  if (b) {
    const parts = b.channel_termination
      ? [`CT ${b.channel_termination}`, `CP ${b.channel_pair}`, `CPart ${b.channel_partition}`, `CG ${b.channel_group}`, `Type-B ${b.type_b_role}`, `hw ${b.hardware}`]
      : b.v_ani
        ? [`${b.v_ani} (onu-id ${b.onu_id}, SN ${b.expected_serial_number})`, `${b.ani}`, `${b.olt_v_enet} ↔ ${b.onu_v_enet}`, `pref ${b.preferred_channel_pair}${b.protection_channel_pair ? `, prot ${b.protection_channel_pair}` : ''}`,
           ...b.tconts.map((t) => `T-CONT alloc-id ${t.alloc_id} / GEM ${t.gemport_id} (${t.profile})`)]
        : [`${b.channel_group} / ${b.channel_partition}`, `closest ONU ${b.closest_onu_distance_km} km`, `max differential ${b.maximum_differential_xpon_distance_km} km`]
    rows.push(['BBF TR-385', parts.join(' · ')])
  } else if (std.bbf) rows.push(['BBF TR-383/385', [std.bbf.module, std.bbf.path, std.bbf.note].filter(Boolean).join(' · ')])
  if (std.ietf) rows.push(['IETF / IANA', Object.values(std.ietf).join(' · ')])
  if (std.g709) rows.push(['ITU-T G.709', std.g709.layers ? `${std.g709.layers.join(' → ')} · TTI ${std.g709.tti?.sapi}→${std.g709.tti?.dapi}` : std.g709.note])
  if (std.rfc8345) rows.push(['RFC 8345', Object.entries(std.rfc8345).map(([k, v]) => `${k.replace('_', ' ')} ${v.join(', ')}`).join(' · ')])
  if (std.note) rows.push(['Standards note', std.note])
  return rows
}

export function EntityPanel({ topology, id, view, incidents, onSelectIncident }) {
  if (!id || !topology) return <div className="muted small">Click a node or link to see its ontology record, status and dependencies.</div>
  const e = topology.entities.find((x) => x.id === id)
  if (!e) return null
  const v = view[id] || {}
  const deps = topology.entities.filter((x) => x.depends_on.includes(id)).map((x) => x.id)
  const incs = incidents.filter((i) => i.status !== 'resolved' && (i.entities.includes(id) || i.impact?.root === id))
  return (
    <div className="kv">
      <div>Entity</div><div><b>{e.id}</b> — {e.name}</div>
      <div>Ontology class</div><div>{e.class} · {e.kind} · layer {e.layer} · domain {e.domain} · policy class {e.policy_class}</div>
      <div>Depends on</div><div className="mono">{e.depends_on.join(', ') || '– (root)'}</div>
      <div>Dependents</div><div className="mono">{deps.join(', ') || '–'}</div>
      {e.protection && (<><div>Protection</div><div>{e.protection.type}: working {e.protection.working}, standby {e.protection.standby}</div></>)}
      <div>Attributes</div><div>{Object.entries({ ...e.meta, ...(e.rate ? { rate: e.rate } : {}), ...(e.subtype ? { subtype: e.subtype } : {}), ...(e.encapsulation ? { encapsulation: e.encapsulation } : {}) }).map(([k, val]) => `${k}: ${val}`).join(' · ') || '–'}</div>
      {standardsRows(e.std).map(([k, val]) => (<Fragment key={k}><div>{k}</div><div className="small">{val}</div></Fragment>))}
      <div>Status</div><div>{v.severity ? `${v.alarms} active alarm(s), worst ${v.severity}` : 'no active alarms'}{v.root_of ? ` · ROOT CAUSE of ${v.root_of}` : ''}{v.impacted_by ? ` · impacted by ${v.impacted_by}` : ''}</div>
      {incs.length > 0 && (<><div>Incidents</div><div>{incs.map((i) => <button key={i.id} className="btn small" onClick={() => onSelectIncident(i.id)} style={{ marginRight: 4 }}>{i.id}</button>)}</div></>)}
    </div>
  )
}
