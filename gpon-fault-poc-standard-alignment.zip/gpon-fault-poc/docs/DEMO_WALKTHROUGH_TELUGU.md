# GPON · G.702 Backhaul AI Fault & Alarm Management PoC: డెమో వాక్‌త్రూ (తెలుగు)

ఇది presenter script. Dashboard (http://localhost:5173) తెరిచి, ఈ order లో చూపిస్తూ మాట్లాడండి.
Technical terms (alarm, OLT, ONT, E1, BSC, root cause మొదలైనవి) English లోనే ఉంచాం.
`>` తో మొదలయ్యే lines presenter చెప్పాల్సిన మాటలు; 👉 గుర్తు ఉన్నవి ఏం click చేయాలో చెబుతాయి.

**డెమో ముందు సిద్ధం:** `./run_backend.sh`, `./run_frontend.sh` run చేయండి. Dashboard లో **Reset all** నొక్కండి.
మొదటి డెమోలో గందరగోళం లేకుండా ఉండాలంటే **background noise** checkbox off చేయండి.

---

## 1. పరిచయం (30 సెకన్లు)

> అందరికీ నమస్కారం. ఈ రోజు మనం చూడబోయేది ఒక AI-powered, closed-loop fault & alarm management PoC.
> మన backhaul network లో రెండు ప్రపంచాలు కలిసి ఉంటాయి: ఒకటి G.702 (E1/E3 circuits, CES gateway, BSC, 2G BTS),
> రెండోది GPON (OLT, PON port, splitter, ONT). ఒక fibre cut అయితే చాలు, పది పదిహేను devices నుంచి వేర్వేరు alarms వస్తాయి.
> NOC engineer ఆ alarms అన్నీ చూసి, అసలు root cause ఏంటో కనుక్కొని, fix చేయడానికి చాలా సమయం పడుతుంది.
> ఈ system ఆ పనిని నాలుగు దశల్లో automatic గా చేస్తుంది: **Detect → Analyze → Decide → Act → Verify**.
> ఎంత వరకు AI తనే చేయాలి, ఎక్కడ మనిషి approval కావాలి అనేది policy నిర్ణయిస్తుంది.
>
> ఒక్క విషయం ముందే చెప్పాలి: ఇక్కడ network simulated. నిజమైన OLT లు లేవు, కానీ alarms, telemetry, SNMP traps, syslog
> అన్నీ నిజమైన devices లాగే వస్తాయి. Simulator గంటల పనిని సెకన్లలో చూపిస్తుంది.

---

## 2. Screen పై భాగం: Header మరియు status chips

👉 Screen పైన ఉన్న title bar చూపించండి.

> పైన title: **GPON · G.702 Backhaul — AI Fault & Alarm Management**. కింద చిన్న అక్షరాల్లో మూడు ముఖ్యమైన విషయాలు:
> topology-aware correlation, closed-loop remediation, fault-tolerant pipeline.

కుడి వైపు ఉన్న **status chips** ఒక్కొక్కటి వివరించండి. పచ్చ చుక్క అంటే బాగుంది, ఎరుపు/పసుపు అంటే సమస్య.

| Chip | ఏం చెబుతుంది |
|---|---|
| **Dashboard link live / lost** | Browser కి backend తో connection ఉందా లేదా. Lost అయితే చివరి state చూపిస్తూ ప్రతి సెకను retry చేస్తుంది. |
| **Correlation CE-x active / FAILOVER** | ప్రస్తుతం ఏ correlation engine instance leader గా పని చేస్తోంది. Crash అయితే FAILOVER అని ఎరుపులో చూపిస్తుంది. |
| **AI online / down · safe mode** | AI component పని చేస్తోందా. Down అయితే safe mode లోకి వెళ్తుంది. |
| **Ingestion normal · q N** | Alarm ingestion pipeline state, queue లో ఎన్ని messages ఉన్నాయి. Storm వస్తే state మారుతుంది. |
| **Alarm storm z=…** | Alarm rate అసాధారణంగా పెరిగినప్పుడు మాత్రమే కనిపిస్తుంది (AI model z-score). |
| **… mgmt unreachable** | ఏదైనా device (ఉదా. OLT-B) management కి అందకపోతే మాత్రమే కనిపిస్తుంది. |

> ఇవి కాక, సమస్య వచ్చినప్పుడు మాత్రమే కనిపించే మూడు **banners** ఉన్నాయి: Safe mode banner (AI down),
> Correlation failover banner (engine మారుతోంది, events ఏవీ పోవు), Lost connection banner. వీటిని తర్వాత drills లో చూపిస్తాను.

---

## 3. KPI strip: ఎనిమిది tiles

👉 Header కింద ఉన్న ఎనిమిది KPI boxes చూపించండి. Reset తర్వాత ఎక్కువ విలువలు `–` గా ఉంటాయి. "డెమో చేస్తున్న కొద్దీ ఇవి నిండుతాయి" అని చెప్పండి.

| KPI | అర్థం | Audience గమనించాల్సింది |
|---|---|---|
| **MTTD (live)** | Fault జరిగినప్పటి నుంచి incident open అయ్యే వరకు సగటు సమయం | కింద "baseline N min (rule-based)" తో పోల్చండి. మనది సెకన్లలో ఉంటుంది. |
| **MTTR (live)** | Fault నుంచి service restore అయ్యే వరకు సగటు సమయం | "auto" విలువ: మనిషి లేకుండా fix అయిన వాటి MTTR. |
| **Alarm compression** | ఎన్ని raw alarms ఒక incident గా కలిశాయి (ఉదా. 15×) | "45 alarms → 3 incidents" లాంటి లెక్క. NOC కి 45 tickets కాదు, 3 మాత్రమే. |
| **Resolved autonomously** | మనిషి జోక్యం లేకుండా close అయిన incidents శాతం | "verification pass %" అంటే action తర్వాత telemetry check pass అయిన శాతం. |
| **Open incidents** | ఇంకా open గా ఉన్నవి | "transients self-cleared": తనంతట తానే తగ్గిపోయిన తాత్కాలిక alarms. |
| **Awaiting approval** | Operator approval కోసం ఎదురు చూస్తున్న actions | "actions executed": ఇప్పటి వరకు network పై చేసిన actions. |
| **Escalations** | NOC కి escalate అయిన incidents మొత్తం | "currently open": ఇప్పుడు ఇంకా open గా ఉన్నవి. |
| **Predicted faults** | Alarm రాక ముందే AI ఊహించిన faults | "duplicates suppressed": పదే పదే వచ్చిన అదే alarm ని ఎన్నిసార్లు drop చేశామో. |

---

## 4. Demo scenarios bar మరియు controls

👉 KPI strip కింద ఉన్న buttons row చూపించండి.

> ఇక్కడ ఉన్న buttons నిజమైన network లో fault జరిగినట్టు simulator లో fault inject చేస్తాయి.
> Button పై mouse పెడితే ఆ scenario కథ tooltip లో కనిపిస్తుంది.

| Button | ఏం జరుగుతుంది | చూపించాల్సిన ఫలితం |
|---|---|---|
| **Cascading fibre cut** (ఎరుపు) | Feeder fibre F-A1 కట్ అవుతుంది | ఒకే incident, root cause F-A1, approval కోసం wait |
| **E1 timing slips (autonomous)** (పచ్చ) | ONT-A1-2 CES port తప్పు clock కి lock అవుతుంది | మనిషి లేకుండా సెకన్లలో resolve |
| **PON optics degradation (escalates)** (పసుపు) | PON-B2 laser పాతబడుతుంది | Verification fail, NOC కి escalate |
| **ONT Rx drift (predictive)** (నీలం) | ONT-B1-3 connector మురికి, Rx power పడిపోతోంది | Alarm రాక ముందే predictive incident |
| **OLT uplink failure** (ఎరుపు) | OLT-A నుంచి AGG-1 కి uplink పోతుంది | పెద్ద outage, advisory తర్వాత escalation |
| **▶ Guided demo** | మొదటి నాలుగు scenarios ఒకదాని తర్వాత ఒకటి (30 సెకన్ల gap), చివర్లో correlation engine crash | Hands-free డెమో |
| **Repair network** | Simulator లో ఉన్న అన్ని faults repair చేస్తుంది | Incidents history లో ఉంటాయి |
| **Reset all** | Repair + అన్ని incidents clear | కొత్తగా మొదలుపెట్టడానికి |

కుడి వైపు రెండు checkboxes:

- **show simulator ground truth**: Fault నిజంగా ఎక్కడ inject చేశామో topology పై ⚡ గుర్తుతో చూపిస్తుంది.
  > "AI చెప్పిన root cause, నిజమైన fault ఒకటేనా అని మీరే check చేసుకోవచ్చు. ఇది AI కి కనిపించదు, మనకు మాత్రమే."
- **background noise**: Random తాత్కాలిక alarms (dying gasp, CPU spike లాంటివి) పంపుతుంది. నిజమైన network లాగా ఉండాలంటే on చేయండి.

ఏ button నొక్కినా పక్కన చిన్న confirmation message (toast) 4 సెకన్లు కనిపిస్తుంది, ఉదా. "Started: Cascading fibre cut".

చివరగా నాలుగు **tabs**: Operations, Closed loop, Autonomy & resilience, Trends & KPIs.
Closed loop tab పక్కన ఎరుపు number badge వస్తే, approval కోసం లేదా escalate అయి ఎదురు చూస్తున్న incidents అన్ని ఉన్నాయి అని అర్థం.

---

## 5. Operations tab: ప్రశాంత స్థితిలో network

👉 Operations tab తెరవండి. ఇంకా ఏ fault inject చేయకండి.

### 5.1 Network topology

> ఇది మన network ontology map. పై నుంచి కిందికి ఏడు వరుసలు: **Core → Aggregation → OLT → PON port → Splitter → ONT → Cell site**.

ఆకారాలు వివరించండి:

- **పెద్ద చతురస్రం** = OLT (OLT-A, OLT-B)
- **చిన్న చతురస్రం** = PON port (P-A1 లాంటి label)
- **Diamond** = Splitter
- **వృత్తం** = ONT
- **త్రిభుజం** = BTS (cell site)
- **గుండ్రని అంచుల box** = Core router, aggregation switch, CES gateway, BSC, PDH mux

Colors (కింద legend లో కూడా ఉంటుంది):

- **GPON color** = OLT, PON, ODN fibre, ONT
- **G.702 color** = E1/E3 circuits, PDH mux, CES, BSC, BTS
- **IP color** = aggregation, core
- Fault వచ్చినప్పుడు node severity color తో నిండుతుంది: critical ఎరుపు, major నారింజ, minor, warning.

> గమనించండి: F-A1 పక్కన dashed గా ఒక feeder కనిపిస్తుంది. అది **standby feeder** (Type-B protection). ఇప్పుడు వాడటం లేదు,
> కానీ fibre cut అయితే దానికి switch చేస్తాం. E1-101, E1-102 లాంటి labels E1 circuits ని చూపిస్తాయి.

Top-right లో "click an incident to focus" అని ఉంటుంది. Incident select చేస్తే దానికి సంబంధం లేని nodes మసకబారుతాయి; **clear** button తో మళ్ళీ మొత్తం చూడవచ్చు.

### 5.2 Entity details

👉 Topology లో OLT-A పై click చేయండి, తర్వాత ఒక ONT పై.

> ఏ node లేదా link పై click చేసినా దాని ontology record ఇక్కడ వస్తుంది:

- **Entity**: ID, పేరు
- **Ontology class**: class, kind, layer, domain (gpon / g702 / ip), policy class (autonomy matrix లో ఏ row వర్తిస్తుందో)
- **Depends on**: ఇది దేనిపై ఆధారపడుతుంది (upstream)
- **Dependents**: దీనిపై ఎవరు ఆధారపడతారు (downstream)
- **Protection**: Protection group ఉంటే working / standby
- **Attributes**: vendor, rate, subtype, encapsulation లాంటి meta data
- **Status**: active alarms ఎన్ని, worst severity, "ROOT CAUSE of INC-x" లేదా "impacted by INC-x"
- **Incidents**: ఈ entity కి సంబంధించిన open incidents buttons. Click చేస్తే incident తెరుచుకుంటుంది.

> AI కి ఈ dependency graph తెలుసు కాబట్టే "ఈ alarms అన్నీ ఒకే fault వల్ల" అని చెప్పగలదు. ఇదే topology-aware correlation.

### 5.3 Real-time alarm feed

> ఇది NOC engineer సాధారణంగా చూసే alarm list. Columns:

**Time** · **Severity** (రంగు badge) · **Alarm** type (ఆలస్యంగా వస్తే "late" badge) · **Entity** · **Layer** ·
**Reporter · source** (ఏ device పంపింది, SNMP / syslog / event stream) · **Incident** (ఏ incident లో కలిసింది) ·
**State** (active / cleared, ×count అంటే ఎన్నిసార్లు repeat, flaps).

- Cleared alarms మసకగా కనిపిస్తాయి.
- **active only** checkbox: cleared వాటిని దాచేస్తుంది.
- ఏ row పై click చేసినా దాని incident తెరుచుకుంటుంది.

### 5.4 Correlated incidents (కుడి వైపు)

> ఇప్పుడు "No open incidents. Launch a scenario above." అని ఉంది. Fault రాగానే ఇక్కడ incident cards వస్తాయి.

ప్రతి card లో: title, **phase badge** (Detecting, Analyzing, Advisory, Awaiting approval, Acting, Verifying, Watching, Escalated, Resolved),
incident ID, kind (predictive అయితే badge), ఎన్ని alarms, blast radius (ఎన్ని services), RCA confidence %, MTTD, MTTR, ఎవరు resolve చేశారు.
ఎడమ అంచు రంగు severity ని చూపిస్తుంది; resolve అయితే పచ్చ. కింద "Recently resolved" లో చివరి 12 resolved incidents.

### 5.5 System activity

> ఇది platform audit log: scenarios, AI decisions, actions, escalations, failovers అన్నీ time తో ఇక్కడ వస్తాయి. కొత్తవి పైన.

---

## 6. డెమో 1: Cascading fibre cut (ప్రధాన కథ, సుమారు 3 నిమిషాలు)

👉 **Cascading fibre cut** నొక్కండి. 4–5 సెకన్లు ఆగండి.

> ఒక JCB తవ్వకంలో feeder fibre F-A1 కట్ అయిందనుకోండి. ఇప్పుడు ఏం జరుగుతుందో చూడండి.

**Alarm feed** చూపించండి:

> చూడండి, ఒకేసారి సుమారు 15 alarms వచ్చాయి: OLT నుంచి PON LOS (SNMP), నాలుగు ONTs నుంచి LOSi,
> CES gateway నుంచి రెండు E1 pseudowire down (syslog), BSC నుంచి రెండు 2G cells down, service assurance నుంచి
> 4G మరియు enterprise SLA breach. సాధారణ NOC లో ఇవి 15 వేర్వేరు tickets.

**Correlated incidents** చూపించండి:

> కానీ ఇక్కడ ఒకే ఒక్క incident వచ్చింది. Phase "Awaiting approval". RCA confidence సుమారు 89%.

**Topology** చూపించండి:

> F-A1 link పై **RC** గుర్తు, ఎరుపు dashed line, pulsing ring. Fibre కి alarm పంపే శక్తి లేదు, అది passive.
> అయినా AI దాన్ని root cause గా గుర్తించింది. Rule-based system అయితే PON port ని blame చేసేది.
> Downstream ONTs, BTS లు నారింజ రంగులో "impacted" గా కనిపిస్తున్నాయి.

👉 (ఐచ్ఛికం) **show simulator ground truth** on చేయండి: ⚡ గుర్తు F-A1 పైనే వస్తుంది. "AI సరిగ్గా చెప్పింది."

👉 Incident card పై click చేయండి. కుడి వైపు **incident drawer** తెరుచుకుంటుంది. పై నుంచి కిందికి వివరించండి:

### 6.1 Drawer పై భాగం

- Severity badge, phase badge, kind (reactive / predictive), ID, open అయిన సమయం, **Close** button.
- Title: incident సారాంశం.
- **Stepper**: Detect → Analyze → Decide → Act → Verify → Close. పూర్తైనవి highlight, ప్రస్తుత దశ వేరే రంగు, verify fail అయితే ఎరుపు, చివరి box "Resolved" లేదా "Escalated".

> ఇప్పుడు Detect, Analyze, Decide పూర్తయ్యాయి. Act దగ్గర ఆగింది, ఎందుకంటే మన approval కావాలి.

### 6.2 Metrics

- **MTTD** (fault → incident), **Time to analyze**, **Time to decision**, **Time to first action**, **MTTR** (fault → restored, ఎవరు resolve చేశారు), predictive అయితే **Prediction lead time**, **Correlated alarms** (ఎన్ని alarms, ఎన్ని entities).

### 6.3 Root cause analysis

> ఇది AI ఎలా ఆలోచించిందో చూపిస్తుంది. Method, ఎన్ని candidates score చేసిందో పైన ఉంటుంది.
> Top 5 hypotheses, ఒక్కొక్క దానికి confidence bar. మొదటిది ★ తో: **F-A1 (FiberSegment)**.

ప్రతి hypothesis కింద evidence:
- **explains N% of alarms**: ఈ entity fail అయితే ఎన్ని alarms వివరించబడతాయి
- **healthy dependents**: దీనిపై ఆధారపడినా బాగానే ఉన్నవి ఎన్ని (ఎక్కువ ఉంటే ఇది root cause కాదు)
- **prior**: చరిత్ర ప్రకారం ఈ class fail అయ్యే అవకాశం
- అదనపు evidence notes

> కింద ఉన్న ఇతర candidates (ఉదా. PON-A1 port) కి confidence తక్కువ. OLT తానే PON LOS alarm పంపుతోంది కాబట్టి OLT, port బతికే ఉన్నాయి;
> port కింద ఉన్న ONTs అన్నీ ఒకేసారి పోయాయి కాబట్టి సమస్య మధ్యలో ఉన్న feeder fibre లో ఉంది అని AI reasoning.

### 6.4 Impact

- **Blast radius**: ఎన్ని services, ఎన్ని cell sites, ఎంత మంది subscribers
- **Services**, **Cell sites** list
- **Upstream path**: root నుంచి core వరకు path

> Blast radius 5 services, 2 cell sites. గుర్తుంచుకోండి, ఇది ముఖ్యం.

### 6.5 Decision (autonomy policy)

- **Policy cell**: ఉదా. ODN × link_down
- **Configured level**: matrix లో ఉన్నది
- **Effective level**: guardrails తర్వాత నిజంగా వర్తించేది (safe mode అయితే "(safe mode)")
- **Proposed action**: ఏ action, ఏ target పై, risk ఎంత
- **Adjustments**: level ఎందుకు మారిందో
- **Boundary** (ఎరుపు): ఏ guardrail దాటిందో

> Blast radius 5, autonomy limit 4. అందుకే AI తానే చేయకుండా "supervised" గా మన approval అడుగుతోంది. ఇదే safe autonomy.

### 6.6 Recommended remediation

> Playbook library నుంచి AI ఎంచుకున్నది: **GPON Type-B protection switchover**. Steps, ప్రతి step కి action name, risk.
> చరిత్రలో ఈ playbook success rate ఎంత (n = ఎన్ని సార్లు), similar past incidents ఎన్ని, వాటి median MTTR ఎంత.
> కింద మసకగా ఇతర alternative playbooks కూడా చూపిస్తుంది.

### 6.7 Correlated alarms మరియు enrichment

👉 Table లో ఏదైనా alarm row (ఉదా. ONT LOSi) పై click చేయండి.

> ప్రతి alarm కి enrichment: **Topology** (layer, domain, OLT, PON, splitter), **Managed by** (EMS / site), **Device** details,
> **Impact** (services, cell sites, subscribers), **History (30 d)** (గత 30 రోజుల్లో incidents, MTBF, చివరిసారి ఎప్పుడు), **Detail** (raw alarm data).
> NOC engineer కి వేరే tool తెరవాల్సిన అవసరం లేదు.

### 6.8 Closed-loop timeline

> కిందన ప్రతి దశ time stamp తో: detect, analyze, decide... audit కి ఇది చాలా ఉపయోగం.

### 6.9 Approve చేసి resolution చూపించడం

👉 పైన పచ్చ button **Approve: pon_protection_switch → …** నొక్కండి. (వేరే option: **Reject**)

> ఇప్పుడు loop NETCONF ద్వారా PON protection group ని standby feeder కి switch చేస్తుంది.

10–15 సెకన్లు ఆగి చూపించండి:

- Phase: Acting → Verifying → **Resolved**. Stepper అంతా పచ్చ.
- **Actions and verification** section: action ID, action → target, protocol, mode (supervised), Status, result message.
  **Verification: passed** over N s window. ● పచ్చ చుక్కలు = ప్రతి telemetry check pass. ○ ఎరుపు = fail. Relapse అయితే "relapsed N×".
- **Follow-up ticket** callout: "Open field ticket: locate break on working feeder with OTDR and splice".

> Service restore అయింది, కానీ fibre ఇంకా తెగే ఉంది. అందుకే field team కి OTDR తో break కనుక్కొని splice చేయమని follow-up ticket open అయింది.

👉 **Close follow-up … (repair done)** button నొక్కండి: "field team repair పూర్తి చేసినప్పుడు ఇలా close చేస్తారు."

👉 Topology కి తిరిగి వెళ్ళండి: ఎరుపు రంగు పోయింది. KPI strip లో MTTD, MTTR, compression నిండాయి.

> 15 alarms → 1 incident, root cause సరైనది, ఒక్క click తో restore. ఇదే మా ప్రధాన సందేశం.

---

## 7. Closed loop tab

👉 **Closed loop** tab తెరవండి.

> ఇది supervisor view. Open incidents అన్నీ నాలుగు columns (kanban) లో:

| Column | ఏ incidents |
|---|---|
| **Awaiting approval** | Supervised actions, approve / reject కావాలి |
| **Advisory (recommendations)** | AI సూచన మాత్రమే, మనిషి Execute నొక్కాలి |
| **Executing / verifying / watching** | ప్రస్తుతం పని జరుగుతున్నవి, లేదా transient అని watch చేస్తున్నవి |
| **Escalated to NOC** | AI చేయలేనివి లేదా చేయకూడనివి |

ప్రతి column పైన count badge. Card పై click చేస్తే అదే incident drawer తెరుచుకుంటుంది.

కింద **Action log: executed actions and post-action verification** table:
**Started · Action · Incident · Target · Mode** (advisory / supervised / autonomous) · **Protocol** (NETCONF, OMCI, TL1, Workforce, Ticketing) ·
**Status** · **Verification** (passed పచ్చ / failed ఎరుపు, relapse count) · **Result**.

> Network పై చేసిన ప్రతి action, దాని ఫలితం ఇక్కడ రికార్డ్ అవుతుంది. Compliance, audit కి పూర్తి trace.

ఈ tab తెరిచే ఉంచి తర్వాతి డెమోలు చేస్తే cards columns మధ్య కదలడం బాగా కనిపిస్తుంది.

---

## 8. డెమో 2: E1 timing slips, పూర్తిగా autonomous

👉 **E1 timing slips (autonomous)** నొక్కండి. Closed loop tab లో చూడండి.

> ONT firmware restart తర్వాత ONT-A1-2 CES port తప్పు clock కి lock అయింది. E1-102 పై G.822 slips వస్తున్నాయి,
> pseudowire jitter buffer underrun, BSC లో call drops.

> Policy cell **G702 × timing_sync = autonomous**, risk low. కాబట్టి ఈసారి AI ఎవరినీ అడగదు.
> Card "Executing" column లో కనిపించి, కొన్ని సెకన్లలోనే మాయమవుతుంది.

👉 Action log లో కొత్త row చూపించండి: `e1_timing_relock` via OMCI, mode autonomous, verification passed.
👉 Operations tab లో "Recently resolved" లో incident తెరిచి: MTTR సుమారు 7–10 సెకన్లు, resolved by autonomous.

> Verification లో `slips = 0` అని fresh telemetry తో check చేసిన తర్వాతే close చేసింది. "Action చేశాం" అని కాదు, "fix అయిందని నిరూపించాం".
> KPI strip లో **Resolved autonomously** % పెరిగింది చూడండి.

---

## 9. డెమో 3: PON optics degradation, escalation

👉 **PON optics degradation (escalates)** నొక్కండి.

> OLT-B లో PON-B2 transceiver laser పాతబడుతోంది. దాని కింద ఉన్న ప్రతి ONT లో BER పెరుగుతోంది.
> AI laser bias anomaly ఆధారంగా fibre కాకుండా **port** నే root cause గా ర్యాంక్ చేసింది.

చూపించాల్సినవి (incident drawer లో):

1. Policy OLT × signal_degradation = autonomous, కాబట్టి మొదటి step **pon_optics_recalibrate** (low risk) తానే run చేసింది.
2. **Actions and verification** లో verification **failed**, ఎరుపు callout, ○ చుక్కలు, "relapsed" (BER మళ్ళీ పెరిగింది). Stepper లో Verify ఎరుపు.
3. తర్వాతి step **pon_port_migrate** (ONTs అన్నీ spare port కి, ~30 s service hit) risk **high**. Guardrail max risk = medium.
4. కాబట్టి **Escalated to NOC** ఎరుపు callout: ticket number, కారణం, "Proposed next action awaiting a human".
5. Closed loop tab పక్కన ఎరుపు badge, Escalated column లో card. KPI **Escalations** పెరిగింది.

> AI కి తన హద్దులు తెలుసు. విఫలమైనప్పుడు గుడ్డిగా ఇంకా ప్రమాదకరమైనది చేయదు. పూర్తి context తో మనిషికి అప్పగిస్తుంది.

Escalated incident కి drawer లో మూడు buttons:

- **Approve proposed: pon_port_migrate**: మనిషి high-risk action కి ఒప్పుకుంటే
- **Acknowledge**: NOC "చూశాం" అని తెలియజేయడం (acknowledged badge వస్తుంది)
- **Resolve (field fix applied)**: field team SFP మార్చి fix చేసినప్పుడు

👉 **Acknowledge** నొక్కి, తర్వాత **Approve proposed** లేదా **Resolve (field fix applied)** నొక్కి close చేయండి.

---

## 10. డెమో 4: ONT Rx drift, predictive

👉 **ONT Rx drift (predictive)** నొక్కండి. Alarm feed చూపించండి.

> ONT-B1-3 drop connector మురికిగా ఉంది. Downstream Rx power నిమిషానికి సుమారు 5 dB పడిపోతోంది. కానీ గమనించండి,
> **ఇంకా ఒక్క alarm కూడా లేదు**. Device threshold దాటలేదు.

👉 20–40 సెకన్లు ఆగండి. (ఈ సమయంలో Autonomy & resilience tab లో AI component card లో "Active predictions" చూపించవచ్చు:
`ONT-B1-3: rx_power … dBm, … dB/min, crosses in …s (p=…)`.)

> ఇప్పుడు **predictive** incident open అయింది. Trend + logistic model receiver sensitivity ఎప్పుడు దాటుతుందో ఊహించింది.
> Drawer లో **Prediction lead time** చూడండి: alarm రాక ముందే ఇంత సమయం ముందుగా తెలిసింది.

> Policy ONT × signal_degradation = **advisory**. కాబట్టి AI సూచిస్తుంది మాత్రమే: "technician ని పంపి connector clean చేయండి".

👉 **Execute recommendation: dispatch_field_cleaning** నొక్కండి (లేదా **Dismiss**). Verification లో Rx power తిరిగి వచ్చిందని చూపిస్తుంది, incident resolve.

> 4G site down కాక ముందే సమస్య పరిష్కారం. Reactive నుంచి proactive operations కి మార్పు ఇదే. KPI **Predicted faults** పెరిగింది.

---

## 11. డెమో 5 (ఐచ్ఛికం): OLT uplink failure, పెద్ద outage

👉 **OLT uplink failure** నొక్కండి.

> OLT-A నుంచి AGG-1 కి uplink LAG fail అయింది. OLT-A వెనక ఉన్న ప్రతి ONT, cell site, service down.
> OLT-A నిశ్శబ్దం అయిపోయింది, ఏ alarm పంపలేదు. AI AGG-1 పంపిన LINK_DOWN నుంచి reasoning చేసింది:
> "AGG-1 report చేస్తోంది కాబట్టి అది బతికే ఉంది; సమస్య uplink లో ఉంది."

- ఒకే incident లో OLT-A మొత్తం ప్రభావం, blast radius చాలా పెద్దది.
- Policy Aggregation × link_down = **advisory**, risk high reroute సూచన.
- 👉 **Execute recommendation: uplink_reroute** నొక్కండి: secondary uplink provision కాలేదు కాబట్టి action fail, loop **escalate** చేస్తుంది.

> నిజ జీవితంలో అన్నీ పని చేయవు. Action fail అయినా system ఆ విషయం గుర్తించి, మనిషికి సరైన సమాచారంతో అప్పగిస్తుంది.

తర్వాత **Repair network** నొక్కండి.

---

## 12. Autonomy & resilience tab

👉 **Autonomy & resilience** tab తెరవండి.

### 12.1 Autonomy matrix

> ఇది మా governance control. Rows లో device classes: **OLT, ONT, ODN, G702, Aggregation, Core, Service**.
> Columns లో fault categories: **Link down, Signal degradation, Timing/sync, Equipment, Config, Performance**.
> ప్రతి cell లో dropdown, రంగుతో: **advisory** (AI సూచిస్తుంది, మనిషి execute), **supervised** (AI సిద్ధం చేస్తుంది, approval తర్వాత run),
> **autonomous** (AI తానే చేసి verify చేస్తుంది, fail అయితే escalate).

> Core, Service rows అన్నీ advisory: core network లో AI తానే ఏమీ చేయదు. ONT చిన్న ప్రభావం కాబట్టి ఎక్కువ autonomous.
> ఈ matrix ని operator తమ నమ్మకం పెరిగిన కొద్దీ మార్చుకోవచ్చు. Change వెంటనే వర్తిస్తుంది.

👉 (ఐచ్ఛిక live demo) **ODN × Link down** ని autonomous కి మార్చి fibre cut మళ్ళీ run చేయండి:
> "Matrix autonomous అన్నా కూడా blast radius 5 > 4 కాబట్టి guardrail దాన్ని ఇంకా approval కి పంపుతుంది." తర్వాత reset చేయండి.

### 12.2 Guardrails (autonomy boundaries)

| Guardrail | Default | అర్థం |
|---|---|---|
| **Max risk for autonomous actions** | medium | దీనికంటే ఎక్కువ risk ఉన్న action escalate |
| **Max blast radius (services) for autonomy** | 4 | ఎక్కువ services ప్రభావితమైతే approval కావాలి |
| **Min RCA confidence for autonomy** | 0.6 | AI కి 60% కంటే తక్కువ నమ్మకం ఉంటే supervised కి దిగుతుంది |
| **Max actions per element per hour** | 4 | ఒకే device పై పదే పదే actions ఆపడానికి rate limit |
| **Safe-mode ceiling (AI unavailable)** | advisory | AI down అయితే గరిష్టంగా ఈ level మాత్రమే |

**Reset policy to defaults** button: అన్నీ మొదటి విలువలకు తిరిగి.

### 12.3 Fault-tolerance drills

> ఇప్పటి వరకు network faults చూశాం. ఇప్పుడు మా **platform** కే సమస్య వస్తే ఏమవుతుందో చూద్దాం. ప్రతి drill కి **Run** button.

| Drill | ఏం జరుగుతుంది | Audience గమనించాల్సింది |
|---|---|---|
| **Alarm storm / backpressure** | ~3,500 messages ఒకేసారి, అదే సమయంలో ఒక నిజమైన fault | Queue gauge నిండుతుంది, low-priority shed, sources retry. Callout లో "real fault alarm delivered: **true**" |
| **Duplicate & out-of-order replay** | Traps/syslog రెండుసార్లు, కలగలిపి, పాత clears తో | Callout: "N replayed → N duplicates dropped, N re-ordered, N stale clears ignored". Incident తప్పుగా close అవదు |
| **Correlation engine failover** | Active engine ని kill చేస్తుంది | Header లో FAILOVER banner, standby leader అవుతుంది, checkpoint నుంచి replay, ఏ incident పోదు |
| **AI service outage (safe mode)** | AI down | పసుపు safe mode banner, rule-based RCA, అన్ని actions advisory కి పరిమితం. Button "Restore AI service" గా మారుతుంది, **Turn off** తో తిరిగి |
| **OLT-B management unreachable** | OLT-B కి commands timeout | Header chip "OLT-B mgmt unreachable", circuit breaker open, loop action చేయకుండా escalate. **Turn off** తో restore |

👉 సూచన: Alarm storm run చేసి వెంటనే కుడి వైపు Ingestion pipeline card చూపించండి. Correlation engine failover run చేసి Correlation engine card చూపించండి.

### 12.4 Ingestion pipeline card

- పైన state badge (normal / shedding లాంటివి)
- **Queue gauge**: నిండిన శాతం, నిలువు గీత = high watermark (దాటితే low-priority shed, bar నారింజ రంగు)
- Queue depth/capacity, peak, re-order buffer, log offset
- 8 stats: **received, shed (low priority), rejected (full), duplicates dropped, re-ordered, late events, stale ignored, dead-lettered**
- Sources table: ప్రతి source (SNMP, syslog, event stream, telemetry) కి **Sent, Buffered, Retries, Backoff, Stale dropped**

> Storm లో కూడా critical alarm ముందుగా వెళ్తుంది. Telemetry లాంటి తక్కువ ప్రాధాన్యత ఉన్నవి మాత్రమే drop అవుతాయి.

### 12.5 Correlation engine (active / standby) card

- Instances table: **Instance, Role** (leader పచ్చ / standby / crashed ఎరుపు), **Heartbeat age, Log offset, Note** (restarts in Ns)
- **Consumer lag**, checkpoint ప్రతి 1 s, 2.5 s heartbeat లేకపోతే failover
- **Failovers** list: from → to, ఎన్ని సెకన్లలో detect, ఏ checkpoint నుంచి restore, ఎన్ని events replay, ఎన్ని ms

> Engine crash అయినా సుమారు 3 సెకన్లలో standby తీసుకుంటుంది, ఒక్క event కూడా పోదు. Production లో ఇది Kafka consumer group లాగా పని చేస్తుంది.

### 12.6 AI component card

- Status badge: **up** / **DOWN · safe mode**
- Stats: **inferences, anomalies raised, predictions, RCA runs**
- **Alarm-rate model**: alarms/s, z-score, STORM గుర్తు
- **Models**: వాడుతున్న ML models
- **Active anomalies**: entity, feature, z-score
- **Active predictions**: metric, ప్రస్తుత dBm, dB/min slope, threshold దాటడానికి సమయం, probability
- **Circuit breakers**: device వారీగా state (all closed = అన్నీ బాగున్నాయి)
- **Dead-letter queue**: parse కాని malformed messages (empty = సమస్య లేదు)

---

## 13. Trends & KPIs tab: business value

👉 **Trends & KPIs** tab తెరవండి.

### 13.1 KPI comparison table

> నాలుగు metrics, మూడు columns: **Rule-based NOC (days 1–15)**, **AI closed loop (days 16–30)**, **This live session**.

- **Mean time to detect**
- **Mean time to resolve** (live లో autonomous vs human విడివిడిగా)
- **Alarms per ticket / incident**
- **Resolved without a human** %

> నిజాయితీగా చెప్పాలి: history columns లో ఉన్నది 30 రోజుల synthetic seed data (SQLite లో). Live column మాత్రం ఈ డెమోలో
> నిజంగా measure చేసినది, simulator వల్ల సమయం compress అయి ఉంటుంది. Pilot లో నిజమైన NOC data తో ఇదే comparison చేస్తాం.

### 13.2 Live charts (పై వరుస)

- **Ingest rate vs alarm rate (per second)**: messages ingested/s vs new alarms/s. Storm drill తర్వాత spike కనిపిస్తుంది.
- **Ingestion queue depth**: queue ఎంత నిండిందో, మళ్ళీ ఎలా ఖాళీ అయిందో.
- **Active alarms vs open incidents**: alarms లైన్ పైకి వెళ్ళినా incidents లైన్ తక్కువగానే ఉంటుంది. Compression ని ఇది visual గా చూపిస్తుంది.

### 13.3 History bar charts

ఐదు charts, ప్రతి రోజుకి ఒక bar. **నారింజ = Rule-based NOC**, **నీలం = AI closed loop**:

- Mean time to resolve per day (min)
- Mean time to detect per day (min)
- Raw alarms per ticket/incident
- Incidents resolved without a human (%)
- Raw alarms per day

> Day 16 నుంచి నీలం bars కి మారిన తర్వాత MTTR, MTTD పడిపోవడం, autonomous % పెరగడం స్పష్టంగా కనిపిస్తుంది. Raw alarms per day మారదు:
> network మారలేదు, మనం వాటిని handle చేసే విధానం మాత్రమే మారింది.

---

## 14. ముగింపు (30 సెకన్లు)

> సారాంశంగా, ఈ PoC లో మనం చూసింది:
> 1. **Correlation**: 15 alarms ఒకే incident గా, G.702 మరియు GPON రెండు domains కలిపి.
> 2. **Root cause**: alarm పంపలేని passive fibre ని కూడా సరిగ్గా గుర్తించడం.
> 3. **Closed loop**: policy ఆధారంగా advisory / supervised / autonomous actions, ప్రతి action తర్వాత telemetry తో verification.
> 4. **Safe escalation**: guardrails దాటితే లేదా verification fail అయితే మనిషికి పూర్తి context తో.
> 5. **Prediction**: alarm రాక ముందే fault గుర్తించడం.
> 6. **Resilience**: alarm storm, duplicates, engine crash, AI outage, device unreachable అన్నింటిలో ఒక్క event కూడా పోకుండా.
>
> ధన్యవాదాలు. ప్రశ్నలు అడగండి.

---

## అనుబంధం A: సమయం తక్కువగా ఉంటే (5 నిమిషాల version)

1. Reset all → **Cascading fibre cut** → incident తెరిచి RCA, Impact, Decision చూపించి **Approve** (2 నిమిషాలు)
2. Closed loop tab → **E1 timing slips** → autonomous resolve (1 నిమిషం)
3. **PON optics degradation** → escalation callout (1 నిమిషం)
4. Autonomy & resilience → **Correlation engine failover** drill (1 నిమిషం)

లేదా **▶ Guided demo** నొక్కి, scenarios వస్తున్న కొద్దీ వివరిస్తూ వెళ్ళండి (సుమారు 2.5 నిమిషాలు run అవుతుంది; చివర్లో engine crash కూడా ఉంటుంది). తర్వాత open incidents ని approve / resolve చేయండి.

## అనుబంధం B: Audience సాధారణంగా అడిగే ప్రశ్నలు

- **"ఇది నిజమైన network పై పని చేస్తుందా?"** ఇప్పుడు simulated. Real devices కి SNMP / syslog / NETCONF / OMCI adapters కలపాలి; ingestion, correlation, closed loop అలాగే ఉంటాయి.
- **"AI తప్పు చేస్తే?"** Guardrails: risk, blast radius, RCA confidence, rate limit. ప్రతి action తర్వాత verification, fail అయితే escalate. Rollback steps playbooks లో ఉన్నాయి.
- **"AI down అయితే?"** Safe mode: rule-based correlation కొనసాగుతుంది, actions advisory కి పరిమితం (drill లో చూపించాం).
- **"History numbers నిజమేనా?"** కాదు, అవి synthetic seed data. Live session numbers మాత్రమే measure చేసినవి.

## అనుబంధం C: డెమోలో సమస్యలు వస్తే

| సమస్య | పరిష్కారం |
|---|---|
| Scenario నొక్కినా ఏమీ రాలేదు | ~4 సెకన్లు ఆగండి (hold-down). System activity చూడండి. ముందటి fault ఉంటే **Repair network**. |
| Prediction రాలేదు | 20–40 సెకన్లు telemetry కావాలి; AI online గా ఉండాలి (AI outage drill off చేయండి). |
| వింత correlations | **background noise** off చేయండి; **show simulator ground truth** తో check చేయండి. |
| "Backend not reachable" | `./run_backend.sh` మళ్ళీ run చేయండి; page తనంతట తానే reconnect అవుతుంది. |
