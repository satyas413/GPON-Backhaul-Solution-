# వేర్వేరు Domains (GPON, G.702/E1/E3, CES, BSC, IP) ని ఎలా Simulate చేశాం — తెలుగులో

> Source files: `backend/config/topology.yaml`, `backend/config/alarm_catalog.yaml`, `backend/app/simulator.py`,
> `backend/app/sources.py`, scenarios కోసం `backend/app/runtime.py`. ఇక్కడ చెప్పిన ప్రతి విషయం ఈ files లోని code నుంచే.

---

## 1. Core idea: ఒకే simulator, నాలుగు layers

ప్రతి domain కి వేరు వేరు simulator రాయలేదు. **ఒకే generic engine** (`NetworkSim`) ఉంది. Domain తేడాలు నాలుగు చోట్ల మాత్రమే ఉంటాయి:

| Layer | ఎక్కడ | Domain ఎలా వస్తుంది |
|---|---|---|
| 1. **Structure** | `topology.yaml` | ప్రతి entity కి `class`, `domain` (gpon / g702 / ip / service), `layer`, `depends_on` |
| 2. **Behaviour (ఎవరు ఏ alarm పంపుతారు)** | `simulator.py` → `_expected_alarms()` | Class వారీగా observer rules |
| 3. **Numbers (telemetry)** | `simulator.py` → `telemetry()` | Domain వారీగా PM counters (Rx power, BER, slips, jitter-buffer underruns...) |
| 4. **Wire format (ఎలా పంపుతారు)** | `sources.py` → `render()` | OLT → SNMP, CES/Mux/IP → syslog, BSC/NMS/SA → event stream |

అంటే కొత్త domain కలపాలంటే: YAML లో classes, ఒక alarm rule block, అవసరమైతే telemetry metrics, ఒక reporter → source mapping. అంతే.

---

## 2. Step 1 — `topology.yaml`: ప్రతి domain ని entities గా model చేయడం

`ontology.classes` లో ప్రతి class కి properties:

```yaml
OLT:          {layer: access, kind: device,  domain: gpon, policy_class: OLT,  observable: true}
Splitter:     {layer: access, kind: passive, domain: gpon, policy_class: ODN,  observable: false}
FiberSegment: {layer: access, kind: link,    domain: gpon, policy_class: ODN,  observable: false}
E1Circuit:    {layer: access, kind: link,    domain: g702, policy_class: G702, observable: true}
Pseudowire:   {layer: core,   kind: logical, domain: g702, policy_class: G702, observable: true}
CESGateway:   {layer: core,   kind: device,  domain: g702, policy_class: G702, observable: true}
G702Mux:      {layer: aggregation, kind: device, domain: g702, ...}   # E1 2048 kbit/s → E3 34368 kbit/s
BSC:          {layer: core,   kind: device,  domain: g702, ...}
```

**`observable: false`** అనేది కీలకం: splitter, fibre, BTS తమంతట తాము alarm పంపలేవు — real life లో లాగే.

### Domain వారీగా instances

**GPON (access):**
```
OLT-A ─► PON-A1 ─► F-A1 (feeder, 3.8 km) ─► SPL-A1 (2:8, Type-B) ─► D-A1-1 (drop) ─► ONT-A1-1
                └► F-A1P (standby feeder) ┘
```
- `SPL-A1` కి `protection: {type: GPON Type-B, working: F-A1, standby: F-A1P}`.
- మొత్తం: 2 OLTs, 6 PON ports, 4 splitters, 21 fibre segments (feeder + drop + standby), cell-site / enterprise ONTs.

**G.702 over GPON (CES — circuit emulation):**
```
ONT-A1-1 ─► E1-101 (2048 kbit/s, G.704, adaptive clock recovery) ─► BTS-101
E1-101 + CESGW-1 ─► PW-101 (CESoPSN RFC 5086, jitter buffer 8 ms)
CESGW-1 ─► STM1-BSC1 (155.52 Mbit/s channelized, 63×E1) ─► BSC-1
```
అంటే 2G BTS యొక్క E1, ONT లోని CES port ద్వారా packets గా మారి, pseudowire లో CES gateway కి వెళ్ళి, మళ్ళీ E1 గా STM-1 మీద BSC కి చేరుతుంది.

**Legacy G.702 PDH (microwave):**
```
CESGW-1 ─► E3-MUX1 (34368 kbit/s) ─► MUX-1 (PDH-34, 16×E1 → E3) ─► E1-301 / E1-302 (microwave PDH, loop-timed) ─► BTS-301/302
```

**IP / Ethernet:** OLT → `EthernetUplink` (10GE) → AggregationSwitch → `CoreLink` (100GE) → CoreRouter.

**Services (end-to-end):** ఒక service తన path లోని ప్రతి element మీద depend అవుతుంది:
```yaml
- id: SVC-2G-101
  class: MobileBackhaulService
  depends_on: [BTS-101, PW-101, BSC-1]
  meta: {tech: 2G, sla: 99.99%, subscribers: 1607}
```
అదనంగా 4G `EthernetBackhaulService` మరియు `EnterpriseService` (L2VPN) ఉన్నాయి.

**Rule:** `depends_on` ఎప్పుడూ **upstream** (core వైపు) చూపుతుంది. ఈ ఒక్క rule తో అన్ని domains ఒకే graph లో కలిసిపోతాయి — GPON fibre cut, G.702 E1 ని, pseudowire ని, BSC Abis link ని, 2G service ని ఒకేసారి పడగొడుతుంది.

---

## 3. Step 2 — Faults inject చేయడం

`simulator.py`:
```python
DOWN_FAULTS    = {"cut", "fail", "power"}
DEGRADE_FAULTS = {"optics_degraded", "timing", "rx_drift"}
```

| Fault | Domain | ఉదాహరణ (runtime.py scenarios) |
|---|---|---|
| `cut` | GPON fibre / IP link | `sim.inject("F-A1", "cut")`, `sim.inject("UL-OLTA-AGG1", "cut")` |
| `fail` | ఏ device/port అయినా; PDH fade | noise: `E1-301` fail 3–6 s |
| `power` | ONT | noise: enterprise ONT power loss 6–12 s (dying gasp) |
| `timing` | G.702 E1 | `sim.inject("E1-102", "timing")` |
| `optics_degraded` | GPON PON port | `sim.inject("PON-B2", "optics_degraded", recoverable=False)` |
| `rx_drift` | GPON ONT | `sim.inject("ONT-B1-3", "rx_drift", rate_db_per_s=0.085)` |

`rx_drift` ప్రత్యేకం: Rx power సమయంతో పడిపోతుంది (`base − rate × elapsed`). −27 dBm (class B+ sensitivity) కంటే తక్కువైతే `degraded`, −29.5 dBm కంటే తక్కువైతే `down`. అందుకే AI ముందుగా predict చేయగలుగుతుంది.

అదనంగా `mgmt_unreachable` set: device పని చేస్తుంది కానీ దాని **management plane** reach కాదు (OLT-B drill).

---

## 4. Step 3 — Status propagation (`_recompute`)

ప్రతి 0.5 s tick లో, ప్రతి entity కి status `up / degraded / down` compute అవుతుంది:

```python
best = self._own(eid) or ("up", None, None)          # నా సొంత fault
for p in depends_on:                                    # నా parents
    if rank[parent_status] > rank[best]: best = parent_status   # worst wins
```

Status tuple లో `(state, origin, fault_type)` ఉంటాయి — **origin** అంటే fault నిజంగా ఎక్కడ ఉందో. ఇది తదుపరి step లో "నా సొంత fault ఆ, లేక upstream నుంచి వచ్చిందా" అని తేల్చడానికి.

F-A1 cut అయితే: F-A1 down → SPL-A1 → drops → ONTs → E1-101/102 → BTS, PW-101/102 → 2G/4G/enterprise services — అన్నీ `down`, origin = F-A1.

---

## 5. Step 4 — Domain-specific alarm rules (`_expected_alarms`) — ఇదే హృదయం

ఇది **observer model**: "ఈ status లో, real network లో ఏ device ఏ alarm పంపుతుంది?" Class వారీగా rules:

### GPON

| Situation | Reporter | Alarm |
|---|---|---|
| PON port తానే down | OLT | `PON_PORT_FAIL` |
| PON port తానే degraded | OLT | `PON_BER_SD` with `tx_bias=high` |
| Port up, కానీ active feeder down (లేదా splitter down) | OLT | `PON_LOS` with `laser_tx=ok` |
| Port up, standby feeder down | OLT | `PON_PROTECTION_UNAVAILABLE` |
| ONT down, సొంత power fault | OLT | `ONT_DYING_GASP` |
| ONT down, upstream వల్ల | OLT | `ONT_LOSi` |
| ONT సొంత rx_drift | OLT | `ONT_RX_POWER_LOW` |
| ONT degraded (upstream optics) | OLT | `ONT_SDi` |

**ముఖ్య గమనిక:** Fibre, splitter కి ఏ rule లేదు — అవి ఎప్పుడూ alarm పంపవు. `laser_tx=ok` detail మాత్రమే "port laser బాగుంది, సమస్య బయట fibre లో" అనే clue ఇస్తుంది. `alarm_catalog.yaml` లో:
```yaml
PON_LOS: {implicates: {FiberSegment: 0.8, Splitter: 0.45, PONPort: 0.5},
          when: [{detail: {laser_tx: ok}, implicates: {FiberSegment: 1.0, Splitter: 0.45, PONPort: 0.2}}]}
```
ఇలాగే AI silent fibre ని root cause గా పట్టుకుంటుంది.

### G.702 / E1 / CES

E1 head (`a` endpoint) ఎవరో బట్టి రెండు రకాలు:

**E1 over GPON (head = ONT, CES):**

| Situation | Reporter | Alarm |
|---|---|---|
| E1 తానే down | OLT (OMCI CES PM ద్వారా) | `E1_LOS` |
| E1 down, upstream వల్ల | CESGW-1 | `E1_AIS` (all-ones = "upstream failed") |
| E1 సొంత timing fault | OLT | `E1_FRAME_SLIP` (`slips_per_15min=40`, G.822) |
| E1 degraded, ఇతర కారణం | CESGW-1 | `E1_ERRORED_SECONDS` (G.826) |

**E1 over PDH (head = MUX-1):** down → MUX-1 `E1_LOS`; degraded → `E1_ERRORED_SECONDS`.

**Pseudowire:** CESGW-1 → down అయితే `PW_DOWN`, degraded అయితే `PW_JITTER_BUFFER_UNDERRUN`.

### BSC / Services

| Service class | Reporter | Down | Degraded |
|---|---|---|---|
| `MobileBackhaulService` (2G Abis) | BSC-1 | `ABIS_LINK_DOWN` | `CALL_DROP_RATE_HIGH` |
| 4G / Enterprise | `SA` (service assurance) | `SERVICE_SLA_BREACH` | `SERVICE_DEGRADED` |

### IP / Equipment

| Situation | Reporter | Alarm |
|---|---|---|
| Uplink / core link / STM-1 / E3 trunk సొంత fault | link యొక్క `a` end device | `LINK_DOWN` |
| OLT down | `NMS` | `NE_UNREACHABLE` |
| Agg switch / core router / CES GW / Mux / BSC సొంత fault | `NMS` | `NE_UNREACHABLE` |

### "Dead device cannot speak" rule

```python
def add(reporter, entity, atype, **detail):
    if reporter not in VIRTUAL_REPORTERS and not self.is_up(reporter):
        return          # reporter తానే down → alarm పంపలేడు
```
OLT పడిపోతే దాని కింద ONT alarms రావు; NMS (virtual reporter) మాత్రమే `NE_UNREACHABLE` పంపుతుంది. Real network లో సరిగ్గా ఇలాగే జరుగుతుంది.

### Raise / clear

`tick()` expected alarms ని previous active set తో compare చేస్తుంది: కొత్తవి → `raise`, పోయినవి → `clear`. ప్రతి event కి `id` (UUID), `reporter`, `entity`, `type`, catalog నుంచి `severity`, `ts`, reporter వారీగా `seq`, `detail`, `source`.

---

## 6. Step 5 — Domain-specific telemetry (`telemetry()`, ప్రతి 2 s)

Healthy values Gaussian / Poisson random; fault ఉంటే distribution మారుతుంది.

| Producer | Entity | Metrics | Healthy | Fault ఉంటే |
|---|---|---|---|---|
| OLT | OLT | `cpu_pct`, `temp_c` | ~22 %, ~48 °C | — |
| OLT | PON port | `us_ber`, `tx_bias_ma`, `util_pct` | BER ~1e-11, bias ~28 mA | optics_degraded: BER ~1e-5.3, bias ~52 mA |
| OLT | ONT | `rx_power_dbm`, `temp_c`, `us_ber` | −17.5 … −21 dBm (ONT కి fixed base) | rx_drift: క్రమంగా పడిపోతుంది |
| OLT (OMCI CES PM) | E1 | `es`, `ses`, `slips` (Poisson) | దాదాపు 0 | timing: slips ~7, ES ~9 |
| CESGW-1 | Pseudowire | `jb_underruns`, `loss_pct` | ~0 | timing: underruns ~14; optics: loss ~0.9 % |

`normal_samples()` ఇదే healthy distribution నుంచి 3,000 samples ఇస్తుంది — IsolationForest training కి. కాబట్టి AI "normal" ఏమిటో ఈ simulator నుంచే నేర్చుకుంటుంది.

---

## 7. Step 6 — Wire formats (`sources.py`): domain బట్టి protocol

```python
REPORTER_SOURCE   = {"OLT": "snmp", "CESGateway": "syslog", "G702Mux": "syslog",
                     "AggregationSwitch": "syslog", "CoreRouter": "syslog", "BSC": "stream"}
VIRTUAL_REPORTERS = {"NMS": "stream", "SA": "stream"}
```

**GPON OLT → SNMP v2c trap** (trap receiver decode చేసిన dict రూపంలో):
```json
{"version":"v2c","agent":"OLT-A","community":"public",
 "trap_oid":"1.3.6.1.4.1.64999.2.0.1",
 "varbinds":{"gponAlarmEntity":"PON-A1","gponAlarmType":"PON_LOS","gponAlarmSeverity":1,
             "gponAlarmState":1,"gponAlarmTime":"...","gponAlarmSeq":17,"gponAlarmDetail.laser_tx":"ok"}}
```
Private enterprise OID `64999`; 12 GPON/E1 alarm types కి ఒక్కొక్క trap OID.

**CES gateway / PDH mux / IP → RFC 5424 syslog** (facility local0):
```
<131>1 2026-10-20T12:00:00.123Z CESGW-1 fmd - PW_DOWN [alarm@64999 id="..." entity="PW-101" state="raise" severity="major" seq="5"] PW_DOWN raised on PW-101
```

**BSC / NMS / Service assurance → JSON event stream** (Kafka-style):
```json
{"event_id":"...","producer":"BSC-1","type":"ABIS_LINK_DOWN","entity":"SVC-2G-101",
 "state":"raise","severity":"critical","event_time":"...","seq":3,"attributes":{}}
```

**Telemetry → batched samples** (gNMI / PM-file style): `{"producer":"OLT-A","ts":...,"samples":[{entity, metrics}, ...]}`.

అందుకే ఒక fibre cut లో ~15 alarms **మూడు వేర్వేరు systems నుంచి, మూడు formats లో** వస్తాయి — ingestion మరియు correlation నిజమైన పని చేయాలి.

---

## 8. Step 7 — Real-world imperfections కావాలనే కలపడం

| Imperfection | ఎలా | ఎందుకు |
|---|---|---|
| Out-of-order delivery | `SourceClient.send` లో `network_jitter_s: 0.35` random delay | Re-order buffer పని చూపించడానికి |
| Duplicate traps | `trap_retransmit_ratio: 0.06` — 6 % SNMP traps మళ్ళీ పంపడం | De-dup పని చూపించడానికి |
| Background noise | ప్రతి 12–25 s: 45 % enterprise ONT power loss (dying gasp), 30 % PDH microwave fade (E1-301/302), 25 % AGG CPU spike (`HIGH_CPU`) | Real NOC లాగా; correlation వీటిని వేరే incidents గా ఉంచాలి |
| Retry / backpressure | Gateway reject చేస్తే exponential backoff + full jitter | Ingestion fault tolerance |
| Stale telemetry | 5 s కంటే పాత samples drop (latest-value-wins) | Backlog తర్వాత పాత PM replay కాకుండా |

---

## 9. Step 8 — Actions network ని ఎలా మారుస్తాయి (`apply_action`)

Closed loop యొక్క "act" ఇక్కడ domain-specific effect పొందుతుంది:

| Action | Domain | Simulator లో effect |
|---|---|---|
| `pon_protection_switch` | GPON | Splitter `depends_on` ని working → standby feeder కి మార్చుతుంది (Type-B) |
| `pon_protection_revert` | GPON | Working feeder కి తిరిగి |
| `pon_optics_recalibrate` | GPON | Recoverable అయితే fix; లేకపోతే 2.5 s మాత్రమే improve, తర్వాత **relapse** (escalation scenario) |
| `pon_port_migrate` | GPON | Feeders ని అదే OLT లోని spare PON port కి |
| `ont_reboot` | GPON (OMCI) | Soft fail అయితే fix |
| `e1_timing_relock` | G.702 | Timing fault repair (clock source re-select, ACR, jitter buffer re-centre) |
| `pw_reset` | CES | Pseudowire re-signal; E1 timing fault repair |
| `dispatch_field_cleaning` | Field | 5 s తర్వాత field fix (simulator లో compressed time) |
| `uplink_reroute` | IP | ఎప్పుడూ fail — secondary uplink లేదు (advisory/failure demo) |
| `open_ticket`, `watch` | — | Network మార్పు లేదు |

Action తర్వాత next tick లో status మళ్ళీ compute అవుతుంది → alarms `clear` events గా అదే pipeline ద్వారా వస్తాయి → closed loop వాటిని, fresh telemetry ని చూసి verify చేస్తుంది.

---

## 10. Honesty boundary

- **Ground truth (`faults`) ని analysis ఎప్పుడూ చదవదు.** `truth_onset()` కేవలం MTTD/MTTR measure చేయడానికి.
- Ingestion తర్వాత ఉన్న code అంతా raw SNMP / syslog / JSON / telemetry మాత్రమే చూస్తుంది — real equipment తో లాగే.
- పరిమితులు: SNMP traps raw BER/UDP కాకుండా decoded dicts గా వస్తాయి; syslog కి మాత్రం real UDP listener (:5514) ఉంది. Device actions (NETCONF, OMCI, TL1) simulator మీద మాత్రమే పని చేస్తాయి.

---

## 11. ఒక్క వాక్యంలో

**Topology YAML domains ని నిర్వచిస్తుంది, `_recompute` faults ని domains దాటి propagate చేస్తుంది, `_expected_alarms` ప్రతి domain లోని real device ఏం report చేస్తుందో నిర్ణయిస్తుంది, `telemetry()` domain-specific counters ఇస్తుంది, `sources.render` ప్రతి domain ని దాని native protocol లో పంపుతుంది.**
