# G.702 + GPON backhaul ontology

The topology is defined in [`backend/config/topology.yaml`](../backend/config/topology.yaml): an `ontology`
section (classes, layers, relationships) followed by the instances (`devices`, `links`, `services`).
Every instance is a first-class entity with an id, a class, attributes and `depends_on` edges.

## Layers

| Layer | Contents |
|---|---|
| core | core routers, CES gateway (TDM interworking), BSC, core links, channelized STM-1, pseudowires |
| aggregation | aggregation switches, OLT uplinks, G.702 PDH multiplexer and its E3 trunk |
| access | OLTs, PON ports, feeder/drop fibre, splitters, ONTs, cell-site BTS and their E1 circuits |
| service | 2G Abis backhaul, 4G Ethernet backhaul and enterprise L2VPN services |

## Entity classes

| Class | Kind | Domain | Policy class | Role in the backhaul path |
|---|---|---|---|---|
| CoreRouter | device | ip | Core | IP/MPLS core |
| CESGateway | device | g702 | G702 | Terminates CESoPSN pseudowires, hands E1s to the BSC over channelized STM-1 |
| BSC | device | g702 | G702 | 2G controller terminating Abis E1s |
| AggregationSwitch | device | ip | Aggregation | Metro aggregation for OLT uplinks |
| G702Mux | device | g702 | G702 | PDH mux, E1 (2048 kbit/s) → E3 (34368 kbit/s) per ITU-T G.702 |
| OLT | device | gpon | OLT | GPON optical line terminal |
| PONPort | port | gpon | OLT | GPON port (G.984), contained in an OLT |
| Splitter | passive | gpon | ODN | Passive splitter; **cannot alarm**, inferred from its children |
| ONT | device | gpon | ONT | Cell-site ONTs carry E1 CES ports; others carry Ethernet |
| BTS | device | g702 | G702 | 2G base station with G.703/G.704 E1 Abis interface |
| CoreLink / EthernetUplink / STM1Link / E3Trunk | link | ip / g702 | Core / Aggregation / G702 | Transport links |
| FiberSegment | link | gpon | ODN | Feeder or drop fibre; **passive** |
| E1Circuit | link | g702 | G702 | G.702 primary-rate circuit, G.704 framing |
| Pseudowire | logical | g702 | G702 | CESoPSN pseudowire carrying one E1 across GPON + IP |
| Mobile/Ethernet/EnterpriseService | service | service | Service | End-to-end services with SLA and subscriber counts |

`observable` marks whether a class can report alarms. RCA uses it to tell "silent because broken" from
"silent because it never reports".

## Relationships

* **depends_on**: child → parent (upstream). A child is down when any required parent is down, and
  degradations (BER, timing) propagate the same way.
* **contained_in**: PON port → OLT, modelled as `depends_on`.
* **connects**: links carry `a` (upstream end) and `b` (downstream end) endpoints.
* **carries**: a service depends on every device, link and pseudowire on its end-to-end path
  (for 2G: BTS ← E1 ← ONT ← drop ← splitter ← feeder ← PON port ← OLT ← uplink ← AGG ← core ← CES GW ← STM-1 ← BSC).
* **protects**: splitter SPL-A1 has a GPON **Type-B** protection group: working feeder F-A1 from PON-A1,
  standby feeder F-A1P from PON-A1P. A switchover re-points the splitter's `depends_on`, which the topology
  view shows by swapping the dashed and solid feeders.

## Instance summary

* 2 core routers, 1 CES gateway, 1 BSC, 2 aggregation switches, 1 PDH mux
* 2 OLTs, 6 PON ports (incl. one Type-B standby and one spare), 4 splitters, 16 ONTs
* 8 cell sites: 6 over GPON with CESoPSN E1s, 2 legacy over the PDH mux (microwave E1 → E3)
* 19 services (8 × 2G Abis, 6 × 4G Ethernet backhaul, 5 × enterprise L2VPN)

## How analysis uses the graph

* **Impact** = all descendants of an entity; services, cell sites and subscribers are summed from them.
* **Correlation affinity** (`Topology.affinity`): 1/(1 + 0.1·d) when one entity is upstream of the other;
  0.9^(d1+d2) through the nearest shared-risk ancestor (splitter, feeder, PON port). Sharing an OLT chassis,
  aggregation switch or the core does not count, so independent faults on different PON trees stay separate.
* **RCA candidates** are the alarmed entities plus all their ancestors, which is how a silent fibre or
  splitter can be named as root cause.
* **Manager resolution** (`manager_of`) gives the element that executes an action: ONT and E1 actions go to
  the OLT (OMCI), pseudowire actions to the CES gateway, fibre/splitter actions to the OLT owning the
  protection group.

## Alarm catalogue

[`alarm_catalog.yaml`](../backend/config/alarm_catalog.yaml) normalises 24 alarm types (G.984.3 PON alarms,
G.775/G.822/G.826 E1 alarms, CESoPSN pseudowire alarms, BSC and service-assurance events, NMS/IP alarms and
the AI-derived `AI_ANOMALY` / `PREDICTED_FAULT`), each with category, default severity and the RCA evidence
weights described in [AI logic](AI_LOGIC.md).

## Standards alignment

Every class is mapped to OpenConfig, BBF TR-383 / TR-385, ITU-T G.709 and RFC 8345 in
[`standards.yaml`](../backend/config/standards.yaml), and every entity carries the result as `std` (shown in the
dashboard's entity panel). PON ports become TR-385 channel-pair / channel-termination interfaces, each splitter's
ODN tree a channel-group / channel-partition, each ONT a v-ani / ani pair with v-enets, T-CONTs and GEM ports, and
the inter-site core links carry 100GBASE-R over a G.709 OPU4 / ODU4 / OTU4 server layer (`otn:` in topology.yaml).
The backend exports TR-385, OpenConfig and RFC 8345 documents that pass a schema check against the published
YANG models. Details, naming, alarm identities and known gaps: [Standards alignment](STANDARDS_ALIGNMENT.md).
