# GPON · G.702 Fault Management PoC — ఎలా Design చేసి Build చేశాం (Step by Step, తెలుగులో)

> ఈ document లో, ఈ PoC ని **requirement చదివిన దగ్గర నుంచి, design decisions, ఒక్కో module build చేసిన order,
> testing, documentation** వరకు మొత్తం ప్రయాణాన్ని step by step గా వివరిస్తున్నాను. Technical terms (OLT, RCA, closed loop,
> asyncio లాంటివి) English లోనే ఉంచాను, ఎందుకంటే presentation లో, code లో అవే పదాలు వాడతాం.
>
> ఇక్కడ చెప్పిన ప్రతి విషయం actual code (`backend/app/*.py`, `frontend/src/`) మరియు docs (`KNOWLEDGE_TRANSFER.md`,
> `ARCHITECTURE.md`, `AI_LOGIC.md`, `CLOSED_LOOP.md`, `FAULT_TOLERANCE.md`, `METRICS.md`) ఆధారంగా రాసింది.

---

## విషయ సూచిక

1. Build timeline ఒక్క చూపులో
2. Step 0: Requirement ని అర్థం చేసుకోవడం
3. Step 1: Requirements ని design goals గా మార్చడం
4. Step 2: Technology stack ఎంచుకోవడం (ఎందుకు ఇవి?)
5. Step 3: Architecture design (components & data flow)
6. Step 4: "Behaviour YAML లో, mechanics Python లో" — configuration-first design
7. Step 5: Module build order — ఒక్కో module ఎందుకు, ఏం చేస్తుంది
   - 5.1 ontology.py — Network model
   - 5.2 simulator.py — Fake network
   - 5.3 sources.py — Wire formats
   - 5.4 ingestion.py — Front door
   - 5.5 history.py — Memory (SQLite)
   - 5.6 enrichment.py — Context
   - 5.7 ai.py — ML models & RCA
   - 5.8 correlation.py — Incident engine + failover
   - 5.9 closed_loop.py — Decide, act, verify
   - 5.10 runtime.py + main.py — Wiring & API
   - 5.11 Frontend (React + Vite)
8. Step 6: Demo scenarios & fault-tolerance drills design
9. Step 7: Verification (17 checks) & bugs fix చేయడం
10. Step 8: Documentation, run scripts, packaging
11. ఒక fault ని మొదటి నుంచి చివరి వరకు follow చేయడం (summary)
12. Honest limits & production కి path
13. ఈ approach నుంచి నేర్చుకోవాల్సిన key lessons

---

## 1. Build timeline ఒక్క చూపులో

మొత్తం PoC 2026-10-20 న ఒకే session లో build అయింది. Original build thread లోని progress checklist ఈ order చూపిస్తుంది:

| # | Step | ఏం జరిగింది |
|---|---|---|
| 1 | Toolchain check | Python 3.13, Node 22, pip/npm reach అవుతున్నాయా చూశాం |
| 2 | Topology model + simulator | `topology.yaml`, `ontology.py`, `simulator.py` |
| 3 | Ingestion + history store | `sources.py`, `ingestion.py`, `history.py` |
| 4 | AI + correlation (active/standby) + closed loop | `ai.py`, `enrichment.py`, `correlation.py`, `closed_loop.py` |
| 5 | API, scenarios, drills wiring | `runtime.py`, `main.py`, `verify_demo.py` → **17/17 pass** |
| 6 | React dashboard | `frontend/src/` — clean build |
| 7 | Full end-to-end run | ఇక్కడ ఒక **safe-mode correlation edge case** bug దొరికింది, fix చేశాం, మళ్ళీ 17/17 |
| 8 | Screenshots | ప్రతి view కి screenshot (`docs/screenshots/`) |
| 9 | Docs + run scripts | README + 6 design docs, `run_backend.sh/.ps1`, `run_frontend.sh/.ps1` |
| 10 | Clean install test | Fresh venv + `npm install` తో మొదటి నుంచి start అవుతుందని verify చేశాం |

Size idea కోసం: backend Python ≈ **3,000 lines** (11 files), frontend JSX ≈ **1,000 lines**, topology లో **105 entities**.

**ముఖ్యమైన order logic:** ముందు *data model* (topology), తర్వాత *data source* (simulator), తర్వాత *pipeline* (ingestion),
తర్వాత *intelligence* (AI, correlation, closed loop), తర్వాత *API*, ఆఖరిలో *UI*. UI కంటే ముందే API ద్వారా test script
(`verify_demo.py`) 17/17 pass అయ్యేలా చూశాం — అంటే logic correct అని తెలిసిన తర్వాతే screen కట్టాం.

---

## 2. Step 0: Requirement ని అర్థం చేసుకోవడం

Satya ఇచ్చిన requirement పెద్దది. దాన్ని చదివి, ముందుగా **"ఏది must, ఏది nice-to-have"** అని విడదీశాను.

### 2.1 Requirement లో ఉన్న ముఖ్య అంశాలు

| Requirement భాగం | నేను అర్థం చేసుకున్నది |
|---|---|
| **G.702 + GPON backhaul ontology** | OLT, PON port, feeder fibre, splitter, drop fibre, ONT, E1, E3/PDH mux, pseudowire (CES), BSC — అన్నీ **first-class entities**. ప్రతి దానికి parent-child / depends-on relationship ఉండాలి. Access → Aggregation → Core layers. |
| **Alarms, correlation, RCA, impact అన్నీ topology మీద పని చేయాలి** | Topology ని ఒక graph గా పెట్టాలి; ప్రతి algorithm ఆ graph ని వాడాలి. |
| **Fault detection & categorization** | Severity, type, source, network layer — ప్రతి alarm normalise అవ్వాలి. |
| **Correlation & de-duplication** | ఒక fault వల్ల వచ్చే 15 alarms → **ఒక్క incident**. |
| **RCA + impact assessment** | నిజంగా ఏది పాడైందో, ఎవరెవరికి impact అయ్యిందో. |
| **MTTD / MTTR** | Measure చేయాలి, తగ్గినట్టు చూపించాలి. |
| **Alert enrichment** | Topology context, device metadata, historical data. |
| **Closed loop: detect → analyze → decide → act → verify** | Action తర్వాత **post-action telemetry** తో verify; fail అయితే లేదా autonomy boundary దాటితే **human కి escalate**. |
| **Autonomy level configurable** | advisory / supervised / autonomous — **per device class × per fault type**. |
| **Fault tolerance** | Ingestion backpressure & retry, duplicate & out-of-order events, correlation engine failover, AI down / device unreachable అయినప్పుడు safe mode. కనీసం ఒక్కటైనా demo లో చూపించాలి. |
| **Data sources** | SNMP traps, syslog, event streams, OLT/G.702 management telemetry. |
| **AI component** | Anomaly detection, correlation, fault prediction, remediation suggest/auto-execute. |
| **Dashboard** | Real-time alarm feed, topology view, incidents, RCA, closed-loop status, autonomy controls, fault-tolerance indicators, trends & KPIs. |
| **Demo dataset** | కనీసం: ఒక **cascading failure**, ఒక **autonomous fix**, ఒక **escalation**. |
| **No Docker** | Python venv + npm మాత్రమే. |
| **Outcome** | Stakeholder తన laptop లో run చేసి, click చేసి, వెంటనే అర్థం చేసుకోగలగాలి. |

### 2.2 Requirement నుంచి నేను తీసుకున్న మూడు key insights

1. **"Stakeholder laptop లో run చేయాలి"** → అంటే real OLTs, real Kafka, real Kubernetes లేవు. కాబట్టి network ని **simulate**
   చేయాలి, infrastructure లేకుండా ఒకే command తో start అవ్వాలి.
2. **"Topology-aware" అనేది హృదయం** → Rule-based systems కంటే మనం గొప్పగా చూపించాల్సిన విషయం: **alarm పంపలేని passive
   element (fibre, splitter) ని కూడా root cause గా కనిపెట్టడం.** అందుకే ontology ని ముందు, బలంగా design చేశాను.
3. **"Fault tolerance demo లో చూపించాలి"** → ప్రతి degradation mode కి ఒక **button (drill)** ఉండాలి, అది నొక్కితే effect
   కనిపించాలి. అందుకే queue size, processing rate లాంటి numbers ని కావాలని చిన్నగా పెట్టాం (effect కనిపించడానికి).

---

## 3. Step 1: Requirements ని design goals గా మార్చడం

Requirement ని ఈ **design principles** గా మార్చాను. Code మొత్తం వీటిని follow చేస్తుంది:

| # | Design principle | ఎందుకు | Code లో ఎక్కడ |
|---|---|---|---|
| P1 | **Simulator raw messages ద్వారానే మాట్లాడాలి** | Ingestion తర్వాత ఉన్న logic మొత్తం "real" — అది simulator తో మాట్లాడుతోందని దానికి తెలియదు. Real network కి మారినప్పుడు simulator తీసేస్తే చాలు. | `simulator.py` → `sources.py` (SNMP dict / syslog line / JSON) → `ingestion.py` |
| P2 | **Topology ఒక్కటే source of truth** | Correlation, RCA, impact, enrichment, layout — అన్నీ ఒకే graph నుంచి. | `topology.yaml` + `ontology.py` |
| P3 | **Behaviour YAML లో, mechanics Python లో, presentation React లో** | Product person అడిగే మార్పులు చాలావరకు YAML edit తో అయిపోతాయి. | `backend/config/*.yaml` |
| P4 | **ప్రతి AI call కి deterministic fallback** | AI down అయినా system ఆగకూడదు (safe mode). | `ai.py` `check()` → `AIUnavailable`; callers catch చేస్తారు |
| P5 | **Engine state = ఒక plain JSON dict** | Checkpoint & failover సులభం అవుతుంది. | `correlation.py` `empty_state()` |
| P6 | **Loop state incident లోనే ఉండాలి** | Engine failover అయినా closed loop ఎక్కడ ఆగిందో అక్కడ నుంచి కొనసాగుతుంది. | `incident["loop"]` |
| P7 | **ప్రతి component ని తర్వాత separate service గా deploy చేయగలిగేలా boundaries** | PoC ఒక process అయినా, production design లో తేడా ఉండకూడదు. | `ARCHITECTURE.md` "From PoC process to deployed services" table |
| P8 | **UI కి ఒకే snapshot endpoint** | Frontend simple; backend ఒక్కటే source of truth. | `GET /api/snapshot` (ప్రతి 1 s poll) |
| P9 | **Honest metrics** | KPI కోసం simulator ground truth (fault inject time) వాడతాం, కానీ **analysis కి ఎప్పుడూ వాడం**. | `simulator.truth_onset` — KPI only |

---

## 4. Step 2: Technology stack ఎంచుకోవడం (ఎందుకు ఇవి?)

Requirement "Python, Node.js, or Go" మరియు "React, Vue, or similar" అని choice ఇచ్చింది. Satya ప్రత్యేకంగా ఏదీ చెప్పలేదు,
కాబట్టి ఈ defaults నేను ఎంచుకున్నాను (delivery message లోనూ "మీరు మార్చాలనుకుంటే చెప్పండి" అని చెప్పాను):

| Choice | ఎందుకు |
|---|---|
| **Python 3.10+** | ML (scikit-learn, NumPy) Python లో natural. Telecom automation tooling (pysnmp, ncclient) కూడా Python లో ఉంది. |
| **FastAPI + uvicorn** | Async native — background loops, API ఒకే event loop లో. `/docs` లో free interactive API docs. |
| **asyncio, ఒకే process** | Kafka, Redis, Kubernetes లేకుండా laptop లో run. అన్ని "services" cooperating asyncio tasks. API routes కూడా `async` కాబట్టి thread-safety సమస్యలు లేవు. |
| **In-memory EventLog (Kafka బదులు)** | Offset-addressed append-only list. Interface (`read(offset, n)`) Kafka topic లాగే, కాబట్టి తర్వాత Kafka/Redpanda పెట్టడం సులభం. |
| **SQLite** | History, learned stats, checkpoints. Install అవసరం లేదు, Python లోనే ఉంది. Production లో PostgreSQL/TimescaleDB. |
| **scikit-learn** (IsolationForest, LogisticRegression) | Small, fast, explainable. Startup లో ~1 second లో train అవుతాయి. GPU, heavy deep learning అవసరం లేదు. |
| **PyYAML** | Config files human-readable. |
| **React 18 + Vite** | Fast dev server, simple build. Vite `/api` requests ని `localhost:8000` కి proxy చేస్తుంది. |
| **Recharts** | Trend charts కోసం simple React charting. |
| **Pure SVG topology** | Extra graph library లేకుండా, backend ఇచ్చే `layout()` x/y coordinates తో draw. |
| **No Docker** | Requirement. `run_backend.sh` venv create చేసి packages install చేస్తుంది; `run_frontend.sh` `npm ci` చేస్తుంది. Windows కి `.ps1` scripts. |

`backend/requirements.txt` లో కేవలం 5 packages: `fastapi`, `uvicorn[standard]`, `numpy`, `scikit-learn`, `pyyaml`.
Frontend లో 3 runtime dependencies: `react`, `react-dom`, `recharts`. **Dependencies తక్కువ = install fail అయ్యే chance తక్కువ** —
stakeholder laptop కి ఇది చాలా ముఖ్యం.

---

## 5. Step 3: Architecture design

### 5.1 Data flow (pipeline)

```
 ┌──────────── simulator.py ────────────┐
 │ faults → status propagation → alarms │  + telemetry ప్రతి 2 s, + background noise
 └───────────────┬──────────────────────┘
                 │ raw messages (SNMP trap dict / syslog line / JSON event / telemetry batch)
                 ▼
 sources.py   SourceClient ×4  (buffer, delay jitter, exponential backoff + full jitter తో retry)
                 ▼  submit()
 ingestion.py IngestionGateway: parse → validate (DLQ) → admission control (bounded queue, watermark shedding)
                 ▼
              de-dup (event id) → re-order buffer (1 s, device time) → EventLog (offset-addressed)
                 ▼  read(offset)
 correlation.py  EngineSupervisor ── leader (corr-a)  /  standby (corr-b)
                 alarm lifecycle, enrichment, correlation, merge; telemetry → AI
                 ప్రతి 1 s కి state + offset ని SQLite కి checkpoint
                 ▼  incidents
 closed_loop.py  ClosedLoopController.tick() ప్రతి 0.5 s:
                 detected → analyze → decide (policy + guardrails) → act (DeviceAdapter) → verify → resolved / escalated
                 ▼
 runtime.py   snapshot()  ──►  main.py  GET /api/snapshot  ──► React dashboard (ప్రతి 1 s poll)
```

### 5.2 ఈ shape ఎందుకు?

- **Pipeline stages = production services.** ప్రతి box కి ఒక clear interface ఉంది (`submit()`, `read(offset)`,
  `execute(action, target)`, `AIUnavailable` exception). PoC లో function call; production లో network call.
- **Event log మధ్యలో పెట్టడం** వల్లే failover సాధ్యం: standby engine checkpoint నుంచి offset తీసుకుని log ని replay చేస్తుంది.
- **AI ని ఒక separate component గా** పెట్టాం (correlation లో కలపలేదు), కాబట్టి దాన్ని switch off చేసి safe mode చూపించగలం.
- **Device adapter** అనే layer action కి ముందు ఉంది — దానిలోనే retries, timeouts, circuit breaker. Real NETCONF/OMCI/TL1
  clients తర్వాత ఇక్కడే plug అవుతాయి.

### 5.3 PoC → Production mapping

| PoC component | Production లో |
|---|---|
| `SourceClient` + `IngestionGateway` | snmptrapd/pysnmp, rsyslog, Kafka consumers, gNMI/PM collectors + ingestion service |
| `EventLog` | Kafka / Redpanda topic (OLT వారీగా partition) |
| `CorrelationEngine` pair + supervisor | 2 replicas + leader election (Kubernetes lease / etcd / consumer-group rebalance) |
| `HistoryStore` | PostgreSQL / TimescaleDB |
| `AIService` | Model-serving service (REST/gRPC) |
| `ClosedLoopController` + `DeviceAdapter` | Orchestration service — NETCONF/RESTCONF, OMCI via OLT, TL1, ticketing APIs |

### 5.4 Background tasks (`Runtime.start()`)

| Task | Period | పని |
|---|---|---|
| `_sim_loop` | 0.5 s | `sim.tick()`, alarm events render చేసి sources కి ఇవ్వడం (కొన్ని SNMP retransmits తో) |
| `_telemetry_loop` | 2 s | PM telemetry |
| `_noise_loop` | 12–25 s | Realistic transients (dying gasp, PDH fade, CPU spike) |
| `_sampler` | 2 s | Live charts కోసం points |
| `gateway.run` | 50 ms | Ingestion queue → event log |
| `supervisor.run` | 0.25 s | Leader processing, heartbeat, checkpoint, failover |
| `loop.run` | 0.5 s | Closed-loop tick |
| `SourceClient.run` ×4 | continuous | Retry తో delivery |
| UDP endpoint | packet వచ్చినప్పుడు | Real syslog on :5514 |

---

## 6. Step 4: Configuration-first design

Code రాయడానికి ముందే, "ఏ విషయాలు మారుతూ ఉంటాయి?" అని అడిగి వాటిని YAML లో పెట్టాను. `backend/config/`:

| File | లోపల ఏముంది | ఎవరు మారుస్తారు |
|---|---|---|
| `topology.yaml` | Ontology classes, relationships + 105 entities (devices, links, pseudowires, services) | Network engineer |
| `alarm_catalog.yaml` | ప్రతి alarm type కి category, severity, domain, standard reference (G.984.3, G.822, G.826 ...), **RCA evidence weights** (`implicates`), `when:` overrides | Fault-management expert |
| `playbooks.yaml` | Remediation playbooks: match, steps (action, target, risk, protocol, rollback), verify KPI, follow-up | Operations |
| `policy.yaml` | Autonomy matrix (7 device classes × 6 fault categories) + guardrails | NOC manager (UI లో live edit కూడా) |
| `settings.yaml` | Timings, queue sizes, watermarks, retry/backoff, failover timeouts, model thresholds | Developer / demo tuning |

**ఉదాహరణ — policy.yaml:**
```yaml
matrix:
  ODN:  {link_down: supervised, ...}        # fibre cut → approval కావాలి
  G702: {timing_sync: autonomous, ...}       # E1 slips → AI తానే fix
  ONT:  {signal_degradation: advisory, ...}  # Rx drift → AI కేవలం suggest
guardrails:
  max_risk_autonomous: medium
  max_blast_radius_autonomous: 4
  min_rca_confidence_autonomous: 0.6
  max_actions_per_device_per_hour: 4
  safe_mode_level: advisory
```

**`depends_on` ఎప్పుడూ upstream వైపు** point చేస్తుంది (ONT → drop fibre → splitter → feeder → PON port → OLT). ఈ ఒక్క rule
తో ancestors (ఎవరి వల్ల నేను పడిపోతాను) మరియు descendants (నేను పడిపోతే ఎవరు పడిపోతారు) రెండూ compute చేయవచ్చు.

---

## 7. Step 5: Module build order — ఒక్కో module వివరంగా

> Build order dependency order ని follow చేస్తుంది: ఏ module దేని మీద ఆధారపడుతుందో అది ముందు.

### 7.1 `ontology.py` — Network model (మొదట build చేసింది)

**ఎందుకు మొదట?** ప్రతి ఇతర module (simulator, correlation, RCA, impact, enrichment, layout, closed loop) దీన్ని వాడుతుంది.

**ఏం చేస్తుంది:**
- `Topology.__init__`: `topology.yaml` చదివి, ప్రతి entity కి class properties (layer, kind, domain, `policy_class`,
  `observable`) copy చేస్తుంది; reverse index `dependents` build చేస్తుంది.
- `ancestors(eid)` / `descendants(eid)`: BFS తో hop distances (cached). Protection switch జరిగినప్పుడు `set_dependencies` cache rebuild చేస్తుంది.
- `affinity(a, b)`: రెండు entities ఎంత దగ్గర సంబంధం ఉన్నవో — dependency path మీద `1/(1+0.1·d)`, shared-risk ancestor
  (splitter, feeder, PON port) ద్వారా `0.9^(d1+d2)`. **ఒకే OLT chassis లో ఉన్నంత మాత్రాన siblings గా లెక్కించదు** (`NON_SHARED_RISK`)
  — లేకపోతే సంబంధం లేని faults కలిసిపోతాయి.
- `impacted(eid)`: descendants ని services, devices, cell sites, subscribers గా group చేస్తుంది (blast radius).
- `manager_of(eid)`: action ఎవరు execute చేస్తారు (ONT/E1 → దాని OLT via OMCI, pseudowire → CES gateway).
- `layout()`: Topology view కోసం x/y (rows per class, leaves సమానంగా, parents center లో).
- `AlarmCatalog`: `implicates(type, detail)` — RCA evidence weights, alarm details ఆధారంగా `when:` overrides
  (ఉదా: `PON_LOS` with `laser_tx: ok` → port కాదు, fibre ని implicate చేస్తుంది).

**Ontology లో modeled entities:** OLT, PON port, feeder fibre (working + standby — Type-B protection), splitter, drop fibre, ONT,
E1 circuit, BTS, eNB, G.702 PDH mux (E3 trunk), pseudowire (CESoPSN), CES gateway, STM-1, BSC, aggregation switches,
core routers, services (2G Abis backhaul, 4G backhaul, enterprise L2VPN). Layers: access, aggregation, core, service.

### 7.2 `simulator.py` — Fake network (రెండవది)

**ఎందుకు ఇప్పుడు?** Pipeline build చేయడానికి ముందు data source కావాలి. Real network లేదు కాబట్టి realistic simulator కావాలి.

**Design idea — "Observer model":** Simulator కి **ground truth** తెలుసు (ఏ fault ఎక్కడ inject చేశామో). కానీ అది బయటకు పంపేది
**ప్రతి real device ఏం report చేస్తుందో అదే** — fibre ఎప్పుడూ alarm పంపదు; OLT పంపుతుంది.

- State: `faults` (entity → `Fault(type, since, params, until)`), `mgmt_unreachable`, `extra_alarms` (noise), `active`.
- Fault types: `cut`, `fail`, `power` (down); `optics_degraded`, `timing`, `rx_drift` (degraded).
- `_recompute()`: worst status ని dependency tree లో క్రిందికి propagate చేస్తుంది. F-A1 down → SPL-A1 → drops → ONTs → E1s → BTS, PWs, services down.
- `_expected_alarms()`: ప్రతి entity class కి "ఎవరు ఏం report చేస్తారు" rules. ఉదా: "PON port up కానీ active feeder down → OLT
  `PON_LOS` with `laser_tx=ok` report చేస్తుంది." **Reporter తానే down అయితే report చేయలేడు** — అందుకే OLT fail అయితే ONT
  alarms రావు, NMS నుంచి `NE_UNREACHABLE` వస్తుంది.
- `tick()`: expected vs previous active keys diff → `raise` / `clear` events.
- `telemetry()`: OLT CPU/temp, PON BER/laser bias/utilisation, ONT Rx power/temp/BER, E1 ES/SES/slips, pseudowire underruns/loss — faults వీటి numbers ని మారుస్తాయి.
- `apply_action()`: remediation network ని ఎలా మారుస్తుందో — **actions కి effect ఉండే ఏకైక place** ఇదే.
- `noise_event()`: dying gasp, PDH microwave fade, CPU spike — real NOC లాగా noise.
- `truth_onset`: **KPI measurement కి మాత్రమే**, analysis కి ఎప్పుడూ కాదు.

### 7.3 `sources.py` — Wire formats

**ఎందుకు?** Requirement "SNMP traps, syslog, event streams, telemetry" నుంచి ingest చేయాలని అడిగింది. కాబట్టి simulator
events ని ఆ native formats లో render చేయాలి.

- `render(ev)`: Reporter class బట్టి format —
  - OLT → **SNMP trap dict** (private enterprise OID `1.3.6.1.4.1.64999`, alarm type కి ఒక trap OID, varbinds)
  - CES gateway / PDH mux / IP devices → **RFC 5424 syslog** line, structured data `[alarm@64999 id=... entity=... state=...]`
  - BSC / NMS / service assurance → **JSON event stream**
  - PM → telemetry batch
- `SourceClient`: bounded buffer, **random delivery delay** (కావాలనే out-of-order arrive అవ్వడానికి), **exponential backoff
  with full jitter** retry, telemetry కి **latest-value-wins** (పాత samples retry చేయకుండా drop).

### 7.4 `ingestion.py` — Front door

- `parse()`: నాలుగు formats → ఒకే normalised dict: `{kind, id, reporter, entity, type, severity, state, ts, source, detail, priority}`.
  Bad input / unknown entity → **DLQ (dead-letter queue)** — pipeline ఆగదు.
- `submit()` — **admission control**:
  - Priority 2 = critical/major లేదా ఏ clear అయినా; priority 1 = మిగతావి; telemetry = 0.
  - Queue 60 % (high watermark) దాటితే low-priority **shed** (`retry_after` తో reject).
  - Queue full అయితే అన్నీ reject. HTTP endpoint లో ఇది **429 + Retry-After**.
- `run()`: fixed rate (450 ev/s) తో queue drain → `_dedup_and_buffer` (event id మీద idempotency, TTL cache) →
  device timestamp ordered heap → `_release` (1 s re-order window) → `EventLog` (ప్రతి event కి **offset**).
- `EventLog`: append-only list, చివరి 60k events — Kafka topic కి stand-in.

### 7.5 `history.py` — Memory (SQLite)

**ఎందుకు AI కంటే ముందు?** AI కి learn చేయడానికి history కావాలి.

- Tables: `incidents` (seeded + live) మరియు `checkpoints`.
- `seed()`: **30 days synthetic history** — days 1–15 `mode=rule` (rule-based NOC), days 16–30 `mode=ai`. Trends లో
  comparison కోసం. UI లో "synthetic" అని స్పష్టంగా label చేశాం.
- `refresh_stats()`: root-cause **priors** (fibre ≈ 27 %, ONT ≈ 27 %, E1 ≈ 20 % ...), alarm **co-occurrence (NPMI)**,
  **playbook success rates** (Beta(1,1) smoothing).
- Live గా resolve అయిన ప్రతి incident append అవుతుంది — statistics నేర్చుకుంటూనే ఉంటాయి.

### 7.6 `enrichment.py` — Context

`enrich(ctx, alarm)` alarm create అయినప్పుడు ఒక్కసారి compute చేస్తుంది:
- `topology`: class, layer, OLT, PON port, splitter, path to core, managing element, site
- `device`: vendor, model, software, install date, serial
- `impact`: services, cell sites, subscribers
- `history`: 30 రోజుల్లో incidents, MTBF, last incident

ఇది requirement లోని "alert enrichment with topology context, device metadata, historical data" ని నేరుగా cover చేస్తుంది.

### 7.7 `ai.py` — ML models & RCA

ఇది PoC లో "AI" భాగం. నాలుగు పనులు:

**(a) Anomaly detection (telemetry):**
- Telemetry family కి ఒక **IsolationForest** (120 trees), startup లో 3,000 healthy samples మీద train.
- Families: ONT (Rx power, temp, log BER), PON port (log BER, laser bias, utilisation), E1 (ES, SES, slips), pseudowire (underruns, loss), OLT (CPU, temp).
- 0.15 % quantile కంటే తక్కువ score **వరుసగా 2 samples** వస్తే anomaly (flapping తగ్గించడానికి). ఏ feature ఎక్కువ deviate అయ్యిందో (z-score) చెబుతుంది: ఉదా `PON-B2 tx_bias_ma z=+33`.
- **Alarm storm detection:** alarm rate మీద EWMA z-score; z > 6 మరియు > 20 alarms/s.

**(b) Fault prediction:**
- ప్రతి ONT కి చివరి 40 Rx-power samples మీద linear trend. Features (slope dB/min, noise, −27 dBm sensitivity కి margin) → **LogisticRegression**.
- Slope negative, 240 s horizon లో threshold cross, P(fault) > 0.6 అయితే `PREDICTED_FAULT` raise. తర్వాత device alarm వస్తే **prediction lead time** record.

**(c) Bayesian RCA (ముఖ్యమైనది):**
```
log score(c) = log P(class(c))                          ← history prior
             + Σ_alarms log P(alarm | c)                 ← evidence (alarm_catalog weights)
             + min(#healthy observable dependents, 8) · log 0.15   ← topology penalty
```
- Candidates = alarmed entities + వాటి ancestors (~25–60).
- **Healthy-dependents penalty** key idea: OLT-A root అయితే PON-A2 లోని ONTs కూడా పడిపోవాలి — కానీ అవి healthy గా report
  చేస్తున్నాయి → OLT-A కాదు. Reporter తానే alarm పంపుతుంటే అది alive (0.05).
- Softmax తో confidences. Fibre cut example: **F-A1 ≈ 89 %**, PON-A1 ≈ 7 %, SPL-A1 ≈ 4 %, OLT-A ≈ 0 %.
- Rule-based fallback ("most upstream alarmed entity") PON-A1 ని ఎంచుకుంటుంది — తప్పు; technician OLT card దగ్గరకు వెళ్తాడు, fibre దగ్గరకు కాదు. **ఇదే PoC యొక్క main "wow" point.**

**(d) Playbook ranking:** `historical success rate × match specificity`, similar past incidents count, median MTTR తో.

**Safe mode:** ప్రతి public method ముందు `check()` → AI `up` కాకపోతే `AIUnavailable` raise. Callers catch చేసి rule-based fallback వాడతారు.

**ఎందుకు ఈ models?** Small, explainable, fast. NOC operator కి "ఎందుకు ఈ root cause" అని evidence strings చూపించగలం — black box కాదు.

### 7.8 `correlation.py` — Incident engine + failover

**State design:** Engine state మొత్తం ఒక JSON-serialisable dict (`empty_state()`): `offset`, `alarms`, `index`, `incidents`,
`last_ts`, `telemetry`, `stats`. ఇదే checkpoint/failover ని trivial చేసింది.

**Alarm lifecycle (`_alarm`):**
1. **Stale** (ఈ entity+type కి చివరి event కంటే పాతది) → ignore. (Delayed clear కొత్త raise ని cancel చేయలేదు.)
2. **Clear** → alarm cleared.
3. Active alarm **repeat** → count++.
4. Open incident లో cleared alarm మళ్ళీ raise → **flap** (reactivate).
5. లేకపోతే కొత్త alarm `ALM-xxxxx` → `enrich()` → `_correlate()`.

**Correlation score:**
```
score = 0.6 · topology_affinity + 0.25 · exp(-Δt / 30 s) + 0.15 · NPMI(co-occurrence)
```
- Best ≥ 0.5 → attach. చాలా incidents కి match అయితే → **merge** (cascade మొదట fragments గా మొదలవుతుంది).
- Match లేకపోతే → new incident (ఇక్కడ **MTTD** end point).
- Affinity < 0.45 అయితే veto. Non-service-affecting warnings (CPU spike) anchor కావు.
- Safe mode లో strict rule (same subtree, 60 s).

**Telemetry:** `ai.analyze_telemetry` కి fan-out → `AI_ANOMALY` / `PREDICTED_FAULT` derived alarms → అవి కూడా అదే correlation ద్వారా.

**`EngineSupervisor` (failover):**
- రెండు instances: corr-a (leader), corr-b (standby). Leader 0.25 s కి heartbeat, 1 s కి checkpoint (state + offset → SQLite).
- Heartbeat 2.5 s కంటే పాతదైతే standby: **checkpoint load → offset నుంచి log replay → promote**.
- Idempotency + per-key reconciliation వల్ల replay safe (effectively-once).
- Crash అయిన instance 12 s తర్వాత standby గా తిరిగి join.

### 7.9 `closed_loop.py` — Decide, act, verify

**Phase machine** (`step()` per incident, ప్రతి 0.5 s):

```
detected ─(3 s quiet hold-down, max 8 s)─► analyzed
analyzed ─► watching (transient) | advisory | awaiting_approval | acting | escalated
advisory ─Execute─► acting      awaiting_approval ─Approve─► acting
acting ─► verifying  (లేదా device unreachable → escalated)
verifying ─► resolved (alarms clear + KPI met; MTTR stops)
          ─► acting (verification fail, next step allowed)
          ─► escalated (step లేదు / next step out of bounds)
```

1. **Analyze:** `ai.rca()` (లేదా fallback), `topo.impacted()`, `_category()`, `_match_playbooks()` + `ai.rank_playbooks()`.
2. **Decide:** `policy_class(root) × fault_category` → matrix level. Guardrails apply:
   - risk > `medium` → escalate
   - blast radius > 4 services → escalate
   - RCA confidence < 0.6 → supervised కి downgrade
   - device కి గంటకి 4 actions దాటితే → escalate
   - AI down → `advisory` ceiling
3. **Act:** `DeviceAdapter.execute()` — managing element resolve (`manager_of`), **circuit breaker** check, protocol latency
   simulate (NETCONF / OMCI / TL1), timeout 2.5 s, 2 retries, `sim.apply_action()`. Result `pending_results` లో queue — next tick లో apply (failover gap లో కూడా lost కాదు).
4. **Verify:** Window (8 s; transient watch కి 45 s) లో ప్రతి second: service-affecting alarms అన్నీ clear **మరియు**
   playbook KPI **action తర్వాత వచ్చిన fresh telemetry** మీద hold అవ్వాలి (ఉదా `slips = 0`, `us_ber ≤ 1e-9`, `rx_power ≥ −25 dBm`).
   Window లో **relapse** అయితే fail. MTTR = service restore అయిన క్షణం (window end కాదు).
5. **On failure:** rollback (ఉంటే) → next step (మళ్ళీ decide logic ద్వారా) → లేదా **escalate** (NOC ticket + full RCA, impact, enrichment, proposed action).

**CircuitBreaker:** closed → 2 failures తర్వాత open → 30 s తర్వాత half-open.

**ఎందుకు loop state incident లో?** Engine failover అయినా loop ఎక్కడ ఉందో అక్కడ నుంచే కొనసాగుతుంది (P6).

### 7.10 `runtime.py` + `main.py` — Wiring & API

- `Runtime` = **composition root**: dependency order లో ప్రతి component construct చేస్తుంది, background tasks own చేస్తుంది,
  scenarios (`SCENARIOS`, `run_scenario`, `guided_demo`), drills (`DRILLS`, `_storm`, `_replay`), KPIs (`kpis()`),
  topology overlay (`entity_view`), dashboard payload (`snapshot()`).
- `main.py`: thin FastAPI layer. ముఖ్యమైన endpoints:

| Endpoint | పని |
|---|---|
| `GET /api/snapshot` | Dashboard కి కావాల్సింది అంతా |
| `GET /api/topology` | Ontology, entities, layout |
| `GET /api/incidents/{id}` | Enriched alarms తో incident |
| `POST /api/incidents/{id}/{approve\|execute\|reject\|ack\|resolve}` | Operator actions |
| `PUT /api/policy/matrix`, `/guardrails` | Autonomy live edit |
| `POST /api/scenarios/{name}`, `/api/drills/{name}` | Demo |
| `POST /api/ingest/{snmp\|syslog\|stream\|telemetry}` | External ingestion: 202 / 429 + Retry-After / 400 |
| `GET /api/history/trends` | 30-day KPIs |

- Built frontend (`frontend/dist`) ఉంటే backend దాన్ని :8000 లోనే serve చేస్తుంది (single-port option).

### 7.11 Frontend (React + Vite) — చివరిగా

**ఎందుకు చివరిగా?** Backend logic API ద్వారా 17/17 checks pass అయిన తర్వాతే UI కట్టాం — UI bugs మరియు logic bugs కలవకుండా.

- `api.js`: `api()` fetch helper; `usePoll(path, ms)` — **last good value ఉంచుతుంది**, error వస్తే "link lost" banner (dashboard ఎప్పుడూ blank అవ్వదు).
- `App.jsx`: `/api/snapshot` ప్రతి 1 s, `/api/topology` ప్రతి 4 s. Header chips, KPI strip, scenario bar, 4 tabs.
- `TopologyView.jsx`: pure SVG. Blue = GPON, purple = G.702, grey = IP. Severity colours, root cause కి pulsing red ring, passive fault link మీద "RC", dashed standby feeder.
- `IncidentDetail.jsx`: drawer — phase stepper, operator buttons, RCA hypotheses (confidence bars + evidence), impact, policy decision, ranked playbooks, actions + verification, alarms (enrichment), timeline.
- `Panels.jsx`: incident list, alarm feed, activity log, entity panel.
- `ClosedLoopBoard.jsx`: awaiting approval / advisory / executing-verifying / escalated columns + action log.
- `AutonomyResilience.jsx`: editable autonomy matrix + guardrails, drill buttons, ingestion gauges, engine instances, AI status, circuit breakers, DLQ.
- `Trends.jsx`: Recharts — rule-based vs AI vs live session comparison, live charts, 30-day history.
- `styles.css`: dark NOC theme.

**Client-side state store లేదు, router లేదు** — backend snapshot ఒక్కటే source of truth (P8). Simple గా ఉంచాం.

---

## 8. Step 6: Demo scenarios & fault-tolerance drills design

Requirement కనీసం 3 scenarios (cascade, autonomous, escalation) అడిగింది. ప్రతి scenario **closed loop లోని వేరే branch** ని
చూపించేలా design చేశాను:

| Scenario | Inject చేసేది | Policy cell | Loop path | చూపించేది |
|---|---|---|---|---|
| **Cascading fibre cut** | `F-A1` cut | ODN × link_down = supervised (blast radius 5 > 4 కూడా) | awaiting approval → switchover → verified → resolved + field ticket | ~15 alarms → 1 incident; silent fibre ని RCA కనిపెట్టడం |
| **E1 timing slips** | E1-102 timing | G702 × timing_sync = autonomous | act → verify `slips=0` → resolved (MTTR ≈ 7–10 s) | Human లేకుండా fix |
| **PON optics degradation** | PON-B2 optics | OLT × signal_degradation = autonomous | recalibrate → relapse → verification fail → next step high risk → **escalated** | Verification fail + escalation |
| **ONT Rx drift** | rx_drift | ONT × signal_degradation = advisory | predictive incident → Execute dispatch → verified | Alarm రాకముందే prediction |
| **OLT uplink failure** | uplink | Aggregation × link_down = advisory | high-risk reroute fails → escalated | Advisory + failure path |

**Fault-tolerance drills** (requirement లోని ప్రతి item కి ఒకటి):

| Drill | ఏం జరుగుతుంది | Expected |
|---|---|---|
| Alarm storm | < 1 s లో ~3,500 messages + ఒక real dying-gasp fault | Queue ≈ 580/600, shedding, retries, **real alarm delivered** |
| Duplicate & out-of-order replay | Recent events ని 2 సార్లు shuffle చేసి + 30 s పాత stale clears | Duplicates drop, stale clears ignore, active alarms మారవు |
| Crash correlation engine | Leader kill | ~2.5 s లో standby takeover, ~0.3 s replay, **ఏ incident కోల్పోలేదు** |
| AI outage | AI `up=False` | Safe-mode banner, rule-based RCA, advisory ceiling |
| OLT-B management unreachable | mgmt plane down | Breaker open, action execute కాదు, escalated |

**Guided demo** button scenarios 1–4 + engine failover ని వరుసగా run చేస్తుంది. **"show simulator ground truth"** checkbox
AI సరిగ్గా చెప్పిందో లేదో check చేయడానికి.

**Demo కోసం కావాలని చేసిన tuning:** `process_rate_per_s: 450`, `queue_capacity: 600` చిన్నవి (backpressure కనిపించడానికి);
`holddown_s: 3`, `verify_window_s: 8` short (demo వేగంగా కదలడానికి); `trap_retransmit_ratio: 0.06`, `network_jitter_s: 0.35`
(de-dup, re-order పని చేయడం కనిపించడానికి).

---

## 9. Step 7: Verification & bug fixing

### 9.1 `verify_demo.py` — 17 end-to-end checks

UI కంటే ముందే ఈ script రాశాం. Running backend ని API ద్వారా drive చేసి outcomes assert చేస్తుంది (4–5 minutes):

| Area | Checks |
|---|---|
| Cascade | root cause = F-A1; ≥ 10 alarms ఒక incident లో; awaiting approval; approve తర్వాత verified & resolved |
| Autonomous | E1-102 human లేకుండా resolved |
| Escalation | autonomous action verification fail; proposed high-risk step (`pon_port_migrate`) తో escalated; human fix close |
| Prediction | device alarm కంటే ముందే predicted; proactive dispatch verified |
| Failover | standby (corr-b) takeover; incidents lost కాలేదు |
| Replay | duplicates dropped |
| Storm | backpressure engaged; real alarm delivered |
| Safe mode | rule-based RCA + advisory ceiling |
| Unreachable | action execute కాలేదు, escalated |

Run సమయంలో background noise off చేసి, చివర on చేస్తుంది. Exit 0 = all pass.

### 9.2 Build లో దొరికిన bug

Full end-to-end run లో **safe-mode correlation edge case** దొరికింది (AI off ఉన్నప్పుడు వాడే rule-based correlation
fallback లో; build log లో ఈ ఒక్క line మాత్రమే record అయింది, వివరమైన diff లేదు). Fix చేసి మళ్ళీ 17/17 pass అయ్యేలా చూశాం. ఈ రకమైన bug UI లో చూస్తే దొరకడం కష్టం — automated check వల్లే దొరికింది.

### 9.3 Clean install test

చివరగా fresh environment లో `run_backend.sh` (కొత్త venv) మరియు `run_frontend.sh` (`npm install`) నుంచి start చేసి రెండు
servers వస్తున్నాయని verify చేశాం. తర్వాతి రోజుల్లో scripts ని మరింత robust చేశాం: Python 3.10+/Node 18+ check, broken/half-created
venv detect చేసి rebuild, వేరే Node version తో install అయిన `node_modules` reinstall.

---

## 10. Step 8: Documentation, scripts, packaging

| Deliverable | Purpose |
|---|---|
| `README.md` | Quick start, 5-minute demo script, API summary, honest limits |
| `docs/ARCHITECTURE.md` | Components, data flow, production mapping |
| `docs/TOPOLOGY_ONTOLOGY.md` | Entity classes, relationships, alarm catalogue |
| `docs/AI_LOGIC.md` | Correlation scoring, Bayesian RCA, anomaly, prediction, ranking |
| `docs/CLOSED_LOOP.md` | Phases, autonomy levels, guardrails, verification, escalation |
| `docs/FAULT_TOLERANCE.md` | ప్రతి degradation mode + demo ఎలా |
| `docs/METRICS.md` | MTTD, MTTR, compression ఎలా compute చేస్తామో |
| `docs/screenshots/` | 5 views |
| `run_backend.sh/.ps1`, `run_frontend.sh/.ps1`, `run_all.sh` | Linux/Mac/Windows one-command start |

తర్వాత Satya అడిగిన మేరకు: `gpon-fault-poc.zip`, `KNOWLEDGE_TRANSFER.md` (new developer guide), tech-head architecture doc + PDF,
15-slide deck, Telugu demo walkthrough script — ఇప్పుడు ఈ document.

**Metrics ఎలా compute అవుతాయి (Runtime.kpis):**
- **MTTD** = incident creation − fault onset (ingestion delay + re-order window + correlation అన్నీ కలిపి).
- **MTTR** = service restoration − fault onset.
- **Alarm compression** = unique raw alarms ÷ incidents.
- **Resolved autonomously** = autonomous resolved ÷ remediated; verification pass rate.
- 30-day trends: days 1–15 rule-based vs 16–30 AI vs live session.

---

## 11. ఒక fault ని మొదటి నుంచి చివరి వరకు (summary)

*Cascading fibre cut* button నొక్కితే:

1. **Button** → `POST /api/scenarios/cascade_fiber_cut` → `sim.inject("F-A1", "cut")`.
2. **Simulator** → status propagate → expected alarms → `raise` events (PON_LOS, 4× ONT_LOSi, 2× PW_DOWN, 2× E1_AIS, 2× ABIS_LINK_DOWN, 3× SLA_BREACH).
3. **Sources** → SNMP / syslog / JSON formats లో, random delay తో.
4. **Ingestion** → parse → admission → de-dup → re-order → event log (offset).
5. **Correlation** → మొదటి ONT_LOSi `INC-0001` open (MTTD); మిగతావన్నీ topology affinity తో attach.
6. **Analyze** (3 s hold-down తర్వాత) → RCA: F-A1 89 %; impact 5 services, 2 cell sites; playbook `pon_type_b_switchover`.
7. **Decide** → ODN × link_down = supervised → `awaiting_approval`.
8. **Act** → Operator *Approve* → DeviceAdapter → OLT-A (NETCONF) → `pon_protection_switch` → SPL-A1 standby feeder F-A1P కి.
9. **Network heals** → clears అదే pipeline ద్వారా → alarms cleared; `PON_PROTECTION_UNAVAILABLE` warning.
10. **Verify** → 8 s window pass → resolved, MTTR, field ticket `FLD-xxxx` (fibre repair), history లో append.
11. **Screen** → snapshot → TopologyView లో F-A1 root, descendants impacted.

---

## 12. Honest limits & production కి path

| PoC limit | Production approach |
|---|---|
| Simulated network & actions | Real collectors + NETCONF/RESTCONF, OMCI via OLT EMS, TL1, ticketing APIs |
| SNMP traps pre-decoded dicts గా | Vendor MIBs తో trap receiver → `/api/ingest/snmp` |
| ఒకే process, in-memory event log | Separate services, Kafka, leader election (K8s lease / etcd) |
| SQLite | PostgreSQL / TimescaleDB |
| Synthetic 30-day history | Operator real history మీద train, periodic retraining, model monitoring |
| No authentication | SSO, role-based approvals, audit log |
| UI 1 s polling | WebSocket / SSE |
| UI policy edits persist కావు | DB లో policy + change history |
| Unit tests లేవు, ఒక E2E script | Module unit tests, parser contract tests, chaos tests |

---

## 13. ఈ approach నుంచి key lessons

1. **Data model ముందు.** Topology/ontology బలంగా ఉంటే correlation, RCA, impact అన్నీ దాని మీద సహజంగా కూర్చుంటాయి.
2. **Simulator కి, logic కి మధ్య wire-format boundary.** ఇది PoC ని "toy" కాకుండా "real pipeline" గా చేస్తుంది.
3. **ప్రతి smart component కి dumb fallback.** AI down, device down, engine crash — ఏది జరిగినా system ఆగదు, safe గా degrade అవుతుంది.
4. **State ని plain data గా ఉంచు.** Checkpoint, failover, debugging అన్నీ సులభం.
5. **Config-first.** Autonomy, playbooks, alarms, topology — code మార్చకుండా YAML తో మారతాయి.
6. **UI కంటే ముందు automated E2E check.** Logic bugs ముందే దొరుకుతాయి; UI కేవలం presentation.
7. **Demo కోసం design చేయి.** ప్రతి requirement కి ఒక button, ప్రతి button కి ఒక visible effect, ప్రతి effect కి ఒక check.
8. **Honest గా ఉండు.** Synthetic data ని label చేయి, simulated parts ని README లో స్పష్టంగా చెప్పు, production path చూపించు.
