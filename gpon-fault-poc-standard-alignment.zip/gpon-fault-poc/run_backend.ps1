# Windows: create (or repair) the virtual environment and start the backend on :8000.
$ErrorActionPreference = "Stop"
Set-Location "$PSScriptRoot\backend"
$venvPy = ".\.venv\Scripts\python.exe"
$imports = "import fastapi, uvicorn, numpy, sklearn, yaml"

$healthy = $false
if (Test-Path $venvPy) { & $venvPy -m pip --version *> $null; $healthy = ($LASTEXITCODE -eq 0) }
if (-not $healthy) {
  if (Test-Path .venv) { Write-Host "backend\.venv is incomplete or broken; rebuilding it."; Remove-Item -Recurse -Force .venv }
  python -m venv .venv
  if ($LASTEXITCODE -ne 0) { throw "Could not create the virtual environment. Install Python 3.10+ from python.org and re-run." }
}

& $venvPy -c $imports *> $null
if ($LASTEXITCODE -ne 0) {
  Write-Host "Installing Python dependencies (first run takes a minute) ..."
  & $venvPy -m pip install -r requirements.txt
  if ($LASTEXITCODE -ne 0) { throw "pip install failed (see above). Check internet/proxy access and re-run." }
}

& $venvPy -m uvicorn app.main:app --host 0.0.0.0 --port 8000
