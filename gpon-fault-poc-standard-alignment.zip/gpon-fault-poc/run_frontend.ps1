# Windows: install dashboard dependencies (when needed) and start Vite on :5173. Needs Node.js 18+.
$ErrorActionPreference = "Stop"
Set-Location "$PSScriptRoot\frontend"

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  throw "Node.js was not found. Install Node.js 20 LTS from https://nodejs.org (or: winget install OpenJS.NodeJS.LTS) and re-run."
}
$nodeVer = (node --version).Trim()
$nodeMajor = [int]($nodeVer.TrimStart('v').Split('.')[0])
if ($nodeMajor -lt 18) {
  throw "Node.js $nodeVer is too old; the dashboard (Vite 5) needs Node.js 18 or newer. Install Node.js 20 LTS from https://nodejs.org (or: winget install OpenJS.NodeJS.LTS) and re-run."
}

$stamp = "node_modules\.installed-with-node"
$stampVal = if (Test-Path $stamp) { (Get-Content $stamp).Trim() } else { "" }
if (-not (Test-Path "node_modules\.bin\vite.cmd") -or $stampVal -ne "$nodeMajor") {
  if (Test-Path node_modules) { Write-Host "Reinstalling dashboard dependencies for Node.js $nodeVer ..."; Remove-Item -Recurse -Force node_modules }
  npm ci
  if ($LASTEXITCODE -ne 0) { throw "npm install failed (see above). Check internet/proxy access and re-run." }
  Set-Content $stamp "$nodeMajor"
}

npm run dev -- --host 0.0.0.0
