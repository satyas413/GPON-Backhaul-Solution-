#!/usr/bin/env bash
# Start backend and dashboard together; Ctrl+C stops both.
set -euo pipefail
cd "$(dirname "$0")"
./run_backend.sh & BE=$!
trap 'kill $BE 2>/dev/null' EXIT
until curl -sf http://localhost:8000/api/health >/dev/null; do sleep 1; done
echo "Backend up on http://localhost:8000 - dashboard on http://localhost:5173"
./run_frontend.sh
