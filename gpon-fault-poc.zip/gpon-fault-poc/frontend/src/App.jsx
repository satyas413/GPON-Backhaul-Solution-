import { useEffect, useMemo, useState } from 'react'
import { api, fmtSec, pct, usePoll } from './api.js'
import TopologyView from './components/TopologyView.jsx'
import IncidentDetail from './components/IncidentDetail.jsx'
import { AlarmFeed, EntityPanel, EventLog, IncidentList } from './components/Panels.jsx'
import ClosedLoopBoard from './components/ClosedLoopBoard.jsx'
import { AutonomyMatrix, Resilience } from './components/AutonomyResilience.jsx'
import Trends from './components/Trends.jsx'

const SCENARIO_BUTTONS = [
  ['cascade_fiber_cut', 'Cascading fibre cut', 'bad'],
  ['autonomous_e1_timing', 'E1 timing slips (autonomous)', 'good'],
  ['escalation_pon_optics', 'PON optics degradation (escalates)', 'warn'],
  ['predictive_rx_drift', 'ONT Rx drift (predictive)', 'primary'],
  ['uplink_failure', 'OLT uplink failure', 'bad'],
]

function Kpi({ label, value, sub, good }) {
  return (
    <div className="kpi">
      <div className="label">{label}</div>
      <div className="value">{value}</div>
      <div className={`sub ${good ? 'good' : ''}`}>{sub}</div>
    </div>
  )
}

export default function App() {
  const { data: snap, error, lastOk } = usePoll('/snapshot', 1000)
  const { data: topology } = usePoll('/topology', 4000)
  const [tab, setTab] = useState('ops')
  const [selInc, setSelInc] = useState(null)
  const [focusInc, setFocusInc] = useState(null)
  const [selEnt, setSelEnt] = useState(null)
  const [showTruth, setShowTruth] = useState(false)
  const [activeOnly, setActiveOnly] = useState(false)
  const [toast, setToast] = useState(null)
  const [scenarioInfo, setScenarioInfo] = useState(null)

  useEffect(() => { api('/scenarios').then(setScenarioInfo).catch(() => {}) }, [])
  useEffect(() => {
    if (!toast) return
    const id = setTimeout(() => setToast(null), 4000)
    return () => clearTimeout(id)
  }, [toast])

  const run = async (path, label) => {
    try { await api(path, 'POST'); setToast(label) } catch (e) { setToast(`Failed: ${e.message}`) }
  }

  const incidents = snap?.incidents || []
  const incident = useMemo(() => incidents.find((i) => i.id === selInc), [incidents, selInc])
  const focused = incidents.find((i) => i.id === focusInc)
  const focus = focused ? { entities: [...focused.entities, ...(focused.impact ? [focused.impact.root, ...focused.impact.devices] : [])] } : null
  const k = snap?.kpis || {}
  const linkDown = error && (!lastOk || Date.now() - lastOk > 3000)

  const openIncident = (id) => { setSelInc(id); setFocusInc(id) }

  if (!snap) {
    return (
      <div className="app">
        <div className="banner down">{error ? `Backend not reachable (${error}). Start it with ./run_backend.sh — retrying…` : 'Connecting to backend…'}</div>
      </div>
    )
  }

  const corr = snap.correlation
  const ing = snap.ingestion
  const pending = k.pending_approvals || 0
  const escalated = incidents.filter((i) => i.phase === 'escalated').length

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <b>GPON · G.702 Backhaul — AI Fault & Alarm Management</b>
          <span>Topology-aware correlation · closed-loop remediation · fault-tolerant pipeline</span>
        </div>
        <div className="chips">
          <span className="chip"><span className={`dot ${linkDown ? 'bad' : ''}`} />Dashboard link {linkDown ? 'lost' : 'live'}</span>
          <span className="chip"><span className={`dot ${corr.leader ? '' : 'bad'}`} />Correlation {corr.leader ? `${corr.leader} active` : 'FAILOVER'}</span>
          <span className="chip"><span className={`dot ${snap.safe_mode ? 'bad' : ''}`} />AI {snap.safe_mode ? 'down · safe mode' : 'online'}</span>
          <span className="chip"><span className={`dot ${ing.state === 'normal' ? '' : 'warn'}`} />Ingestion {ing.state} · q {ing.queue_depth}</span>
          {snap.ai.storm.active && <span className="chip"><span className="dot warn" />Alarm storm z={snap.ai.storm.z}</span>}
          {snap.sim.mgmt_unreachable.length > 0 && <span className="chip"><span className="dot bad" />{snap.sim.mgmt_unreachable.join(', ')} mgmt unreachable</span>}
        </div>
      </header>
      {snap.safe_mode && <div className="banner safe">⚠ Safe mode: the AI component is unavailable. Correlation and RCA use deterministic topology rules and every action is capped at advisory until the AI service is restored.</div>}
      {!corr.leader && <div className="banner down">Correlation engine failover in progress: the standby is restoring the last checkpoint and replaying the event log. No events are lost.</div>}
      {linkDown && <div className="banner down">Lost connection to the backend; showing the last known state and retrying every second.</div>}

      <section className="kpis">
        <Kpi label="MTTD (live)" value={fmtSec(k.mttd_s)} sub={`baseline ${k.baseline_mttd_min ?? '–'} min (rule-based)`} good />
        <Kpi label="MTTR (live)" value={fmtSec(k.mttr_s)} sub={`baseline ${k.baseline_mttr_min ?? '–'} min · auto ${fmtSec(k.mttr_autonomous_s)}`} good />
        <Kpi label="Alarm compression" value={`${k.compression_ratio ?? '–'}×`} sub={`${k.raw_alarms ?? 0} alarms → ${k.incidents ?? 0} incidents`} />
        <Kpi label="Resolved autonomously" value={pct(k.auto_resolution_pct)} sub={`verification pass ${pct(k.verification_pass_pct)}`} />
        <Kpi label="Open incidents" value={k.open_incidents ?? 0} sub={`${k.self_cleared ?? 0} transients self-cleared`} />
        <Kpi label="Awaiting approval" value={pending} sub={`${k.actions ?? 0} actions executed`} />
        <Kpi label="Escalations" value={k.escalations ?? 0} sub={`${escalated} currently open`} />
        <Kpi label="Predicted faults" value={k.predictions ?? 0} sub={`${k.duplicates_suppressed ?? 0} duplicates suppressed`} />
      </section>

      <div className="scenarios">
        <span className="label">Demo scenarios:</span>
        {SCENARIO_BUTTONS.map(([key, label, cls]) => (
          <button key={key} className={`btn ${cls}`} title={scenarioInfo?.scenarios?.[key]?.story} onClick={() => run(`/scenarios/${key}`, `Started: ${label}`)}>{label}</button>
        ))}
        <button className="btn" onClick={() => run('/scenarios/guided_demo', 'Guided demo started')} title="Runs every scenario in sequence, then crashes the active correlation engine">▶ Guided demo</button>
        <button className="btn" onClick={() => run('/reset', 'Network repaired')}>Repair network</button>
        <button className="btn" onClick={() => api('/reset', 'POST', { full: true }).then(() => { setSelInc(null); setFocusInc(null); setToast('Network repaired and incidents cleared') })}>Reset all</button>
        <label className="small muted" style={{ marginLeft: 'auto' }}>
          <input type="checkbox" style={{ width: 'auto', marginRight: 4 }} checked={showTruth} onChange={(e) => setShowTruth(e.target.checked)} />
          show simulator ground truth
        </label>
        <label className="small muted">
          <input type="checkbox" style={{ width: 'auto', marginRight: 4 }} checked={snap.noise} onChange={(e) => api(`/noise/${e.target.checked ? 'on' : 'off'}`, 'POST')} />
          background noise
        </label>
        {toast && <span className="badge" style={{ color: 'var(--accent)' }}>{toast}</span>}
      </div>

      <nav className="tabs">
        {[['ops', 'Operations'], ['loop', 'Closed loop', pending + escalated], ['auto', 'Autonomy & resilience'], ['trends', 'Trends & KPIs']].map(([key, label, n]) => (
          <button key={key} className={`tab ${tab === key ? 'on' : ''}`} onClick={() => setTab(key)}>
            {label}{n ? <span className="badge phase-escalated">{n}</span> : null}
          </button>
        ))}
      </nav>

      <main className="content">
        {tab === 'ops' && (
          <div className="grid ops">
            <div className="grid" style={{ gap: 14 }}>
              <div className="card">
                <h3>
                  Network topology · G.702 + GPON backhaul ontology
                  <span className="right small">
                    {focused ? <>Focused on <b>{focused.id}</b> <button className="btn small" onClick={() => setFocusInc(null)}>clear</button></> : <span className="muted">click an incident to focus</span>}
                  </span>
                </h3>
                <TopologyView topology={topology} view={snap.entity_view} selected={selEnt} onSelectEntity={setSelEnt}
                  focus={focus} faults={snap.sim.faults} showTruth={showTruth} />
              </div>
              <div className="card">
                <h3>Entity details</h3>
                <EntityPanel topology={topology} id={selEnt} view={snap.entity_view} incidents={incidents} onSelectIncident={openIncident} />
              </div>
              <div className="card">
                <h3>
                  Real-time alarm feed
                  <span className="right small">
                    <label><input type="checkbox" style={{ width: 'auto', marginRight: 4 }} checked={activeOnly} onChange={(e) => setActiveOnly(e.target.checked)} />active only</label>
                  </span>
                </h3>
                <AlarmFeed alarms={snap.alarms} filter={activeOnly} onSelectIncident={openIncident} />
              </div>
            </div>
            <div className="grid" style={{ gap: 14, alignContent: 'start' }}>
              <div className="card">
                <h3>Correlated incidents</h3>
                <IncidentList incidents={incidents} selectedId={focusInc} onSelect={openIncident} />
              </div>
              <div className="card">
                <h3>System activity</h3>
                <EventLog events={snap.events} />
              </div>
            </div>
          </div>
        )}
        {tab === 'loop' && <ClosedLoopBoard incidents={incidents} onSelect={openIncident} />}
        {tab === 'auto' && (
          <div className="grid" style={{ gap: 14 }}>
            <div className="card">
              <h3>Autonomy level per device class × fault category</h3>
              <AutonomyMatrix policy={{ ...snap.closed_loop.policy, levels: snap.closed_loop.levels }} />
            </div>
            <Resilience snap={snap} onDrill={(d) => run(`/drills/${d}`, `Drill: ${d.replaceAll('_', ' ')}`)} />
          </div>
        )}
        {tab === 'trends' && <Trends snap={snap} />}
      </main>

      {incident && <IncidentDetail inc={incident} onClose={() => setSelInc(null)} />}
    </div>
  )
}
