import { useMemo } from 'react'
import { Bar, BarChart, CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis, Area, AreaChart } from 'recharts'
import { fmtSec, usePoll } from '../api.js'

// Categorical slots validated for the dark surface (dataviz validator): blue, orange, aqua.
const C1 = '#3987e5'
const C2 = '#d95926'
const C3 = '#199e70'
const AXIS = { stroke: '#4b5878', fontSize: 11, tickLine: false }
const GRID = <CartesianGrid stroke="#24304d" strokeDasharray="3 3" vertical={false} />
const TIP = { contentStyle: { background: '#172138', border: '1px solid #24304d', borderRadius: 8, fontSize: 12 }, labelStyle: { color: '#8d9ab8' } }

function Chart({ title, children, height = 200 }) {
  return (
    <div className="card">
      <h3>{title}</h3>
      <div style={{ height }}>
        <ResponsiveContainer width="100%" height="100%">{children}</ResponsiveContainer>
      </div>
    </div>
  )
}

function ModeBars({ data, field, title, unit }) {
  // Split one measure into two keys so rule-based vs AI days get distinct colors and a legend.
  const rows = data.map((d) => ({ day: d.day, 'Rule-based NOC': d.mode === 'rule' ? d[field] : null, 'AI closed loop': d.mode === 'ai' ? d[field] : null }))
  return (
    <Chart title={title}>
      <BarChart data={rows} barCategoryGap={2}>
        {GRID}
        <XAxis dataKey="day" {...AXIS} interval={4} />
        <YAxis {...AXIS} width={40} unit={unit} />
        <Tooltip {...TIP} cursor={{ fill: 'rgba(56,189,248,.08)' }} />
        <Legend wrapperStyle={{ fontSize: 12 }} />
        <Bar dataKey="Rule-based NOC" stackId="a" fill={C2} radius={[4, 4, 0, 0]} />
        <Bar dataKey="AI closed loop" stackId="a" fill={C1} radius={[4, 4, 0, 0]} />
      </BarChart>
    </Chart>
  )
}

export default function Trends({ snap }) {
  const { data: hist } = usePoll('/history/trends', 30000)
  const daily = hist?.daily || []
  const series = snap.series || []
  const k = snap.kpis || {}
  const summary = useMemo(() => {
    const avg = (rows, f) => (rows.length ? rows.reduce((s, r) => s + r[f], 0) / rows.length : null)
    const rule = daily.filter((d) => d.mode === 'rule'), ai = daily.filter((d) => d.mode === 'ai')
    return {
      rule: { mttd: avg(rule, 'mttd_min'), mttr: avg(rule, 'mttr_min'), comp: avg(rule, 'compression'), auto: avg(rule, 'auto_pct') },
      ai: { mttd: avg(ai, 'mttd_min'), mttr: avg(ai, 'mttr_min'), comp: avg(ai, 'compression'), auto: avg(ai, 'auto_pct') },
    }
  }, [daily])
  const f1 = (v) => (v === null || v === undefined ? '–' : v.toFixed(1))

  return (
    <div className="grid" style={{ gap: 14 }}>
      <div className="card">
        <h3>KPI comparison</h3>
        <table>
          <thead><tr><th>Metric</th><th>Rule-based NOC (days 1–15, history)</th><th>AI closed loop (days 16–30, history)</th><th>This live session</th></tr></thead>
          <tbody>
            <tr><td>Mean time to detect</td><td>{f1(summary.rule.mttd)} min</td><td>{f1(summary.ai.mttd)} min</td><td>{fmtSec(k.mttd_s)}</td></tr>
            <tr><td>Mean time to resolve</td><td>{f1(summary.rule.mttr)} min</td><td>{f1(summary.ai.mttr)} min</td><td>{fmtSec(k.mttr_s)} (autonomous {fmtSec(k.mttr_autonomous_s)}, human {fmtSec(k.mttr_operator_s)})</td></tr>
            <tr><td>Alarms per ticket / incident</td><td>{f1(summary.rule.comp)}</td><td>{f1(summary.ai.comp)}</td><td>{k.compression_ratio ?? '–'}</td></tr>
            <tr><td>Resolved without a human</td><td>{f1(summary.rule.auto)}%</td><td>{f1(summary.ai.auto)}%</td><td>{k.auto_resolution_pct ?? '–'}%</td></tr>
          </tbody>
        </table>
        <p className="muted small">History is synthetic seed data (30 days) stored in SQLite; live-session figures are measured from the running demo, where the simulator compresses hours into seconds.</p>
      </div>
      <div className="grid two">
        <Chart title="Live: ingest rate vs alarm rate (per second)">
          <LineChart data={series}>
            {GRID}
            <XAxis dataKey="t" {...AXIS} minTickGap={40} />
            <YAxis {...AXIS} width={40} />
            <Tooltip {...TIP} />
            <Legend wrapperStyle={{ fontSize: 12 }} />
            <Line type="monotone" dataKey="events_per_s" name="messages ingested/s" stroke={C1} strokeWidth={2} dot={false} isAnimationActive={false} />
            <Line type="monotone" dataKey="alarms_per_s" name="new alarms/s" stroke={C2} strokeWidth={2} dot={false} isAnimationActive={false} />
          </LineChart>
        </Chart>
        <Chart title="Live: ingestion queue depth">
          <AreaChart data={series}>
            {GRID}
            <XAxis dataKey="t" {...AXIS} minTickGap={40} />
            <YAxis {...AXIS} width={40} />
            <Tooltip {...TIP} />
            <Area type="monotone" dataKey="queue_depth" name="queue depth" stroke={C1} fill={C1} fillOpacity={0.2} strokeWidth={2} isAnimationActive={false} />
          </AreaChart>
        </Chart>
        <Chart title="Live: active alarms vs open incidents">
          <LineChart data={series}>
            {GRID}
            <XAxis dataKey="t" {...AXIS} minTickGap={40} />
            <YAxis {...AXIS} width={40} allowDecimals={false} />
            <Tooltip {...TIP} />
            <Legend wrapperStyle={{ fontSize: 12 }} />
            <Line type="stepAfter" dataKey="active_alarms" name="active alarms" stroke={C2} strokeWidth={2} dot={false} isAnimationActive={false} />
            <Line type="stepAfter" dataKey="open_incidents" name="open incidents" stroke={C3} strokeWidth={2} dot={false} isAnimationActive={false} />
          </LineChart>
        </Chart>
        <ModeBars data={daily} field="mttr_min" title="History: mean time to resolve per day (min)" />
        <ModeBars data={daily} field="mttd_min" title="History: mean time to detect per day (min)" />
        <ModeBars data={daily} field="compression" title="History: raw alarms per ticket/incident" />
        <ModeBars data={daily} field="auto_pct" title="History: incidents resolved without a human (%)" unit="%" />
        <ModeBars data={daily} field="raw_alarms" title="History: raw alarms per day" />
      </div>
    </div>
  )
}
