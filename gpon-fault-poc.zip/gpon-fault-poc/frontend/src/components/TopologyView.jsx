import { SEV_COLOR } from '../api.js'

const ROWS = ['Core', 'Aggregation', 'OLT', 'PON port', 'Splitter', 'ONT', 'Cell site']
const DOMAIN_COLOR = { gpon: 'var(--gpon)', g702: 'var(--g702)', ip: 'var(--ip)' }

function shortLabel(n) {
  if (n.class === 'ONT') return n.id.replace('ONT-', '')
  if (n.class === 'PONPort') return n.id.replace('PON-', 'P')
  if (n.class === 'Splitter') return n.id.replace('SPL-', 'S')
  return n.id
}

function Shape({ n, fill, stroke }) {
  const common = { className: 'shape', fill, stroke }
  switch (n.class) {
    case 'ONT':
      return <circle r={11} {...common} />
    case 'Splitter':
      return <polygon points="0,-12 12,0 0,12 -12,0" {...common} />
    case 'PONPort':
      return <rect x={-14} y={-9} width={28} height={18} rx={3} {...common} />
    case 'BTS':
      return <polygon points="0,-13 11,9 -11,9" {...common} />
    case 'OLT':
      return <rect x={-34} y={-14} width={68} height={28} rx={5} {...common} />
    default:
      return <rect x={-36} y={-14} width={72} height={28} rx={14} {...common} />
  }
}

export default function TopologyView({ topology, view, selected, onSelectEntity, focus, faults, showTruth }) {
  if (!topology) return <div className="muted">Loading topology…</div>
  const { layout, entities } = topology
  const byId = Object.fromEntries(layout.nodes.map((n) => [n.id, n]))
  const ent = Object.fromEntries(entities.map((e) => [e.id, e]))
  const focusSet = new Set(focus?.entities || [])
  const truth = new Set((faults || []).map((f) => f.entity))

  const statusOf = (id) => {
    const v = view[id] || {}
    return {
      sev: v.severity,
      root: !!v.root_of,
      impacted: !!v.impacted_by,
    }
  }
  const edgeColor = (e) => {
    const s = statusOf(e.id)
    if (s.root) return 'var(--sev-critical)'
    if (s.sev) return SEV_COLOR[s.sev]
    if (s.impacted) return 'var(--sev-major)'
    if (e.class === 'E1Circuit' || e.class === 'E3Trunk' || e.class === 'STM1Link') return 'var(--g702)'
    if (e.class === 'FiberSegment') return 'var(--gpon)'
    return '#3b4a6b'
  }

  return (
    <div className="topo">
      <svg viewBox={`0 0 ${layout.width} ${layout.height}`} role="img" aria-label="G.702 and GPON backhaul topology">
        {ROWS.map((r, i) => (
          <text key={r} className="rowlabel" x={6} y={40 + i * 92 - 20}>{r}</text>
        ))}
        {layout.edges.map((e) => {
          const a = byId[e.a], b = byId[e.b]
          if (!a || !b) return null
          const s = statusOf(e.id)
          const spl = ent[e.b]
          const standby = e.class === 'FiberSegment' && e.subtype === 'feeder' && spl && !spl.depends_on.includes(e.id)
          const dash = e.class === 'Containment' ? '2 4' : standby ? '6 5' : s.root ? '8 5' : undefined
          const width = s.root ? 4 : e.class === 'CoreLink' || e.class === 'EthernetUplink' ? 2.5 : 1.6
          const midX = (a.x + b.x) / 2, midY = (a.y + b.y) / 2
          return (
            <g key={e.id} onClick={() => onSelectEntity(e.id)} style={{ cursor: e.class === 'Containment' ? 'default' : 'pointer' }}>
              <line x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke="transparent" strokeWidth={10} />
              <line x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke={e.class === 'Containment' ? '#3b4a6b' : edgeColor(e)}
                strokeWidth={width} strokeDasharray={dash} opacity={standby ? 0.7 : 1} />
              {s.root && (
                <g transform={`translate(${midX},${midY})`}>
                  <circle r={13} fill="var(--bg)" stroke="var(--sev-critical)" strokeWidth={2} className="root-ring" />
                  <text textAnchor="middle" dy={4} style={{ fontSize: 10, fontWeight: 700 }}>RC</text>
                </g>
              )}
              {showTruth && truth.has(e.id) && (
                <text x={midX + 14} y={midY} style={{ fontSize: 10, fill: '#fca5a5' }}>⚡</text>
              )}
              {(e.subtype === 'feeder' || e.class === 'E1Circuit') && (
                <text x={midX + 6} y={midY - 2} style={{ fontSize: 9, fill: 'var(--muted)' }}>{e.id}</text>
              )}
            </g>
          )
        })}
        {layout.nodes.map((n) => {
          const s = statusOf(n.id)
          const base = DOMAIN_COLOR[n.domain] || 'var(--ip)'
          const fill = s.sev ? SEV_COLOR[s.sev] : s.impacted ? 'rgba(251,146,60,.25)' : '#16213a'
          const stroke = s.root ? 'var(--sev-critical)' : s.impacted ? 'var(--sev-major)' : base
          const dim = focusSet.size > 0 && !focusSet.has(n.id)
          return (
            <g key={n.id} className="node" transform={`translate(${n.x},${n.y})`} opacity={dim ? 0.35 : 1}
              onClick={() => onSelectEntity(n.id)}>
              {selected === n.id && <circle r={22} fill="none" stroke="var(--accent)" strokeWidth={2} />}
              {s.root && <circle r={24} fill="none" stroke="var(--sev-critical)" strokeWidth={3} className="root-ring" />}
              <Shape n={n} fill={fill} stroke={stroke} />
              <text textAnchor="middle" dy={n.class === 'ONT' || n.class === 'Splitter' || n.class === 'BTS' ? 26 : 4}
                style={{ fontSize: n.class === 'ONT' || n.class === 'BTS' ? 10 : 11, fill: s.sev && n.class !== 'ONT' && n.class !== 'Splitter' && n.class !== 'BTS' ? '#0b1020' : undefined, fontWeight: 600 }}>
                {shortLabel(n)}
              </text>
              {showTruth && truth.has(n.id) && <text x={14} y={-12} style={{ fontSize: 12, fill: '#fca5a5' }}>⚡</text>}
            </g>
          )
        })}
      </svg>
      <div className="legend">
        <span><i style={{ background: 'var(--gpon)' }} />GPON (OLT, PON, ODN, ONT)</span>
        <span><i style={{ background: 'var(--g702)' }} />G.702 (E1/E3, PDH mux, CES, BSC, BTS)</span>
        <span><i style={{ background: 'var(--ip)' }} />IP aggregation / core</span>
        <span><i style={{ background: 'var(--sev-critical)' }} />critical</span>
        <span><i style={{ background: 'var(--sev-major)' }} />major / impacted</span>
        <span><i style={{ background: 'var(--sev-minor)' }} />minor</span>
        <span><i style={{ background: 'var(--sev-warning)' }} />warning</span>
        <span>◯ pulsing = AI root cause · RC = inferred passive fault · dashed feeder = standby</span>
        {showTruth && <span>⚡ = simulator ground truth</span>}
      </div>
    </div>
  )
}
