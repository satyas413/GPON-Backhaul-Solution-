import { useState } from 'react'
import { api, fmtTime } from '../api.js'

const CAT_LABEL = {
  link_down: 'Link down', signal_degradation: 'Signal degr.', timing_sync: 'Timing/sync',
  equipment: 'Equipment', configuration: 'Config', performance: 'Performance',
}

export function AutonomyMatrix({ policy, onChanged }) {
  const [err, setErr] = useState(null)
  if (!policy) return null
  const set = async (device_class, category, level) => {
    try { await api('/policy/matrix', 'PUT', { device_class, category, level }); setErr(null); onChanged?.() } catch (e) { setErr(e.message) }
  }
  const setG = async (key, value) => {
    try { await api('/policy/guardrails', 'PUT', { key, value }); setErr(null); onChanged?.() } catch (e) { setErr(e.message) }
  }
  const g = policy.guardrails
  return (
    <div>
      <div className="scroll">
        <table>
          <thead>
            <tr><th>Device class</th>{policy.fault_categories.map((c) => <th key={c}>{CAT_LABEL[c] || c}</th>)}</tr>
          </thead>
          <tbody>
            {policy.device_classes.map((dc) => (
              <tr key={dc}>
                <td><b>{dc}</b></td>
                {policy.fault_categories.map((c) => {
                  const lv = policy.matrix[dc][c]
                  return (
                    <td key={c}>
                      <select className={`lv-${lv}`} value={lv} onChange={(e) => set(dc, c, e.target.value)} aria-label={`${dc} ${c}`}>
                        {policy.levels.map((l) => <option key={l} value={l}>{l}</option>)}
                      </select>
                    </td>
                  )
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="section">
        <h4>Guardrails (autonomy boundaries)</h4>
        <div className="kv" style={{ gridTemplateColumns: '260px 1fr', alignItems: 'center' }}>
          <div>Max risk for autonomous actions</div>
          <div>
            <select value={g.max_risk_autonomous} onChange={(e) => setG('max_risk_autonomous', e.target.value)}>
              {['low', 'medium', 'high'].map((r) => <option key={r}>{r}</option>)}
            </select>
          </div>
          <div>Max blast radius (services) for autonomy</div>
          <div><input type="number" min={0} defaultValue={g.max_blast_radius_autonomous} onBlur={(e) => setG('max_blast_radius_autonomous', e.target.value)} /></div>
          <div>Min RCA confidence for autonomy</div>
          <div><input type="number" step="0.05" min={0} max={1} defaultValue={g.min_rca_confidence_autonomous} onBlur={(e) => setG('min_rca_confidence_autonomous', e.target.value)} /></div>
          <div>Max actions per element per hour</div>
          <div><input type="number" min={0} defaultValue={g.max_actions_per_device_per_hour} onBlur={(e) => setG('max_actions_per_device_per_hour', e.target.value)} /></div>
          <div>Safe-mode ceiling (AI unavailable)</div>
          <div>
            <select value={g.safe_mode_level} onChange={(e) => setG('safe_mode_level', e.target.value)}>
              {policy.levels.map((l) => <option key={l}>{l}</option>)}
            </select>
          </div>
        </div>
        <div className="actions-bar">
          <button className="btn small" onClick={async () => { await api('/policy/reset', 'POST'); onChanged?.() }}>Reset policy to defaults</button>
          {err && <span style={{ color: 'var(--sev-critical)' }} className="small">{err}</span>}
        </div>
        <p className="muted small">
          Advisory: AI recommends, a human executes. Supervised: AI prepares the action and runs it after approval.
          Autonomous: AI executes and verifies; actions above the risk / blast-radius limits or the hourly rate limit are escalated.
        </p>
      </div>
    </div>
  )
}

function Stat({ label, value }) {
  return <div className="stat"><b>{value ?? '–'}</b><span>{label}</span></div>
}

export function Resilience({ snap, onDrill }) {
  const ing = snap.ingestion
  const corr = snap.correlation
  const ai = snap.ai
  const fill = Math.min(100, (100 * ing.queue_depth) / ing.capacity)
  const wm = (100 * ing.high_watermark) / ing.capacity
  const last = snap.drills.last || {}
  const breakers = Object.entries(snap.closed_loop.breakers || {})
  const drills = [
    { k: 'alarm_storm', t: 'Alarm storm / backpressure', d: 'Burst of ~3,500 messages while a real fault occurs. Watch the queue gauge, shedding and retries.' },
    { k: 'duplicates_out_of_order', t: 'Duplicate & out-of-order replay', d: 'Replays recent traps/syslog/events twice, shuffled, plus stale clears older than their raises.' },
    { k: 'crash_correlation_engine', t: 'Correlation engine failover', d: 'Kills the active engine. The standby restores the checkpoint and replays the log.' },
    { k: 'ai_outage', t: snap.drills.ai_outage ? 'Restore AI service' : 'AI service outage (safe mode)', d: 'Rule-based correlation/RCA and an advisory ceiling while AI is down.', on: snap.drills.ai_outage },
    { k: 'device_unreachable', t: snap.drills.device_unreachable ? 'Restore OLT-B management' : 'OLT-B management unreachable', d: 'Actions on OLT-B time out, the circuit breaker opens and the loop escalates.', on: snap.drills.device_unreachable },
  ]
  return (
    <div className="grid two">
      <div className="card">
        <h3>Fault-tolerance drills</h3>
        {drills.map((x) => (
          <div className="drill" key={x.k}>
            <div className="d"><b>{x.t}</b>{x.d}</div>
            <button className={`btn small ${x.on ? 'active' : 'warn'}`} onClick={() => onDrill(x.k)}>{x.on ? 'Turn off' : 'Run'}</button>
          </div>
        ))}
        {last.alarm_storm && (
          <div className="callout" style={{ marginTop: 8 }}>
            <b>Last storm:</b> peak queue {last.alarm_storm.peak_queue}, accepted {last.alarm_storm.accepted}, shed {last.alarm_storm.shed_low_priority},
            rejected (full) {last.alarm_storm.rejected_full}, source retries {last.alarm_storm.source_retries}, stale telemetry dropped {last.alarm_storm.telemetry_stale_dropped};
            real fault alarm delivered: <b style={{ color: last.alarm_storm.critical_alarm_delivered ? 'var(--ok)' : 'var(--sev-critical)' }}>{String(last.alarm_storm.critical_alarm_delivered)}</b>
          </div>
        )}
        {last.duplicates_out_of_order?.duplicates_dropped !== undefined && (
          <div className="callout" style={{ marginTop: 8 }}>
            <b>Last replay:</b> {last.duplicates_out_of_order.replayed} messages replayed → {last.duplicates_out_of_order.duplicates_dropped} duplicates dropped,
            {' '}{last.duplicates_out_of_order.reordered} re-ordered, {last.duplicates_out_of_order.stale_ignored} stale clears ignored
          </div>
        )}
      </div>

      <div className="card">
        <h3>Ingestion pipeline <span className="right badge">{ing.state}</span></h3>
        <div className="gauge" title={`${ing.queue_depth}/${ing.capacity}`}>
          <div style={{ width: `${fill}%`, background: fill > wm ? 'var(--sev-major)' : 'var(--accent)' }} />
          <div className="wm" style={{ left: `${wm}%` }} />
        </div>
        <div className="muted small" style={{ marginTop: 4 }}>Queue {ing.queue_depth}/{ing.capacity} (shed above {ing.high_watermark}) · peak {ing.peak_depth} · re-order buffer {ing.reorder_buffer} · log offset {ing.log_end}</div>
        <div className="stat-grid">
          <Stat label="received" value={ing.stats.received} />
          <Stat label="shed (low priority)" value={ing.stats.shed_low_priority} />
          <Stat label="rejected (full)" value={ing.stats.rejected_full} />
          <Stat label="duplicates dropped" value={ing.stats.duplicates} />
          <Stat label="re-ordered" value={ing.stats.reordered} />
          <Stat label="late events" value={ing.stats.late} />
          <Stat label="stale ignored" value={snap.engine_stats?.stale_ignored} />
          <Stat label="dead-lettered" value={ing.stats.malformed} />
        </div>
        <table style={{ marginTop: 10 }}>
          <thead><tr><th>Source</th><th>Sent</th><th>Buffered</th><th>Retries</th><th>Backoff</th><th>Stale dropped</th></tr></thead>
          <tbody>
            {snap.sources.map((s) => (
              <tr key={s.name}><td>{s.name}</td><td>{s.sent}</td><td>{s.buffered}</td><td>{s.retries}</td><td>{s.backoff_s}s</td><td>{s.dropped_stale}</td></tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="card">
        <h3>Correlation engine (active / standby) <span className="right badge">{corr.status}</span></h3>
        <table>
          <thead><tr><th>Instance</th><th>Role</th><th>Heartbeat age</th><th>Log offset</th><th>Note</th></tr></thead>
          <tbody>
            {corr.instances.map((e) => (
              <tr key={e.name}>
                <td><b>{e.name}</b></td>
                <td style={{ color: e.role === 'leader' ? 'var(--ok)' : e.role === 'crashed' ? 'var(--sev-critical)' : undefined }}>{e.role}</td>
                <td>{e.role === 'leader' ? `${e.heartbeat_age_s}s` : '–'}</td>
                <td>{e.offset ?? '–'}</td>
                <td className="small">{e.restart_in_s ? `restarts in ${e.restart_in_s}s` : ''}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="muted small" style={{ marginTop: 6 }}>Consumer lag: {corr.lag ?? '–'} events · checkpoint every 1 s · failover after 2.5 s without heartbeat</div>
        {corr.failovers.length > 0 && (
          <div className="section">
            <h4>Failovers</h4>
            {corr.failovers.map((f, i) => (
              <div key={i} className="small">{fmtTime(f.ts)}: {f.from} → {f.to}, detected in {f.detection_s}s, restored checkpoint @ {f.checkpoint_offset}, replayed {f.replayed_events} events in {f.restore_ms} ms</div>
            ))}
          </div>
        )}
      </div>

      <div className="card">
        <h3>AI component <span className="right badge" style={{ color: ai.up ? 'var(--ok)' : 'var(--sev-critical)' }}>{ai.up ? 'up' : 'DOWN · safe mode'}</span></h3>
        <div className="stat-grid">
          <Stat label="inferences" value={ai.stats.inferences} />
          <Stat label="anomalies raised" value={ai.stats.anomalies_raised} />
          <Stat label="predictions" value={ai.stats.predictions_raised} />
          <Stat label="RCA runs" value={ai.stats.rca_runs} />
        </div>
        <div className="kv" style={{ marginTop: 10 }}>
          <div>Alarm-rate model</div><div>{ai.storm.rate_per_s}/s · z={ai.storm.z} {ai.storm.active && <b style={{ color: 'var(--sev-major)' }}>STORM</b>}</div>
          <div>Models</div><div className="small">{Object.entries(ai.models).map(([k, v]) => `${k}: ${v}`).join(' · ')}</div>
          <div>Active anomalies</div><div className="mono">{Object.entries(ai.anomalies).map(([k, v]) => `${k} (${v.feature} z=${v.z})`).join(', ') || '–'}</div>
          <div>Active predictions</div><div className="mono">{Object.entries(ai.predictions).map(([k, v]) => `${k}: ${v.metric} ${v.current} dBm, ${v.slope_db_per_min} dB/min, crosses in ${v.time_to_threshold_s}s (p=${v.probability})`).join(', ') || '–'}</div>
          <div>Circuit breakers</div><div>{breakers.length ? breakers.map(([k, v]) => `${k}: ${v.state}${v.retry_in_s ? ` (retry in ${v.retry_in_s}s)` : ''}`).join(', ') : 'all closed'}</div>
          <div>Dead-letter queue</div><div className="mono small">{ing.dlq.length ? ing.dlq.map((d) => d.error).join('; ') : 'empty'}</div>
        </div>
      </div>
    </div>
  )
}
