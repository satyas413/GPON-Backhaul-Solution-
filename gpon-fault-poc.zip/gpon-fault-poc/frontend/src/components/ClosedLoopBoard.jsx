import { fmtTime } from '../api.js'
import { IncidentCard } from './Panels.jsx'

const COLS = [
  { key: 'approval', title: 'Awaiting approval', match: (i) => i.phase === 'awaiting_approval' },
  { key: 'advisory', title: 'Advisory (recommendations)', match: (i) => i.phase === 'advisory' },
  { key: 'running', title: 'Executing / verifying / watching', match: (i) => ['acting', 'verifying', 'watching', 'detected'].includes(i.phase) },
  { key: 'escalated', title: 'Escalated to NOC', match: (i) => i.phase === 'escalated' },
]

export default function ClosedLoopBoard({ incidents, onSelect }) {
  const open = incidents.filter((i) => i.status !== 'resolved')
  const actions = incidents.flatMap((i) => i.loop.actions.map((a) => ({ ...a, incTitle: i.title })))
    .sort((a, b) => b.started_ts - a.started_ts)
  return (
    <div className="grid" style={{ gap: 14 }}>
      <div className="kanban">
        {COLS.map((c) => {
          const items = open.filter(c.match)
          return (
            <div key={c.key} className="col">
              <h4><span>{c.title}</span><span className="badge">{items.length}</span></h4>
              {items.map((i) => <IncidentCard key={i.id} inc={i} onClick={() => onSelect(i.id)} />)}
            </div>
          )
        })}
      </div>
      <div className="card">
        <h3>Action log: executed actions and post-action verification</h3>
        <div className="scroll" style={{ maxHeight: 360 }}>
          <table>
            <thead>
              <tr><th>Started</th><th>Action</th><th>Incident</th><th>Target</th><th>Mode</th><th>Protocol</th><th>Status</th><th>Verification</th><th>Result</th></tr>
            </thead>
            <tbody>
              {actions.length === 0 && <tr><td colSpan={9} className="muted">No actions yet.</td></tr>}
              {actions.map((a) => (
                <tr key={a.id} className="click" onClick={() => onSelect(a.incident)}>
                  <td className="mono">{fmtTime(a.started_ts)}</td>
                  <td><b>{a.id}</b> {a.action}</td>
                  <td className="mono">{a.incident}</td>
                  <td className="mono">{a.target}</td>
                  <td>{a.mode}</td>
                  <td>{a.protocol}</td>
                  <td style={{ color: a.status === 'failed' ? 'var(--sev-critical)' : undefined }}>{a.status}</td>
                  <td style={{ color: a.verification?.status === 'passed' ? 'var(--ok)' : a.verification?.status === 'failed' ? 'var(--sev-critical)' : undefined }}>
                    {a.verification ? `${a.verification.status}${a.verification.relapses ? ` (relapse ×${a.verification.relapses})` : ''}` : '–'}
                  </td>
                  <td className="small">{a.result?.message || '…'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
