import { useEffect, useState } from 'react'
import { api, fmtSec, fmtTime, PHASE_LABEL, SEV_COLOR } from '../api.js'

const STEPS = ['detect', 'analyze', 'decide', 'act', 'verify']

function Stepper({ inc }) {
  const seen = new Set(inc.timeline.map((t) => t.phase))
  const lastAct = inc.loop.actions[inc.loop.actions.length - 1]
  const vfail = lastAct?.verification?.status === 'failed'
  const terminal = inc.phase === 'resolved' ? 'Resolved' : inc.phase === 'escalated' ? 'Escalated' : null
  return (
    <div className="stepper">
      {STEPS.map((s) => {
        const done = seen.has(s) && !(s === 'verify' && vfail)
        const cur = !done && (STEPS.indexOf(s) === STEPS.findIndex((x) => !seen.has(x)))
        return (
          <div key={s} className={`step ${done ? 'done' : ''} ${cur && !terminal ? 'cur' : ''} ${s === 'verify' && vfail ? 'fail' : ''}`}>
            {s[0].toUpperCase() + s.slice(1)}
          </div>
        )
      })}
      <div className={`step ${terminal === 'Resolved' ? 'done' : ''} ${terminal === 'Escalated' ? 'fail' : ''}`}>
        {terminal || 'Close'}
      </div>
    </div>
  )
}

export default function IncidentDetail({ inc, onClose, onChanged }) {
  const [full, setFull] = useState(null)
  const [busy, setBusy] = useState(false)
  const [msg, setMsg] = useState(null)
  const [alarmSel, setAlarmSel] = useState(null)

  useEffect(() => {
    let alive = true
    api(`/incidents/${inc.id}`).then((d) => alive && setFull(d)).catch(() => {})
    return () => { alive = false }
  }, [inc.id, inc.alarms.length, inc.phase])

  const op = async (name, note) => {
    setBusy(true)
    setMsg(null)
    try {
      await api(`/incidents/${inc.id}/${name}`, 'POST', { note })
      setMsg({ ok: true, text: `${name} sent` })
      onChanged?.()
    } catch (e) {
      setMsg({ ok: false, text: e.message })
    } finally {
      setBusy(false)
    }
  }

  const loop = inc.loop
  const pending = loop.pending
  const dec = loop.decision
  const esc = loop.escalation
  const h = inc.rca?.hypotheses || []
  const rec = inc.recommendation || []
  const m = inc.metrics || {}

  return (
    <>
      <div className="drawer-bg" onClick={onClose} />
      <aside className="drawer" aria-label={`Incident ${inc.id}`}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span className="badge sev" style={{ background: SEV_COLOR[inc.severity] }}>{inc.severity}</span>
          <span className={`badge phase-${inc.phase}`}>{PHASE_LABEL[inc.phase] || inc.phase}</span>
          <span className="badge">{inc.kind}</span>
          <span className="muted small">{inc.id} · opened {fmtTime(inc.created_ts)}</span>
          <button className="btn small" style={{ marginLeft: 'auto' }} onClick={onClose}>Close</button>
        </div>
        <h2>{inc.title || 'Correlating alarms…'}</h2>
        <Stepper inc={inc} />

        <div className="actions-bar">
          {inc.phase === 'awaiting_approval' && pending && (
            <>
              <button className="btn good" disabled={busy} onClick={() => op('approve')}>Approve: {pending.action} → {pending.target_entity}</button>
              <button className="btn bad" disabled={busy} onClick={() => op('reject')}>Reject</button>
            </>
          )}
          {inc.phase === 'advisory' && pending && (
            <>
              <button className="btn primary" disabled={busy} onClick={() => op('execute')}>Execute recommendation: {pending.action}</button>
              <button className="btn bad" disabled={busy} onClick={() => op('reject')}>Dismiss</button>
            </>
          )}
          {inc.phase === 'escalated' && (
            <>
              {pending && <button className="btn warn" disabled={busy} onClick={() => op('approve')}>Approve proposed: {pending.action}</button>}
              {!esc?.acked && <button className="btn" disabled={busy} onClick={() => op('ack')}>Acknowledge</button>}
              <button className="btn good" disabled={busy} onClick={() => op('resolve', 'field fix applied')}>Resolve (field fix applied)</button>
            </>
          )}
          {inc.status === 'resolved' && loop.follow_up && !loop.follow_up.closed && (
            <button className="btn good" disabled={busy} onClick={() => op('resolve', 'field repair completed')}>
              Close follow-up {loop.follow_up.ticket} (repair done)
            </button>
          )}
          {msg && <span className={msg.ok ? 'small' : 'small'} style={{ color: msg.ok ? 'var(--ok)' : 'var(--sev-critical)' }}>{msg.text}</span>}
        </div>

        {esc && (
          <div className="section callout bad">
            <b>Escalated to NOC · {esc.ticket}</b> {esc.acked && <span className="badge">acknowledged</span>}
            <div style={{ marginTop: 4 }}>{esc.reason}</div>
            {esc.proposed && <div className="muted" style={{ marginTop: 4 }}>Proposed next action awaiting a human: <b>{esc.proposed}</b></div>}
          </div>
        )}
        {loop.follow_up && (
          <div className={`section callout ${loop.follow_up.closed ? 'good' : ''}`}>
            <b>Follow-up {loop.follow_up.ticket}</b> {loop.follow_up.closed ? '(closed)' : '(open)'} — {loop.follow_up.text}
          </div>
        )}

        <div className="section">
          <h4>Metrics</h4>
          <div className="kv">
            <div>MTTD (fault → incident)</div><div>{fmtSec(m.mttd_s)}</div>
            <div>Time to analyze</div><div>{fmtSec(m.time_to_analyze_s)}</div>
            <div>Time to decision</div><div>{fmtSec(m.time_to_decide_s)}</div>
            <div>Time to first action</div><div>{fmtSec(m.time_to_act_s)}</div>
            <div>MTTR (fault → restored)</div><div>{fmtSec(m.mttr_s)} {inc.resolved_by && <span className="muted">· {inc.resolved_by}</span>}</div>
            {m.lead_time_s !== undefined && (<><div>Prediction lead time</div><div>{fmtSec(m.lead_time_s)}</div></>)}
            <div>Correlated alarms</div><div>{inc.alarms.length} alarms on {inc.entities.length} entities</div>
          </div>
        </div>

        {h.length > 0 && (
          <div className="section">
            <h4>Root cause analysis · {inc.rca.method} · {inc.rca.candidates_scored ? `${inc.rca.candidates_scored} candidates scored` : ''}</h4>
            {h.slice(0, 5).map((x, i) => (
              <div key={x.entity} style={{ marginBottom: 8 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12 }}>
                  <span><b>{i === 0 ? '★ ' : ''}{x.entity}</b> <span className="muted">{x.class}</span></span>
                  <span>{x.confidence !== null ? `${(x.confidence * 100).toFixed(1)}%` : 'rule'}</span>
                </div>
                {x.confidence !== null && <div className="bar"><div style={{ width: `${x.confidence * 100}%`, background: i === 0 ? 'var(--accent)' : '#475569' }} /></div>}
                <div className="muted small">
                  explains {Math.round(x.coverage * 100)}% of alarms
                  {x.healthy_dependents !== null && ` · ${x.healthy_dependents} healthy dependents`}
                  {x.prior !== null && ` · prior ${x.prior}`}
                  {x.evidence?.length > 0 && ` · ${x.evidence.join('; ')}`}
                </div>
              </div>
            ))}
          </div>
        )}

        {inc.impact && (
          <div className="section">
            <h4>Impact (downstream of {inc.impact.root})</h4>
            <div className="kv">
              <div>Blast radius</div><div>{inc.impact.blast_radius} services · {inc.impact.cell_sites.length} cell sites · {inc.impact.subscribers.toLocaleString()} subscribers</div>
              <div>Services</div><div className="mono">{inc.impact.services.join(', ') || '–'}</div>
              <div>Cell sites</div><div className="mono">{inc.impact.cell_sites.join(', ') || '–'}</div>
              <div>Upstream path</div><div className="mono">{inc.impact.path_to_core.join(' → ')}</div>
            </div>
          </div>
        )}

        {dec && (
          <div className="section">
            <h4>Decision (autonomy policy)</h4>
            <div className="kv">
              <div>Policy cell</div><div>{dec.policy_key}</div>
              <div>Configured level</div><div>{dec.configured_level}</div>
              <div>Effective level</div><div><b>{dec.effective_level}</b>{!dec.ai_available && ' (safe mode)'}</div>
              <div>Proposed action</div><div>{dec.action} on {dec.target} (risk {dec.risk})</div>
              {dec.reasons.length > 0 && (<><div>Adjustments</div><div>{dec.reasons.join('; ')}</div></>)}
              {dec.boundary_violations.length > 0 && (<><div>Boundary</div><div style={{ color: 'var(--sev-critical)' }}>{dec.boundary_violations.join('; ')}</div></>)}
            </div>
          </div>
        )}

        {rec.length > 0 && (
          <div className="section">
            <h4>Recommended remediation</h4>
            {rec.slice(0, 3).map((p, i) => (
              <div key={p.id} className="callout" style={{ marginBottom: 6, opacity: i === 0 ? 1 : 0.7 }}>
                <b>{i === 0 ? 'Selected: ' : ''}{p.name}</b>
                {p.success_rate !== null && <span className="muted"> · historical success {Math.round(p.success_rate * 100)}% (n={p.history_n})</span>}
                <ol style={{ margin: '4px 0 0', paddingLeft: 18 }}>
                  {p.steps.map((s, j) => <li key={j}>{s.description} <span className="muted">[{s.action}, risk {s.risk}]</span></li>)}
                </ol>
                {i === 0 && p.similar_incidents?.count > 0 && (
                  <div className="muted" style={{ marginTop: 4 }}>
                    {p.similar_incidents.count} similar past incidents; median MTTR {p.similar_incidents.median_mttr_min} min
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {loop.actions.length > 0 && (
          <div className="section">
            <h4>Actions and verification</h4>
            {loop.actions.map((a) => (
              <div key={a.id} className={`callout ${a.verification?.status === 'passed' ? 'good' : a.status === 'failed' || a.verification?.status === 'failed' ? 'bad' : ''}`} style={{ marginBottom: 6 }}>
                <b>{a.id}</b> {a.action} → {a.target} <span className="muted">via {a.protocol} · {a.mode}</span>
                <div>Status: <b>{a.status}</b>{a.result?.message && ` — ${a.result.message}`}{a.result?.attempts !== undefined && ` (attempts ${a.result.attempts})`}</div>
                {a.verification && (
                  <div>
                    Verification: <b>{a.verification.status}</b> over {a.verification.window_s}s window
                    {a.verification.relapses > 0 && <span style={{ color: 'var(--sev-critical)' }}> · relapsed {a.verification.relapses}×</span>}
                    <div className="mono muted" style={{ marginTop: 3 }}>
                      {a.verification.checks.map((c, i) => (
                        <span key={i} title={JSON.stringify(c.kpi)} style={{ color: c.ok ? 'var(--ok)' : 'var(--sev-critical)', marginRight: 4 }}>{c.ok ? '●' : '○'}</span>
                      ))}
                      {a.verification.checks.length > 0 && a.verification.checks[a.verification.checks.length - 1].kpi?.metric &&
                        ` ${a.verification.checks[a.verification.checks.length - 1].kpi.metric}=${a.verification.checks[a.verification.checks.length - 1].kpi.value ?? 'n/a'}`}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        <div className="section">
          <h4>Correlated alarms (click for enrichment)</h4>
          <div className="scroll" style={{ maxHeight: 260 }}>
            <table>
              <thead><tr><th>Time</th><th>Sev</th><th>Type</th><th>Entity</th><th>Source</th><th>State</th></tr></thead>
              <tbody>
                {(full?.alarm_records || []).map((a) => (
                  <tr key={a.id} className={`click ${a.state === 'cleared' ? 'cleared' : ''}`} onClick={() => setAlarmSel(a)}>
                    <td>{fmtTime(a.first_ts)}</td>
                    <td><span className="badge sev" style={{ background: SEV_COLOR[a.severity] }}>{a.severity}</span></td>
                    <td>{a.type}</td><td className="mono">{a.entity}</td><td>{a.reporter} · {a.source}</td><td>{a.state}{a.count > 1 ? ` ×${a.count}` : ''}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {alarmSel && (
            <div className="callout" style={{ marginTop: 8 }}>
              <b>{alarmSel.type}</b> on {alarmSel.entity} <span className="muted">— {alarmSel.ref}</span>
              <div className="kv" style={{ marginTop: 6 }}>
                <div>Topology</div><div>{alarmSel.enrichment.topology.layer} / {alarmSel.enrichment.topology.domain} · OLT {alarmSel.enrichment.topology.olt || '–'} · PON {alarmSel.enrichment.topology.pon_port || '–'} · splitter {alarmSel.enrichment.topology.splitter || '–'}</div>
                <div>Managed by</div><div>{alarmSel.enrichment.topology.managed_by} · site {alarmSel.enrichment.topology.site || '–'}</div>
                <div>Device</div><div>{Object.entries(alarmSel.enrichment.device).map(([k, v]) => `${k}: ${v}`).join(' · ') || '–'}</div>
                <div>Impact</div><div>{alarmSel.enrichment.impact.service_count} services, {alarmSel.enrichment.impact.cell_sites.length} cell sites, {alarmSel.enrichment.impact.subscribers} subscribers</div>
                <div>History (30 d)</div><div>{alarmSel.enrichment.history.incidents_30d} incidents · MTBF {alarmSel.enrichment.history.mtbf_days ?? '–'} d · last {alarmSel.enrichment.history.last_incident_days_ago ?? '–'} d ago</div>
                {Object.keys(alarmSel.detail || {}).length > 0 && (<><div>Detail</div><div className="mono">{JSON.stringify(alarmSel.detail)}</div></>)}
              </div>
            </div>
          )}
        </div>

        <div className="section">
          <h4>Closed-loop timeline</h4>
          <ul className="timeline">
            {inc.timeline.map((t, i) => (
              <li key={i}><span className="muted mono">{fmtTime(t.ts)}</span> <span className="ph">{t.phase}</span>{t.msg}</li>
            ))}
          </ul>
        </div>
      </aside>
    </>
  )
}
