import { useEffect, useRef, useState } from 'react'

export async function api(path, method = 'GET', body) {
  const res = await fetch(`/api${path}`, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(data.detail || `HTTP ${res.status}`)
  return data
}

// Poll an endpoint; keeps the last good value and reports link health so the UI degrades gracefully.
export function usePoll(path, intervalMs) {
  const [data, setData] = useState(null)
  const [error, setError] = useState(null)
  const [lastOk, setLastOk] = useState(null)
  const busy = useRef(false)
  useEffect(() => {
    let alive = true
    const tick = async () => {
      if (busy.current) return
      busy.current = true
      try {
        const d = await api(path)
        if (alive) { setData(d); setError(null); setLastOk(Date.now()) }
      } catch (e) {
        if (alive) setError(e.message)
      } finally {
        busy.current = false
      }
    }
    tick()
    const id = setInterval(tick, intervalMs)
    return () => { alive = false; clearInterval(id) }
  }, [path, intervalMs])
  return { data, error, lastOk }
}

export const SEV_COLOR = {
  critical: 'var(--sev-critical)', major: 'var(--sev-major)', minor: 'var(--sev-minor)',
  warning: 'var(--sev-warning)', info: 'var(--sev-info)', cleared: 'var(--ok)',
}

export const PHASE_LABEL = {
  detected: 'Detecting', analyzed: 'Analyzing', advisory: 'Advisory', awaiting_approval: 'Awaiting approval',
  acting: 'Acting', verifying: 'Verifying', watching: 'Watching', escalated: 'Escalated', resolved: 'Resolved',
}

export const fmtTime = (ts) => (ts ? new Date(ts * 1000).toLocaleTimeString([], { hour12: false }) : '–')
export const fmtSec = (s) => {
  if (s === null || s === undefined) return '–'
  if (s < 90) return `${Number(s).toFixed(1)} s`
  if (s < 5400) return `${(s / 60).toFixed(1)} min`
  return `${(s / 3600).toFixed(1)} h`
}
export const pct = (v) => (v === null || v === undefined ? '–' : `${v}%`)
