"""Closed-loop control: detect -> analyze -> decide -> act -> verify (-> escalate).

* Detect: incidents are opened by the correlation engine; a hold-down lets the alarm burst settle.
* Analyze: AI RCA (Bayesian, topology-aware) with rule-based fallback, impact, enrichment, playbook ranking.
* Decide: autonomy policy (advisory / supervised / autonomous per device class x fault category) and
  guardrails (risk, blast radius, RCA confidence, rate limit, safe-mode ceiling).
* Act: device adapter with retries, timeouts and a per-element circuit breaker.
* Verify: post-action telemetry and alarm state over a verification window (relapses fail it); on failure
  the next playbook step is tried, and the loop escalates to a human when none remains or the next step
  is outside the autonomy boundary.
"""
from __future__ import annotations

import asyncio
import copy
import random
import time

from .ai import AIUnavailable, rule_based_rca
from .ontology import load_yaml

LEVELS = ["advisory", "supervised", "autonomous"]
RISK = {"none": 0, "low": 1, "medium": 2, "high": 3}
CATEGORY_PRIORITY = ["link_down", "equipment", "signal_degradation", "timing_sync", "configuration", "performance"]
SERVICE_SEVERITIES = {"critical", "major", "minor"}


class Policy:
    def __init__(self):
        self.spec = load_yaml("policy.yaml")
        self.default = copy.deepcopy(self.spec)

    @property
    def matrix(self) -> dict:
        return self.spec["matrix"]

    @property
    def guardrails(self) -> dict:
        return self.spec["guardrails"]

    def level(self, policy_class: str, category: str) -> str:
        return self.matrix.get(policy_class, {}).get(category, "advisory")

    def set_level(self, policy_class: str, category: str, level: str) -> None:
        if level not in LEVELS:
            raise ValueError(f"level must be one of {LEVELS}")
        if policy_class not in self.matrix or category not in self.spec["fault_categories"]:
            raise ValueError("unknown device class or fault category")
        self.matrix[policy_class][category] = level

    def set_guardrail(self, key: str, value) -> None:
        if key not in self.guardrails:
            raise ValueError(f"unknown guardrail {key}")
        cur = self.guardrails[key]
        self.guardrails[key] = type(cur)(value) if not isinstance(cur, str) else str(value)

    def reset(self) -> None:
        self.spec = copy.deepcopy(self.default)


def min_level(a: str, b: str) -> str:
    return LEVELS[min(LEVELS.index(a), LEVELS.index(b))]


class CircuitBreaker:
    def __init__(self, threshold: int, reset_s: float):
        self.threshold = threshold
        self.reset_s = reset_s
        self.state: dict[str, dict] = {}

    def allow(self, key: str) -> bool:
        s = self.state.get(key)
        if not s or s["state"] == "closed":
            return True
        if s["state"] == "open" and time.time() - s["opened_at"] >= self.reset_s:
            s["state"] = "half-open"
            return True
        return s["state"] == "half-open"

    def record(self, key: str, ok: bool) -> None:
        s = self.state.setdefault(key, {"state": "closed", "failures": 0, "opened_at": 0.0})
        if ok:
            s.update({"state": "closed", "failures": 0})
            return
        s["failures"] += 1
        if s["failures"] >= self.threshold or s["state"] == "half-open":
            s.update({"state": "open", "opened_at": time.time()})

    def snapshot(self) -> dict:
        now = time.time()
        return {k: {**v, "retry_in_s": round(max(0.0, self.reset_s - (now - v["opened_at"])), 1) if v["state"] == "open" else None}
                for k, v in self.state.items()}


class DeviceAdapter:
    """Southbound action executor (NETCONF / OMCI-via-OLT / TL1 / workforce) against the simulator."""

    NO_DEVICE = {"watch", "open_ticket", "dispatch_field_cleaning"}

    def __init__(self, ctx):
        self.ctx = ctx
        cfg = ctx.settings["closed_loop"]
        self.timeout = cfg["action_timeout_s"]
        self.retries = cfg["action_retries"]
        self.breaker = CircuitBreaker(cfg["breaker_failure_threshold"], cfg["breaker_reset_s"])
        self.rng = random.Random(11)

    async def execute(self, action: str, target: str) -> dict:
        sim, topo = self.ctx.sim, self.ctx.topo
        if action in self.NO_DEVICE:
            await asyncio.sleep(0.3)
            return {**sim.apply_action(action, target), "attempts": 1, "manager": "workforce/ticketing"}
        mgr = topo.manager_of(target)
        if not self.breaker.allow(mgr):
            return {"ok": False, "unreachable": True, "attempts": 0, "manager": mgr,
                    "message": f"circuit breaker OPEN for {mgr}: action not attempted (safe mode)"}
        attempt = 0
        for attempt in range(1, self.retries + 2):
            await asyncio.sleep(self.rng.uniform(0.3, 0.7))
            if mgr not in sim.mgmt_unreachable and sim.is_up(mgr):
                self.breaker.record(mgr, True)
                return {**sim.apply_action(action, target), "attempts": attempt, "manager": mgr}
            await asyncio.sleep(self.timeout)
            self.breaker.record(mgr, False)
            if not self.breaker.allow(mgr):
                break
        return {"ok": False, "unreachable": True, "attempts": attempt, "manager": mgr,
                "message": f"{mgr} management plane unreachable after {attempt} attempt(s) ({self.timeout}s timeout each); breaker opened"}


class ClosedLoopController:
    def __init__(self, ctx):
        self.ctx = ctx
        self.cfg = ctx.settings["closed_loop"]
        self.policy = Policy()
        self.playbooks = load_yaml("playbooks.yaml")["playbooks"]
        self.adapter = DeviceAdapter(ctx)
        self.pending_results: list[tuple] = []
        self.device_actions: dict[str, list[float]] = {}
        self.ticket_seq = 1000
        self.action_seq = 0
        self.paused = False

    # ------------------------------------------------------------------- run
    async def run(self) -> None:
        while True:
            try:
                self.tick()
            except Exception as exc:  # noqa: BLE001 - the loop must survive a bad incident
                self.ctx.log_event("error", f"closed-loop tick error: {exc!r}")
            await asyncio.sleep(self.cfg["poll_s"])

    def state(self) -> dict | None:
        L = self.ctx.supervisor.leader
        return L.state if L and L.role == "leader" and L.state else None

    def tick(self) -> None:
        now = time.time()
        self.ctx.ai.update_rate(now)
        st = self.state()
        if st is None:
            self.paused = True
            return
        self.paused = False
        for item in list(self.pending_results):
            self.pending_results.remove(item)
            self._apply_result(st, *item)
        for inc in list(st["incidents"].values()):
            if inc["status"] != "resolved":
                self.step(st, inc, now)

    # ------------------------------------------------------------------ step
    def step(self, st: dict, inc: dict, now: float) -> None:
        alarms = [st["alarms"][a] for a in inc["alarms"] if a in st["alarms"]]
        active = [a for a in alarms if a["state"] == "active"]
        service_active = [a for a in active if a["severity"] in SERVICE_SEVERITIES and a["source"] != "ai"]
        # reactive incidents close on network alarms; AI-only incidents close when the AI signal clears
        blocking = [a for a in active if a["source"] != "ai"] if inc["kind"] == "reactive" else active
        phase = inc["phase"]
        cc = self.ctx.settings["correlation"]
        if phase == "detected":
            quiet = now - inc["last_alarm_ts"]
            if not blocking and quiet > 2:
                self.resolve(inc, "self-cleared", now)
                return
            if quiet >= cc["holddown_s"] or now - inc["created_ts"] >= cc["max_holddown_s"]:
                self.analyze(st, inc)
                self.decide(st, inc, 0)
            return
        if phase in ("advisory", "awaiting_approval", "escalated", "watching"):
            if (phase in ("advisory", "awaiting_approval") and inc.get("analysis_alarm_count") != len(inc["alarms"])
                    and now - inc["last_alarm_ts"] > 1.5 and inc["loop"]["step"] == 0):
                self.analyze(st, inc, reanalysis=True)
                self.decide(st, inc, 0)
                return
            last_clear = max((a.get("cleared_ts") or 0 for a in alarms), default=0)
            if not blocking and now - last_clear > 2:
                by = "human" if inc["loop"].get("human_fix") else "self-cleared"
                self.resolve(inc, by, now)
                return
            if phase == "watching" and now >= inc["loop"].get("watch_deadline", now + 1):
                self.escalate(inc, "transient pattern persisted beyond the watch window", None)
            return
        if phase == "verifying":
            self.verify(st, inc, now, service_active)

    # --------------------------------------------------------------- analyze
    def analyze(self, st: dict, inc: dict, reanalysis: bool = False) -> None:
        topo, ai = self.ctx.topo, self.ctx.ai
        alarms = [st["alarms"][a] for a in inc["alarms"] if a in st["alarms"]]
        active = [a for a in alarms if a["state"] == "active"] or alarms
        t0 = time.time()
        try:
            rca = ai.rca(active)
        except AIUnavailable:
            rca = rule_based_rca(topo, active)
        rca["ms"] = round((time.time() - t0) * 1000, 1)
        if not rca["hypotheses"]:
            return
        root = rca["hypotheses"][0]["entity"]
        root_cls = topo.cls(root)
        imp = topo.impacted(root)
        if topo.entities[root]["kind"] == "service":
            imp["services"] = sorted(set(imp["services"]) | {root})
        category = self._category(inc, active, root)
        matches = self._match_playbooks(st, inc, active, root, category)
        try:
            ranked = ai.rank_playbooks(matches, root_cls, category)
        except AIUnavailable:
            ranked = [{**m, "success_rate": None, "history_n": None, "score": m["_specificity"]} for m in matches]
            ranked.sort(key=lambda p: -p["score"])
        inc["rca"] = rca
        inc["category"] = category
        inc["impact"] = {"root": root, "services": imp["services"], "cell_sites": imp["cell_sites"], "devices": imp["devices"],
                         "subscribers": imp["subscribers"], "blast_radius": len(imp["services"]),
                         "path_to_core": topo.path_to_core(root)}
        inc["recommendation"] = [{k: v for k, v in r.items() if not k.startswith("_")} for r in ranked]
        inc["analysis_alarm_count"] = len(inc["alarms"])
        inc["analyzed_ts"] = time.time()
        inc["metrics"].setdefault("time_to_analyze_s", round(inc["analyzed_ts"] - inc["created_ts"], 2))
        label = {"link_down": "Loss of connectivity", "signal_degradation": "Signal degradation", "timing_sync": "Timing/sync fault",
                 "equipment": "Equipment fault", "performance": "Performance degradation", "configuration": "Configuration fault"}[category]
        prefix = "Predicted: " if inc["kind"] == "predictive" else ""
        inc["title"] = f"{prefix}{label} at {root} ({root_cls})"
        h = rca["hypotheses"][0]
        conf = f'{h["confidence"]:.0%}' if h["confidence"] is not None else "n/a"
        self._tl(inc, "analyze", f'{"Re-analysis" if reanalysis else "RCA"} [{rca["method"]}]: root cause {root} ({root_cls}), '
                                 f'confidence {conf}, {len(active)} alarms, blast radius {len(imp["services"])} services')

    def _category(self, inc: dict, alarms: list[dict], root: str) -> str:
        topo, cat = self.ctx.topo, self.ctx.catalog
        rcls = topo.cls(root)
        evidence = [a for a in alarms if a["entity"] == root or
                    (rcls in cat.implicates(a["type"], a.get("detail")) and topo.descendants(a["entity"]).get(root, 99) <= 2)]
        pool = evidence or [a for a in alarms if a["source"] != "ai"] or alarms
        best = max(pool, key=lambda a: (cat.sev_rank(a["severity"]), -CATEGORY_PRIORITY.index(a["category"])
                                        if a["category"] in CATEGORY_PRIORITY else -99))
        return best["category"]

    def _match_playbooks(self, st: dict, inc: dict, alarms: list[dict], root: str, category: str) -> list[dict]:
        topo = self.ctx.topo
        rcls = topo.cls(root)
        root_types = {a["type"] for a in alarms if a["entity"] == root}
        out = []
        for pb in self.playbooks:
            m = pb["match"]
            spec = None
            if "alarm_types" in m:
                if root_types and root_types <= set(m["alarm_types"]) and inc["kind"] == "reactive":
                    spec = 2.0
            else:
                cls_ok = rcls in m["root_classes"] or "*" in m["root_classes"]
                cat_ok = category in m["categories"] or "*" in m["categories"]
                if cls_ok and cat_ok:
                    spec = 0.2 if "*" in m["root_classes"] else 1.0
            if spec is None:
                continue
            if pb["id"] == "pon_type_b_switchover" and not self._protected_port(root):
                continue
            out.append({**pb, "_specificity": spec})
        return out

    def _protected_port(self, root: str) -> str | None:
        topo = self.ctx.topo
        for eid, e in topo.entities.items():
            prot = e.get("protection")
            if prot and (root in (prot["working"], eid)):
                return topo.entities[prot["working"]]["depends_on"][0]
        return None

    def _target(self, step: dict, root: str) -> str:
        if step["target"] == "protected_port":
            return self._protected_port(root) or root
        if step["target"] == "root_pw":
            pw = next((d for d in self.ctx.topo.dependents.get(root, []) if self.ctx.topo.cls(d) == "Pseudowire"), None)
            return pw or root
        return root

    # ---------------------------------------------------------------- decide
    def decide(self, st: dict, inc: dict, step_idx: int) -> None:
        if not inc.get("recommendation"):
            self.escalate(inc, "no applicable playbook", None)
            return
        topo, g = self.ctx.topo, self.policy.guardrails
        pb = inc["recommendation"][0]
        if step_idx >= len(pb["steps"]):
            self.escalate(inc, "all playbook steps exhausted", None)
            return
        step = dict(pb["steps"][step_idx])
        h = inc["rca"]["hypotheses"][0]
        root = h["entity"]
        step["target_entity"] = self._target(step, root)
        step["playbook"] = pb["id"]
        step["playbook_name"] = pb["name"]
        step["step_idx"] = step_idx
        pclass = topo.entities[root]["policy_class"]
        configured = self.policy.level(pclass, inc["category"])
        level, reasons, boundary = configured, [], []
        if not self.ctx.ai.up:
            level = min_level(level, g["safe_mode_level"])
            reasons.append(f'AI unavailable: safe-mode ceiling "{g["safe_mode_level"]}"')
        blast = inc["impact"]["blast_radius"]
        if level == "autonomous" and step["action"] not in ("watch", "open_ticket"):
            if RISK.get(step["risk"], 3) > RISK[g["max_risk_autonomous"]]:
                boundary.append(f'action risk "{step["risk"]}" exceeds autonomous limit "{g["max_risk_autonomous"]}"')
            if blast > g["max_blast_radius_autonomous"]:
                boundary.append(f'blast radius {blast} services exceeds limit {g["max_blast_radius_autonomous"]}')
            if h["confidence"] is not None and h["confidence"] < g["min_rca_confidence_autonomous"]:
                level = "supervised"
                reasons.append(f'RCA confidence {h["confidence"]:.0%} below {g["min_rca_confidence_autonomous"]:.0%}')
            mgr = topo.manager_of(step["target_entity"])
            recent = [t for t in self.device_actions.get(mgr, []) if time.time() - t < 3600]
            if len(recent) >= g["max_actions_per_device_per_hour"]:
                boundary.append(f"rate limit: {len(recent)} actions on {mgr} in the last hour")
        inc["loop"].update({"playbook": pb["id"], "step": step_idx, "pending": None})
        inc["loop"]["decision"] = {"ts": time.time(), "playbook": pb["id"], "step": step_idx, "action": step["action"],
                                   "target": step["target_entity"], "risk": step["risk"], "policy_key": f"{pclass} x {inc['category']}",
                                   "configured_level": configured, "effective_level": level, "reasons": reasons,
                                   "boundary_violations": boundary, "ai_available": self.ctx.ai.up}
        inc["metrics"].setdefault("time_to_decide_s", round(time.time() - inc["created_ts"], 2))
        if step["action"] == "watch":
            inc["phase"] = "watching"
            inc["loop"]["watch_deadline"] = time.time() + pb.get("verify", {}).get("window_s", 45)
            self._tl(inc, "decide", f'Decision: {pb["name"]} - {step["description"]}')
            return
        if step["action"] == "open_ticket":
            self.escalate(inc, "no automated remediation for this pattern; NOC investigation required", None)
            return
        if boundary:
            self._tl(inc, "decide", f'Decision: {step["action"]} on {step["target_entity"]} is outside the autonomy boundary')
            self.escalate(inc, "outside autonomy boundary: " + "; ".join(boundary), step)
            return
        if level == "autonomous":
            self._tl(inc, "decide", f'Decision [{pclass} x {inc["category"]} = autonomous]: execute {step["action"]} on {step["target_entity"]}')
            self.act(inc, step, "autonomous")
        elif level == "supervised":
            inc["phase"] = "awaiting_approval"
            inc["loop"]["pending"] = step
            self._tl(inc, "decide", f'Decision [{pclass} x {inc["category"]} = supervised]: {step["action"]} on {step["target_entity"]} '
                                    f'awaiting operator approval' + (f' ({"; ".join(reasons)})' if reasons else ""))
        else:
            inc["phase"] = "advisory"
            inc["loop"]["pending"] = step
            self._tl(inc, "decide", f'Advisory [{pclass} x {inc["category"]}]: recommend {step["action"]} on {step["target_entity"]}'
                                    + (f' ({"; ".join(reasons)})' if reasons else ""))

    # ------------------------------------------------------------------- act
    def act(self, inc: dict, step: dict, mode: str) -> dict:
        self.action_seq += 1
        rec = {"id": f"ACT-{self.action_seq:04d}", "incident": inc["id"], "playbook": step["playbook"], "step": step["step_idx"],
               "action": step["action"], "description": step["description"], "target": step["target_entity"], "risk": step["risk"],
               "protocol": step.get("protocol"), "mode": mode, "status": "executing", "started_ts": time.time(),
               "finished_ts": None, "result": None, "verification": None}
        inc["loop"]["actions"].append(rec)
        inc["loop"]["pending"] = None
        inc["phase"] = "acting"
        inc["metrics"].setdefault("time_to_act_s", round(rec["started_ts"] - inc["created_ts"], 2))
        mgr = self.ctx.topo.manager_of(step["target_entity"])
        self.device_actions.setdefault(mgr, []).append(time.time())
        self._tl(inc, "act", f'{rec["id"]} {step["action"]} -> {step["target_entity"]} via {step.get("protocol")} ({mode})')
        self.ctx.log_event("action", f'{inc["id"]}: {rec["id"]} {step["action"]} on {step["target_entity"]} ({mode})')
        asyncio.get_event_loop().create_task(self._execute(inc["id"], rec["id"], step))
        return rec

    async def _execute(self, inc_id: str, act_id: str, step: dict) -> None:
        try:
            res = await self.adapter.execute(step["action"], step["target_entity"])
        except Exception as exc:  # noqa: BLE001
            res = {"ok": False, "message": f"adapter error: {exc!r}"}
        self.pending_results.append((inc_id, act_id, step, res))

    def _apply_result(self, st: dict, inc_id: str, act_id: str, step: dict, res: dict) -> None:
        inc = st["incidents"].get(inc_id)
        if not inc:
            return
        rec = next((a for a in inc["loop"]["actions"] if a["id"] == act_id), None)
        if rec is None:  # state restored from a checkpoint taken before the action was recorded
            rec = {"id": act_id, "incident": inc_id, "playbook": step["playbook"], "step": step["step_idx"], "action": step["action"],
                   "description": step["description"], "target": step["target_entity"], "risk": step["risk"], "mode": "recovered",
                   "protocol": step.get("protocol"), "status": "executing", "started_ts": time.time(), "verification": None}
            inc["loop"]["actions"].append(rec)
        rec["finished_ts"] = time.time()
        rec["result"] = res
        if res.get("ok"):
            rec["status"] = "executed"
            pb = next((p for p in self.playbooks if p["id"] == step["playbook"]), {})
            window = pb.get("verify", {}).get("window_s", self.cfg["verify_window_s"])
            rec["verification"] = {"status": "running", "deadline": time.time() + window, "window_s": window, "first_ok_ts": None,
                                   "relapses": 0, "checks": []}
            inc["phase"] = "verifying"
            self._tl(inc, "act", f'{act_id} executed: {res.get("message")}')
        else:
            rec["status"] = "failed"
            self._tl(inc, "act", f'{act_id} FAILED: {res.get("message")}')
            reason = ("device unreachable - safe mode, no change made to the network" if res.get("unreachable")
                      else f'action failed: {res.get("message")}')
            self.escalate(inc, reason, step)

    # ---------------------------------------------------------------- verify
    def _kpi(self, st: dict, inc: dict, rec: dict) -> tuple[bool, dict]:
        pb = next((p for p in self.playbooks if p["id"] == rec["playbook"]), {})
        kpi = pb.get("verify", {}).get("kpi")
        if not kpi:
            return True, {}
        ent = inc["rca"]["hypotheses"][0]["entity"]
        tm = st["telemetry"].get(ent)
        if not tm or tm["ts"] < (rec.get("finished_ts") or 0):
            return True, {"metric": kpi["metric"], "value": None, "note": "no fresh telemetry; alarm state used"}
        v = tm["metrics"].get(kpi["metric"])
        ok = v is not None and (("max" not in kpi or v <= kpi["max"]) and ("min" not in kpi or v >= kpi["min"]))
        return ok, {"metric": kpi["metric"], "value": v, "limit": kpi.get("max", kpi.get("min")), "ok": ok}

    def verify(self, st: dict, inc: dict, now: float, service_active: list[dict]) -> None:
        rec = inc["loop"]["actions"][-1]
        v = rec["verification"]
        kpi_ok, kpi = self._kpi(st, inc, rec)
        ok_now = not service_active and kpi_ok
        if ok_now and v["first_ok_ts"] is None:
            v["first_ok_ts"] = now
        elif not ok_now and v["first_ok_ts"] is not None:
            v["first_ok_ts"] = None
            v["relapses"] += 1
        if not v["checks"] or now - v["checks"][-1]["ts"] >= 1.0:
            v["checks"].append({"ts": now, "service_alarms": len(service_active), "kpi": kpi, "ok": ok_now})
            v["checks"] = v["checks"][-12:]
        if now < v["deadline"]:
            return
        if ok_now and v["first_ok_ts"]:
            v["status"] = "passed"
            by = "autonomous" if rec["mode"] == "autonomous" else "operator"
            self._tl(inc, "verify", f'Verification PASSED for {rec["id"]}: service alarms clear'
                                    + (f', {kpi["metric"]}={kpi["value"]}' if kpi.get("value") is not None else ""))
            self.resolve(inc, by, v["first_ok_ts"])
            return
        v["status"] = "failed"
        still = sorted({a["type"] for a in service_active})
        self._tl(inc, "verify", f'Verification FAILED for {rec["id"]}: still active {", ".join(still) or "-"}'
                                + (f'; relapsed {v["relapses"]}x' if v["relapses"] else "")
                                + (f'; {kpi["metric"]}={kpi["value"]}' if kpi.get("value") is not None else ""))
        pb = inc["recommendation"][0]
        step = pb["steps"][rec["step"]]
        if step.get("rollback"):
            rb = {**step, "action": step["rollback"], "description": f'Rollback of {step["action"]}', "target_entity": rec["target"],
                  "playbook": pb["id"], "step_idx": rec["step"]}
            self._tl(inc, "act", f'Rolling back {step["action"]}')
            asyncio.get_event_loop().create_task(self.adapter.execute(rb["action"], rb["target_entity"]))
        if rec["step"] + 1 < len(pb["steps"]):
            self._tl(inc, "decide", f'Trying next playbook step {rec["step"] + 2}/{len(pb["steps"])}')
            self.decide(st, inc, rec["step"] + 1)
        else:
            self.escalate(inc, f'verification failed after {rec["step"] + 1} automated step(s)', None)

    # ------------------------------------------------------- escalate/resolve
    def escalate(self, inc: dict, reason: str, pending_step: dict | None) -> None:
        self.ticket_seq += 1
        inc["phase"] = "escalated"
        inc["loop"]["pending"] = pending_step
        inc["loop"]["escalation"] = {"ts": time.time(), "reason": reason, "ticket": f"NOC-{self.ticket_seq}", "acked": False,
                                     "proposed": pending_step["action"] if pending_step else None}
        inc["metrics"].setdefault("time_to_escalate_s", round(time.time() - inc["created_ts"], 2))
        self._tl(inc, "escalate", f'Escalated to NOC (ticket NOC-{self.ticket_seq}): {reason}')
        self.ctx.log_event("escalation", f'{inc["id"]} escalated: {reason}')

    def resolve(self, inc: dict, by: str, at: float) -> None:
        inc["status"] = "resolved"
        inc["phase"] = "resolved"
        inc["resolved_ts"] = at
        inc["resolved_by"] = by
        inc["metrics"]["mttr_s"] = round(at - inc["onset_ts"], 2)
        pb = next((p for p in self.playbooks if p["id"] == inc["loop"].get("playbook")), {})
        if by in ("autonomous", "operator") and pb.get("follow_up"):
            self.ticket_seq += 1
            inc["loop"]["follow_up"] = {"ticket": f"FLD-{self.ticket_seq}", "text": pb["follow_up"], "closed": False}
            self._tl(inc, "resolve", f'Follow-up ticket FLD-{self.ticket_seq}: {pb["follow_up"]}')
        self._tl(inc, "resolve", f'Resolved ({by}); MTTR {inc["metrics"]["mttr_s"]} s')
        if inc.get("rca") and inc["kind"] != "anomaly":
            try:
                self.ctx.history.record_incident(inc)
            except Exception:  # noqa: BLE001 - history is best effort
                pass

    # ------------------------------------------------------------ operators
    def operator(self, inc_id: str, op: str, note: str = "") -> dict:
        st = self.state()
        if st is None:
            raise RuntimeError("correlation engine failover in progress; retry in a few seconds")
        inc = st["incidents"].get(inc_id)
        if not inc:
            raise KeyError(inc_id)
        loop = inc["loop"]
        if op in ("approve", "execute"):
            step = loop.get("pending")
            if not step or inc["phase"] not in ("awaiting_approval", "advisory", "escalated"):
                raise ValueError("no pending action to approve")
            self._tl(inc, "decide", f'Operator {"approved" if op == "approve" else "executed"} {step["action"]}' + (f": {note}" if note else ""))
            return self.act(inc, step, "operator")
        if op == "reject":
            self._tl(inc, "decide", "Operator rejected the proposed action")
            self.escalate(inc, "operator rejected the proposed action", None)
            return {"ok": True}
        if op == "ack":
            if loop.get("escalation"):
                loop["escalation"]["acked"] = True
                loop["escalation"]["acked_ts"] = time.time()
            self._tl(inc, "escalate", "Escalation acknowledged by operator")
            return {"ok": True}
        if op == "resolve":
            hyps = [h["entity"] for h in (inc.get("rca") or {}).get("hypotheses", [])[:3]]
            fixed = self.ctx.sim.repair(set(hyps) | set(inc["entities"]))
            if inc["status"] == "resolved" and loop.get("follow_up"):
                loop["follow_up"]["closed"] = True
                self._tl(inc, "resolve", f'Field repair completed ({", ".join(fixed) or "no fault found"}); follow-up closed')
                return {"ok": True, "repaired": fixed}
            loop["human_fix"] = True
            loop["pending"] = None
            if inc["phase"] in ("verifying", "acting", "detected"):
                inc["phase"] = "escalated"
            self._tl(inc, "resolve", f'Field fix applied by operator ({", ".join(fixed) or "no physical fault found"})'
                                     + (f": {note}" if note else ""))
            return {"ok": True, "repaired": fixed}
        raise ValueError(f"unknown operation {op}")

    def _tl(self, inc: dict, phase: str, msg: str) -> None:
        inc["timeline"].append({"ts": time.time(), "phase": phase, "msg": msg})
        inc["updated_ts"] = time.time()

    def snapshot(self) -> dict:
        return {"policy": self.policy.spec, "breakers": self.adapter.breaker.snapshot(), "paused": self.paused,
                "levels": LEVELS}
