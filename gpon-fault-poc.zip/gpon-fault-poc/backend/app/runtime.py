"""Runtime wiring: builds every component, runs the background loops, scenarios, drills and KPIs."""
from __future__ import annotations

import asyncio
import random
import time
import uuid
from collections import deque

from .ai import AIService
from .closed_loop import ClosedLoopController
from .correlation import EngineSupervisor
from .history import HistoryStore
from .ingestion import IngestionGateway
from .ontology import AlarmCatalog, Topology, load_yaml
from .simulator import NetworkSim
from .sources import SourceClient, iso, render

SCENARIOS = {
    "cascade_fiber_cut": {
        "title": "Cascading failure: feeder fibre cut (OLT-A PON 0/1/1)",
        "story": "A backhoe cuts feeder F-A1. The OLT raises PON LOS, four ONTs go LOSi, the CES gateway loses two E1 pseudowires, "
                 "the BSC drops two 2G cells and service assurance flags 4G/enterprise SLA breaches. The AI groups ~15 alarms into one "
                 "incident, infers the silent fibre (not the port) as root cause and proposes a Type-B protection switchover; the blast "
                 "radius exceeds the autonomy limit, so it waits for operator approval.",
        "expect": "One incident, root cause F-A1, supervised action awaiting approval",
    },
    "autonomous_e1_timing": {
        "title": "Autonomous fix: E1 timing slips at cell site 102",
        "story": "After an ONT firmware restart, the CES port on ONT-A1-2 locks to the wrong clock. E1-102 accumulates G.822 slips, the "
                 "pseudowire jitter buffer underruns and the BSC sees call drops. Policy G702 x timing_sync is autonomous: the loop "
                 "re-locks the E1 clock, verifies slips are zero on post-action telemetry and closes the incident with no human.",
        "expect": "Resolved autonomously in seconds",
    },
    "escalation_pon_optics": {
        "title": "Escalation: degrading PON optics on OLT-B port 0/1/2",
        "story": "The PON-B2 transceiver laser is ageing. BER rises on every ONT behind it. The AI ranks the port above the fibre (laser "
                 "bias anomaly), auto-runs an optics re-calibration, but post-action telemetry relapses. The next step (migrate ONTs to "
                 "the spare port) is high risk, which is outside the autonomy boundary, so the loop escalates to the NOC with full context.",
        "expect": "Verification fails, escalated with a proposed high-risk action",
    },
    "predictive_rx_drift": {
        "title": "Prediction: ONT Rx power drifting (ONT-B1-3)",
        "story": "A dirty drop connector makes ONT-B1-3 downstream power fall ~5 dB/min. No alarm exists yet. The trend + logistic model "
                 "forecasts the sensitivity crossing and opens a predictive incident with an advisory to dispatch cleaning before the "
                 "4G site goes down.",
        "expect": "Predictive incident with lead time before any device alarm",
    },
    "uplink_failure": {
        "title": "Large outage: OLT-A uplink failure",
        "story": "The OLT-A uplink LAG to AGG-1 fails, taking down every ONT, cell site and service behind OLT-A. The OLT itself goes "
                 "silent, so the AI reasons from AGG-1's LINK_DOWN (AGG-1 is alive because it is reporting) and the downstream "
                 "CES/BSC/service alarms. Aggregation x link_down is advisory: the loop recommends a high-risk reroute; executing it "
                 "fails because no secondary uplink is provisioned, so the loop escalates.",
        "expect": "One incident covering all of OLT-A, root cause the uplink, advisory then escalation",
    },
}

DRILLS = {
    "alarm_storm": "Ingestion backpressure: ~3,500-message burst (telemetry, flapping syslog, retransmitted traps) while a real fault occurs",
    "duplicates_out_of_order": "Replay recent traps/syslog/events twice, shuffled, plus stale clears older than their raises",
    "crash_correlation_engine": "Kill the active correlation engine; the standby restores the checkpoint and replays the log",
    "ai_outage": "Toggle the AI inference service off/on (safe mode: rule-based correlation/RCA, advisory ceiling)",
    "device_unreachable": "Toggle OLT-B management plane unreachable (actions time out, breaker opens, loop escalates)",
}


class Runtime:
    def __init__(self):
        self.settings = load_yaml("settings.yaml")
        self.topo = Topology()
        self.catalog = AlarmCatalog()
        self.sim = NetworkSim(self.topo, self.catalog, self.settings)
        self.history = HistoryStore(self.topo)
        self.ai = AIService(self.topo, self.catalog, self.history, self.settings["ai"])
        self.ai.train(self.sim.normal_samples)
        self.gateway = IngestionGateway(self.settings["ingestion"], self.catalog, self.topo)
        jit = self.settings["simulation"]["network_jitter_s"]
        icfg = self.settings["ingestion"]
        self.sources = {
            "snmp": SourceClient("snmp", self.gateway, icfg, jit),
            "syslog": SourceClient("syslog", self.gateway, icfg, jit),
            "stream": SourceClient("stream", self.gateway, icfg, jit),
            "telemetry": SourceClient("telemetry", self.gateway, icfg, 0.1, latest_value_wins=True),
        }
        self.supervisor = EngineSupervisor(self)
        self.loop = ClosedLoopController(self)
        self.events: deque = deque(maxlen=200)
        self.series: deque = deque(maxlen=180)
        self.drills = {"ai_outage": False, "device_unreachable": False, "last": {}}
        self.scenario_runs: list[dict] = []
        self.started = time.time()
        self.noise = self.settings["simulation"]["background_noise"]
        self.rng = random.Random(5)
        self._tasks: list[asyncio.Task] = []
        self._prev = {}

    def log_event(self, kind: str, msg: str) -> None:
        self.events.append({"ts": time.time(), "kind": kind, "msg": msg})

    # --------------------------------------------------------------- startup
    async def start(self) -> None:
        self.supervisor.start(fresh=True)
        loop = asyncio.get_event_loop()
        coros = [self._sim_loop(), self._telemetry_loop(), self._noise_loop(), self._sampler(), self.gateway.run(),
                 self.supervisor.run(), self.loop.run()] + [s.run() for s in self.sources.values()]
        self._tasks = [loop.create_task(c) for c in coros]
        port = self.settings["ingestion"].get("syslog_udp_port")
        if port:
            try:
                await loop.create_datagram_endpoint(lambda: SyslogUDP(self), local_addr=("0.0.0.0", int(port)))
                self.log_event("system", f"UDP syslog listener on :{port}")
            except OSError as exc:
                self.log_event("system", f"UDP syslog listener disabled: {exc}")
        self.log_event("system", f"Fault-management stack started; AI models trained in {self.ai.stats.get('train_s')} s")

    async def stop(self) -> None:
        for t in self._tasks:
            t.cancel()

    async def _sim_loop(self) -> None:
        tick = self.settings["simulation"]["tick_s"]
        rtx = self.settings["simulation"]["trap_retransmit_ratio"]
        while True:
            for ev in self.sim.tick():
                src, payload = render(ev)
                self.sources[src].send(payload)
                if src == "snmp" and self.rng.random() < rtx:
                    self.sources[src].send(payload, delay=self.rng.uniform(0.2, 1.5))
            await asyncio.sleep(tick)

    async def _telemetry_loop(self) -> None:
        while True:
            for msg in self.sim.telemetry():
                self.sources["telemetry"].send({**msg, "ts": iso(msg["ts"])})
            await asyncio.sleep(self.settings["simulation"]["telemetry_interval_s"])

    async def _noise_loop(self) -> None:
        lo, hi = self.settings["simulation"]["noise_interval_s"]
        await asyncio.sleep(8)
        while True:
            await asyncio.sleep(self.rng.uniform(lo, hi))
            if self.noise:
                what = self.sim.noise_event()
                if what:
                    self.log_event("noise", f"Background event: {what}")

    async def _sampler(self) -> None:
        while True:
            await asyncio.sleep(2.0)
            g = self.gateway.stats
            L = self.supervisor.leader
            st = L.state if L and L.role == "leader" and L.state else None
            cur = {"received": g["received"], "raises": st["stats"]["raises"] if st else self._prev.get("raises", 0)}
            d = {k: max(0, v - self._prev.get(k, v)) for k, v in cur.items()}
            self._prev = cur
            point = {"t": time.strftime("%H:%M:%S"), "events_per_s": round(d["received"] / 2, 1),
                     "alarms_per_s": round(d["raises"] / 2, 1), "queue_depth": len(self.gateway.queue),
                     "open_incidents": sum(1 for i in st["incidents"].values() if i["status"] != "resolved") if st else None,
                     "active_alarms": sum(1 for a in st["alarms"].values() if a["state"] == "active") if st else None,
                     "shed": g["shed_low_priority"] + g["rejected_full"], "duplicates": g["duplicates"]}
            self.series.append(point)

    # ------------------------------------------------------------ scenarios
    def run_scenario(self, name: str) -> dict:
        if name not in SCENARIOS:
            raise KeyError(name)
        sim = self.sim
        if name == "cascade_fiber_cut":
            sim.inject("F-A1", "cut")
        elif name == "autonomous_e1_timing":
            sim.inject("E1-102", "timing")
        elif name == "escalation_pon_optics":
            sim.inject("PON-B2", "optics_degraded", recoverable=False)
        elif name == "predictive_rx_drift":
            self.ai.reset_entity("ONT-B1-3")
            sim.inject("ONT-B1-3", "rx_drift", rate_db_per_s=0.085)
        elif name == "uplink_failure":
            sim.inject("UL-OLTA-AGG1", "cut")
        run = {"ts": time.time(), "scenario": name, **SCENARIOS[name]}
        self.scenario_runs.append(run)
        self.log_event("scenario", f'Scenario started: {SCENARIOS[name]["title"]}')
        return run

    async def guided_demo(self) -> None:
        steps = [("cascade_fiber_cut", 30), ("autonomous_e1_timing", 30), ("escalation_pon_optics", 35),
                 ("predictive_rx_drift", 30)]
        self.log_event("scenario", "Guided demo started (cascade -> autonomous -> escalation -> prediction -> engine failover)")
        for name, wait in steps:
            self.run_scenario(name)
            await asyncio.sleep(wait)
        self.drill("crash_correlation_engine")
        self.log_event("scenario", "Guided demo: all scenarios launched. Approve or resolve the open incidents from the dashboard.")

    # --------------------------------------------------------------- drills
    def drill(self, name: str) -> dict:
        if name == "ai_outage":
            self.ai.up = not self.ai.up
            self.drills["ai_outage"] = not self.ai.up
            self.log_event("fault-tolerance", "AI service DOWN - safe mode: rule-based correlation/RCA, autonomy capped at advisory"
                           if not self.ai.up else "AI service restored - full autonomy policy re-enabled")
            return {"ai_up": self.ai.up}
        if name == "device_unreachable":
            if "OLT-B" in self.sim.mgmt_unreachable:
                self.sim.mgmt_unreachable.discard("OLT-B")
                self.drills["device_unreachable"] = False
                self.log_event("fault-tolerance", "OLT-B management plane reachable again")
            else:
                self.sim.mgmt_unreachable.add("OLT-B")
                self.drills["device_unreachable"] = True
                self.log_event("fault-tolerance", "OLT-B management plane UNREACHABLE (NETCONF/SNMP set timeouts)")
            return {"unreachable": sorted(self.sim.mgmt_unreachable)}
        if name == "crash_correlation_engine":
            who = self.supervisor.crash()
            return {"crashed": who}
        if name == "alarm_storm":
            asyncio.get_event_loop().create_task(self._storm())
            return {"started": True}
        if name == "duplicates_out_of_order":
            return self._replay()
        raise KeyError(name)

    def _counters(self) -> dict:
        g = self.gateway.stats
        L = self.supervisor.leader
        es = L.state["stats"] if L and L.state else {}
        src = {k: s.stats["retries"] for k, s in self.sources.items()}
        return {**g, "stale_ignored": es.get("stale_ignored", 0), "repeats": es.get("repeats", 0),
                "retries": sum(src.values()), "telemetry_stale_dropped": self.sources["telemetry"].stats["dropped_stale"]}

    async def _storm(self) -> None:
        before = self._counters()
        t0 = time.time()
        self.log_event("fault-tolerance", "Alarm storm drill: injecting ~3,500 messages in < 1 s")
        tm = [m for m in self.sim.telemetry()]
        n_tm = 0
        for i in range(1500):
            m = tm[i % len(tm)]
            self.sources["telemetry"].send({**m, "ts": iso(time.time())}, delay=0)
            n_tm += 1
        for i in range(1100):
            ts = time.time() + i * 0.0005
            state = "raise" if i % 2 == 0 else "clear"
            line = (f'<132>1 {iso(ts)} AGG-1 fmd - HIGH_CPU [alarm@64999 id="storm-{uuid.uuid4()}" entity="AGG-1" '
                    f'state="{state}" severity="warning" seq="{i}"] control plane CPU flapping')
            self.sources["syslog"].send(line, delay=0)
        traps = [t for t in list(self.sources["snmp"].recent)[-80:]
                 if int(t["varbinds"]["gponAlarmSeverity"]) <= 2 or int(t["varbinds"]["gponAlarmState"]) == 2]
        for i in range(900 if traps else 0):  # retransmitted major/critical traps: high priority, fill the queue
            self.sources["snmp"].send(traps[i % len(traps)], delay=0)
        self.sim.inject("ONT-A2-4", "power", duration=14)
        self.log_event("fault-tolerance", "Storm drill: real dying-gasp fault injected on ONT-A2-4 in the middle of the storm")
        peak = 0
        while time.time() - t0 < 25:
            peak = max(peak, len(self.gateway.queue))
            await asyncio.sleep(0.1)
            if time.time() - t0 > 6 and not self.gateway.queue and not any(s.buffer for s in self.sources.values()):
                break
        after = self._counters()
        delta = {k: after[k] - before.get(k, 0) for k in after}
        L = self.supervisor.leader
        found = False
        if L and L.state:
            found = any(a["entity"] == "ONT-A2-4" and a["type"] == "ONT_DYING_GASP" for a in L.state["alarms"].values()
                        if a["received_ts"] >= t0)
        res = {"duration_s": round(time.time() - t0, 1), "peak_queue": peak, "accepted": delta["accepted"],
               "shed_low_priority": delta["shed_low_priority"], "rejected_full": delta["rejected_full"],
               "source_retries": delta["retries"], "telemetry_stale_dropped": delta["telemetry_stale_dropped"],
               "critical_alarm_delivered": found}
        self.drills["last"]["alarm_storm"] = res
        self.log_event("fault-tolerance", f'Storm drill done: peak queue {peak}, shed {res["shed_low_priority"]}, rejected '
                                          f'{res["rejected_full"]}, retries {res["source_retries"]}, real fault alarm delivered: {found}')

    def _replay(self) -> dict:
        before = self._counters()
        payloads = []
        for name in ("snmp", "syslog", "stream"):
            payloads += [(name, p) for p in list(self.sources[name].recent)[-40:]]
        batch = payloads * 2
        self.rng.shuffle(batch)
        for name, p in batch:
            self.sources[name].send(p, delay=self.rng.uniform(0, 0.8))
        stale = 0
        L = self.supervisor.leader
        if L and L.state:
            act = [a for a in L.state["alarms"].values() if a["state"] == "active" and a["source"] != "ai"][:8]
            for a in act:
                self.sources["stream"].send({"event_id": f"stale-{uuid.uuid4()}", "producer": a["reporter"], "type": a["type"],
                                             "entity": a["entity"], "state": "clear", "severity": "cleared",
                                             "event_time": iso(a["first_ts"] - 30), "seq": 0}, delay=0.1)
                stale += 1
        res = {"replayed": len(batch), "unique_payloads": len(payloads), "stale_clears_sent": stale, "before": before}
        self.drills["last"]["duplicates_out_of_order"] = res
        self.log_event("fault-tolerance", f"Replay drill: {len(batch)} duplicate messages (shuffled) + {stale} stale clears injected")
        asyncio.get_event_loop().create_task(self._replay_report(before))
        return res

    async def _replay_report(self, before: dict) -> None:
        await asyncio.sleep(4)
        after = self._counters()
        r = self.drills["last"]["duplicates_out_of_order"]
        r.update({"duplicates_dropped": after["duplicates"] - before["duplicates"],
                  "reordered": after["reordered"] - before["reordered"], "late": after["late"] - before["late"],
                  "stale_ignored": after["stale_ignored"] - before["stale_ignored"]})
        r.pop("before", None)
        self.log_event("fault-tolerance", f'Replay drill result: {r["duplicates_dropped"]} duplicates dropped, {r["reordered"]} re-ordered, '
                                          f'{r["stale_ignored"]} stale clears ignored; active alarms unchanged')

    def reset(self, full: bool = False) -> None:
        self.sim.repair_all()
        self.ai.up = True
        self.ai.predicted.clear()
        self.ai.anomalous.clear()
        self.ai.rx_hist.clear()
        self.drills.update({"ai_outage": False, "device_unreachable": False})
        self.loop.adapter.breaker.state.clear()
        self.loop.device_actions.clear()
        if full:
            self.supervisor.reset_state()
        self.log_event("system", "Network repaired" + (" and incident state cleared" if full else ""))

    # ---------------------------------------------------------------- views
    def state(self) -> dict | None:
        L = self.supervisor.leader
        return L.state if L and L.role == "leader" and L.state else None

    def kpis(self, st: dict | None) -> dict:
        if st is None:
            return {}
        incs = [i for i in st["incidents"].values() if i["phase"] != "merged"]
        real = [i for i in incs if i["kind"] in ("reactive", "predictive")]
        resolved = [i for i in real if i["status"] == "resolved"]
        mttd = [i["metrics"]["mttd_s"] for i in real if i["kind"] == "reactive" and "mttd_s" in i["metrics"]]
        by = {}
        for i in resolved:
            by.setdefault(i["resolved_by"], []).append(i["metrics"].get("mttr_s", 0))
        acts = [a for i in incs for a in i["loop"]["actions"]]
        ver = [a for a in acts if a.get("verification") and a["verification"]["status"] in ("passed", "failed")]
        esc = [i for i in incs if i["loop"].get("escalation")]
        rule = [d for d in self.history.daily_trends() if d["mode"] == "rule"]
        base_mttr = round(sum(d["mttr_min"] for d in rule) / len(rule), 1) if rule else None
        base_mttd = round(sum(d["mttd_min"] for d in rule) / len(rule), 1) if rule else None
        remediated = [i for i in resolved if i["resolved_by"] in ("autonomous", "operator", "human")]
        avg = lambda xs: round(sum(xs) / len(xs), 1) if xs else None  # noqa: E731
        return {
            "raw_alarms": st["stats"]["raises"], "incidents": len(real), "open_incidents": sum(1 for i in real if i["status"] != "resolved"),
            "compression_ratio": round(st["stats"]["raises"] / max(len(incs), 1), 1),
            "mttd_s": avg(mttd), "mttr_s": avg([i["metrics"]["mttr_s"] for i in remediated]),
            "mttr_autonomous_s": avg(by.get("autonomous", [])), "mttr_operator_s": avg(by.get("operator", []) + by.get("human", [])),
            "auto_resolution_pct": round(100 * len(by.get("autonomous", [])) / len(remediated)) if remediated else None,
            "self_cleared": len(by.get("self-cleared", [])), "actions": len(acts),
            "verification_pass_pct": round(100 * sum(1 for a in ver if a["verification"]["status"] == "passed") / len(ver)) if ver else None,
            "escalations": len(esc), "pending_approvals": sum(1 for i in incs if i["phase"] == "awaiting_approval"),
            "predictions": sum(1 for i in incs if i["kind"] == "predictive"),
            "baseline_mttr_min": base_mttr, "baseline_mttd_min": base_mttd,
            "duplicates_suppressed": self.gateway.stats["duplicates"] + st["stats"]["repeats"],
        }

    def entity_view(self, st: dict | None) -> dict:
        view: dict[str, dict] = {}
        if st is None:
            return view
        rank = self.catalog.rank
        for a in st["alarms"].values():
            if a["state"] != "active":
                continue
            v = view.setdefault(a["entity"], {"severity": None, "alarms": 0})
            v["alarms"] += 1
            if v["severity"] is None or rank.get(a["severity"], 0) > rank.get(v["severity"], 0):
                v["severity"] = a["severity"]
        for inc in st["incidents"].values():
            if inc["status"] == "resolved" or not inc.get("impact"):
                continue
            root = inc["impact"]["root"]
            view.setdefault(root, {"severity": None, "alarms": 0})["root_of"] = inc["id"]
            for e in self.topo.descendants(root):
                view.setdefault(e, {"severity": None, "alarms": 0}).setdefault("impacted_by", inc["id"])
        return view

    def snapshot(self) -> dict:
        st = self.state()
        alarms, incidents = [], []
        if st:
            alarms = sorted(st["alarms"].values(), key=lambda a: a["received_ts"], reverse=True)[:150]
            incs = [i for i in st["incidents"].values() if i["phase"] != "merged"]
            incs.sort(key=lambda i: (i["status"] == "resolved", -i["created_ts"]))
            incidents = incs[:40]
        return {
            "ts": time.time(), "uptime_s": round(time.time() - self.started),
            "kpis": self.kpis(st), "alarms": alarms, "incidents": incidents, "entity_view": self.entity_view(st),
            "ingestion": self.gateway.snapshot(), "sources": [s.snapshot() for s in self.sources.values()],
            "correlation": self.supervisor.snapshot(), "ai": self.ai.snapshot(), "closed_loop": self.loop.snapshot(),
            "drills": self.drills, "events": list(self.events)[-60:], "series": list(self.series),
            "engine_stats": st["stats"] if st else None,
            "sim": {"faults": [{"entity": f.entity, "type": f.type, "since": f.since} for f in self.sim.faults.values()],
                    "mgmt_unreachable": sorted(self.sim.mgmt_unreachable)},
            "safe_mode": not self.ai.up, "noise": self.noise,
        }


class SyslogUDP(asyncio.DatagramProtocol):
    def __init__(self, rt: Runtime):
        self.rt = rt

    def datagram_received(self, data: bytes, addr) -> None:
        line = data.decode("utf-8", errors="replace").strip()
        self.rt.gateway.submit("syslog", line)
