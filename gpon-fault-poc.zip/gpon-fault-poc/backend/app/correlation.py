"""Correlation engine (active/standby) and its supervisor.

The engine consumes the ingestion event log by offset and maintains the alarm and incident state:
* alarm lifecycle (raise / repeat / clear / re-raise) with stale-event reconciliation per alarm key
* enrichment with topology context, device metadata and history
* topology + temporal + learned co-occurrence correlation into incidents (with incident merging)
* telemetry fan-out to the AI component, whose derived events (anomaly, prediction) are correlated too

Fault tolerance: two engine instances run under a supervisor. The leader heartbeats and checkpoints its
full state with the log offset to SQLite. If the leader stops heart-beating, the standby restores the
latest checkpoint and replays the log from the checkpointed offset; alarm-id idempotency and per-key
timestamps make the replay safe (effectively-once processing).
"""
from __future__ import annotations

import copy
import math
import time

from .ai import AIService, AIUnavailable
from .enrichment import enrich
from .history import HistoryStore
from .ingestion import EventLog
from .ontology import AlarmCatalog, Topology


def empty_state() -> dict:
    return {"offset": 0, "alarms": {}, "index": {}, "incidents": {}, "alarm_seq": 0, "inc_seq": 0,
            "last_ts": {}, "telemetry": {}, "stats": {"alarms_processed": 0, "raises": 0, "clears": 0, "repeats": 0,
                                                      "stale_ignored": 0, "reraised": 0, "telemetry_events": 0,
                                                      "merges": 0, "ai_fallbacks": 0, "events_processed": 0}}


class CorrelationEngine:
    def __init__(self, name: str, ctx):
        self.name = name
        self.ctx = ctx
        self.role = "standby"
        self.state: dict | None = None
        self.heartbeat = 0.0
        self.started_at = time.time()
        self.restart_at: float | None = None
        self.crashed_at: float | None = None

    # --------------------------------------------------------------- helpers
    @property
    def topo(self) -> Topology:
        return self.ctx.topo

    @property
    def catalog(self) -> AlarmCatalog:
        return self.ctx.catalog

    @property
    def ai(self) -> AIService:
        return self.ctx.ai

    def restore(self, ckpt: tuple[int, dict] | None) -> None:
        if ckpt:
            self.state = ckpt[1]
            self.state["offset"] = ckpt[0]
        else:
            self.state = empty_state()

    def process(self, log: EventLog, max_n: int = 400) -> int:
        batch = log.read(self.state["offset"], max_n)
        for ev in batch:
            self.handle(ev)
            self.state["offset"] = ev["offset"] + 1
        return len(batch)

    def handle(self, ev: dict) -> None:
        self.state["stats"]["events_processed"] += 1
        if ev["kind"] == "telemetry":
            self._telemetry(ev)
        else:
            self._alarm(ev)

    # ------------------------------------------------------------- telemetry
    def _telemetry(self, ev: dict) -> None:
        st = self.state
        st["stats"]["telemetry_events"] += 1
        for s in ev["samples"]:
            st["telemetry"][s["entity"]] = {"ts": ev["ts"], "metrics": s["metrics"]}
        try:
            derived = self.ai.analyze_telemetry(ev)
        except AIUnavailable:
            st["stats"]["ai_fallbacks"] += 1
            derived = []
        for d in derived:
            self._alarm(d)

    # ---------------------------------------------------------------- alarms
    def _alarm(self, ev: dict) -> None:
        st = self.state
        st["stats"]["alarms_processed"] += 1
        key = f'{ev["entity"]}|{ev["type"]}'
        last = st["last_ts"].get(key)
        if last is not None and ev["ts"] < last:
            st["stats"]["stale_ignored"] += 1
            return
        st["last_ts"][key] = ev["ts"]
        aid = st["index"].get(key)
        alarm = st["alarms"].get(aid) if aid else None
        now = time.time()
        if ev["state"] == "clear":
            if alarm and alarm["state"] == "active":
                alarm["state"] = "cleared"
                alarm["cleared_ts"] = ev["ts"]
                st["stats"]["clears"] += 1
                inc = st["incidents"].get(alarm["incident"])
                if inc:
                    inc["updated_ts"] = now
            return
        if alarm and alarm["state"] == "active":
            alarm["count"] += 1
            alarm["last_ts"] = ev["ts"]
            st["stats"]["repeats"] += 1
            return
        if alarm and alarm["state"] == "cleared":
            inc = st["incidents"].get(alarm["incident"])
            if inc and inc["status"] != "resolved":
                alarm.update({"state": "active", "last_ts": ev["ts"], "cleared_ts": None})
                alarm["flaps"] = alarm.get("flaps", 0) + 1
                st["stats"]["reraised"] += 1
                inc["updated_ts"] = now
                inc["last_alarm_ts"] = now
                self._timeline(inc, "detect", f'{alarm["type"]} re-raised on {alarm["entity"]}')
                return
        st["stats"]["raises"] += 1
        st["alarm_seq"] += 1
        cat = self.catalog.get(ev["type"])
        e = self.topo.entities[ev["entity"]]
        alarm = {"id": f'ALM-{st["alarm_seq"]:05d}', "key": key, "type": ev["type"], "severity": ev["severity"],
                 "category": cat["category"], "domain": cat.get("domain"), "ref": cat.get("ref"),
                 "entity": ev["entity"], "entity_class": e["class"], "layer": e["layer"], "reporter": ev["reporter"],
                 "source": ev["source"], "state": "active", "first_ts": ev["ts"], "last_ts": ev["ts"],
                 "received_ts": now, "cleared_ts": None, "count": 1, "late": bool(ev.get("late")),
                 "detail": ev.get("detail", {}), "incident": None}
        alarm["enrichment"] = enrich(self.ctx, alarm)
        st["alarms"][alarm["id"]] = alarm
        st["index"][key] = alarm["id"]
        if ev["source"] != "ai":
            self.ai.observe_alarm(now)
        self._correlate(alarm)
        self._trim()

    def _correlate(self, alarm: dict) -> None:
        st = self.state
        cfg = self.ctx.settings["correlation"]
        now = time.time()
        ai_ok = self.ai.up
        scores = []
        for inc in st["incidents"].values():
            if inc["status"] == "resolved" or now - inc["updated_ts"] > cfg["window_s"]:
                continue
            s = self._score(alarm, inc, ai_ok)
            if s >= (cfg["join_threshold"] if ai_ok else 1.0):
                scores.append((s, inc["id"]))
        scores.sort(reverse=True)
        if scores:
            target = st["incidents"][scores[0][1]]
            self._attach(target, alarm, scores[0][0], "ai" if ai_ok else "rule")
            for s, other_id in scores[1:]:
                other = st["incidents"][other_id]
                if other["phase"] in ("detected", "analyzed", "advisory", "awaiting_approval") and target["kind"] == other["kind"]:
                    self._merge(target, other)
        else:
            self._new_incident(alarm)

    def _score(self, alarm: dict, inc: dict, ai_ok: bool) -> float:
        topo = self.topo
        alarms = self.state["alarms"]
        # anchor on service-affecting alarms only: a CPU-spike warning must not pull unrelated faults together
        ents = {alarms[a]["entity"] for a in inc["alarms"] if a in alarms
                and not (alarms[a]["category"] == "performance" and alarms[a]["severity"] == "warning")}
        root = (inc.get("rca") or {}).get("hypotheses") or []
        if root:
            ents.add(root[0]["entity"])
        if alarm["category"] == "performance" and alarm["severity"] == "warning":
            # a non-service-affecting warning (e.g. CPU spike) cannot explain or be explained by other faults
            aff = 1.0 if alarm["entity"] in inc["entities"] else 0.0
        else:
            aff = max((topo.affinity(alarm["entity"], e) for e in ents), default=0.0)
        dt = abs(alarm["first_ts"] - inc["last_alarm_event_ts"])
        if not ai_ok:  # safe-mode rules: same subtree, within 60 s
            return 1.0 if aff >= 0.5 and dt <= 60 else 0.0
        if aff < self.ctx.settings["correlation"]["min_topology_affinity"]:
            return 0.0
        temporal = math.exp(-dt / 30.0)
        try:
            cooc = self.ai.cooccurrence(alarm["type"], set(inc["alarm_types"]))
        except AIUnavailable:
            cooc = 0.0
        return 0.6 * aff + 0.25 * temporal + 0.15 * cooc

    def _new_incident(self, alarm: dict) -> None:
        st = self.state
        st["inc_seq"] += 1
        now = time.time()
        kind = "predictive" if alarm["type"] == "PREDICTED_FAULT" else "anomaly" if alarm["type"] == "AI_ANOMALY" else "reactive"
        onset = self.ctx.sim.truth_onset(alarm["entity"]) if kind == "reactive" else None
        inc = {"id": f'INC-{st["inc_seq"]:04d}', "kind": kind, "status": "open", "phase": "detected",
               "created_ts": now, "updated_ts": now, "last_alarm_ts": now, "last_alarm_event_ts": alarm["first_ts"],
               "onset_ts": min(onset or alarm["first_ts"], alarm["first_ts"]),
               "alarms": [], "entities": [], "alarm_types": [], "severity": alarm["severity"], "title": "",
               "category": alarm["category"], "rca": None, "impact": None, "recommendation": None,
               "loop": {"actions": [], "decision": None, "escalation": None, "step": 0, "playbook": None},
               "timeline": [], "metrics": {}, "resolved_by": None, "correlation": []}
        st["incidents"][inc["id"]] = inc
        self._timeline(inc, "detect", f'Incident opened by {alarm["type"]} on {alarm["entity"]}')
        self._attach(inc, alarm, 1.0, "seed")
        inc["metrics"]["mttd_s"] = round(now - inc["onset_ts"], 2)

    def _attach(self, inc: dict, alarm: dict, score: float, method: str) -> None:
        now = time.time()
        alarm["incident"] = inc["id"]
        inc["alarms"].append(alarm["id"])
        if alarm["entity"] not in inc["entities"]:
            inc["entities"].append(alarm["entity"])
        if alarm["type"] not in inc["alarm_types"]:
            inc["alarm_types"].append(alarm["type"])
        if self.catalog.sev_rank(alarm["severity"]) > self.catalog.sev_rank(inc["severity"]):
            inc["severity"] = alarm["severity"]
        inc["updated_ts"] = now
        inc["last_alarm_ts"] = now
        inc["last_alarm_event_ts"] = max(inc["last_alarm_event_ts"], alarm["first_ts"])
        if method != "seed":
            inc["correlation"].append({"alarm": alarm["id"], "score": round(score, 2), "method": method})
        if alarm["type"] == "PREDICTED_FAULT" and inc["kind"] == "anomaly":
            inc["kind"] = "predictive"
        if alarm["type"] == "ONT_RX_POWER_LOW" and inc["kind"] == "predictive" and "lead_time_s" not in inc["metrics"]:
            inc["metrics"]["lead_time_s"] = round(alarm["first_ts"] - inc["created_ts"], 1)
            self._timeline(inc, "detect", f'Prediction confirmed: threshold crossed {inc["metrics"]["lead_time_s"]} s after the forecast')

    def _merge(self, target: dict, other: dict) -> None:
        st = self.state
        for aid in other["alarms"]:
            a = st["alarms"].get(aid)
            if a:
                a["incident"] = target["id"]
                target["alarms"].append(aid)
        for e in other["entities"]:
            if e not in target["entities"]:
                target["entities"].append(e)
        for t in other["alarm_types"]:
            if t not in target["alarm_types"]:
                target["alarm_types"].append(t)
        target["onset_ts"] = min(target["onset_ts"], other["onset_ts"])
        target["created_ts"] = min(target["created_ts"], other["created_ts"])
        other.update({"status": "resolved", "phase": "merged", "resolved_by": f'merged into {target["id"]}',
                      "alarms": [], "merged_into": target["id"]})
        st["stats"]["merges"] += 1
        self._timeline(target, "analyze", f'Merged {other["id"]} (shared topology)')

    def _timeline(self, inc: dict, phase: str, msg: str) -> None:
        inc["timeline"].append({"ts": time.time(), "phase": phase, "msg": msg})
        if len(inc["timeline"]) > 60:
            inc["timeline"] = inc["timeline"][-60:]

    def _trim(self) -> None:
        st = self.state
        if len(st["alarms"]) < 1500:
            return
        live = {i for inc in st["incidents"].values() if inc["status"] != "resolved" for i in inc["alarms"]}
        old = sorted((a for a in st["alarms"].values() if a["state"] == "cleared" and a["id"] not in live),
                     key=lambda a: a["received_ts"])
        for a in old[:500]:
            st["alarms"].pop(a["id"], None)
            if st["index"].get(a["key"]) == a["id"]:
                del st["index"][a["key"]]
        resolved = sorted((i for i in st["incidents"].values() if i["status"] == "resolved"), key=lambda i: i["updated_ts"])
        for inc in resolved[:-150]:
            st["incidents"].pop(inc["id"], None)

    def snapshot(self) -> dict:
        return copy.deepcopy(self.state)


class EngineSupervisor:
    """Active/standby supervisor with heartbeat-based failover from checkpoints."""

    CKPT = "correlation"

    def __init__(self, ctx):
        self.ctx = ctx
        self.cfg = ctx.settings["correlation"]
        self.engines = [CorrelationEngine("corr-a", ctx), CorrelationEngine("corr-b", ctx)]
        self.history: HistoryStore = ctx.history
        self.leader: CorrelationEngine | None = None
        self.last_ckpt = 0.0
        self.failovers: list[dict] = []
        self.status = "starting"

    def start(self, fresh: bool = True) -> None:
        if fresh:
            self.history.clear_checkpoint(self.CKPT)
        a = self.engines[0]
        a.restore(None if fresh else self.history.load_checkpoint(self.CKPT))
        a.role = "leader"
        a.heartbeat = time.time()
        self.leader = a
        self.status = "healthy"

    def reset_state(self) -> None:
        self.history.clear_checkpoint(self.CKPT)
        for e in self.engines:
            if e.role == "leader":
                e.state = empty_state()
                e.state["offset"] = self.ctx.gateway.log.end

    def crash(self, name: str | None = None) -> str:
        eng = next((e for e in self.engines if e.name == name), None) if name else self.leader
        if not eng or eng.role == "crashed":
            return "nothing to crash"
        eng.role = "crashed"
        eng.state = None  # in-memory state is lost with the process
        eng.crashed_at = time.time()
        eng.restart_at = time.time() + self.cfg["restart_after_s"]
        self.ctx.log_event("fault-tolerance", f"Correlation engine {eng.name} crashed (drill); in-memory state lost")
        return eng.name

    async def run(self) -> None:
        import asyncio
        while True:
            self.step()
            await asyncio.sleep(self.cfg["heartbeat_interval_s"])

    def step(self) -> None:
        now = time.time()
        for e in self.engines:
            if e.role == "crashed" and e.restart_at and now >= e.restart_at:
                e.role = "standby"
                e.restart_at = None
                e.started_at = now
                self.ctx.log_event("fault-tolerance", f"Engine {e.name} restarted and rejoined as standby")
        L = self.leader
        if L and L.role == "leader":
            L.process(self.ctx.gateway.log)
            L.heartbeat = now
            self.status = "healthy"
            if now - self.last_ckpt >= self.cfg["checkpoint_interval_s"]:
                self.history.save_checkpoint(self.CKPT, L.state["offset"], L.state)
                self.last_ckpt = now
            return
        hb = L.heartbeat if L else 0
        if now - hb < self.cfg["heartbeat_timeout_s"]:
            self.status = "leader heartbeat missed"
            return
        standby = next((e for e in self.engines if e.role == "standby"), None)
        if not standby:
            self.status = "no standby available"
            return
        t0 = time.time()
        ckpt = self.history.load_checkpoint(self.CKPT)
        standby.restore(ckpt)
        from_offset = standby.state["offset"]
        replayed = 0
        while True:
            n = standby.process(self.ctx.gateway.log, 2000)
            replayed += n
            if n == 0:
                break
        standby.role = "leader"
        standby.heartbeat = time.time()
        self.leader = standby
        self.status = "healthy"
        rec = {"ts": now, "from": L.name if L else None, "to": standby.name, "detection_s": round(now - hb, 2),
               "checkpoint_offset": from_offset, "replayed_events": replayed, "restore_ms": round((time.time() - t0) * 1000, 1)}
        self.failovers.append(rec)
        self.ctx.log_event("fault-tolerance", f'Failover {rec["from"]} -> {rec["to"]}: restored checkpoint @offset {from_offset}, '
                                              f'replayed {replayed} events in {rec["restore_ms"]} ms; no incidents lost')

    def snapshot(self) -> dict:
        now = time.time()
        return {"status": self.status, "leader": self.leader.name if self.leader and self.leader.role == "leader" else None,
                "instances": [{"name": e.name, "role": e.role, "heartbeat_age_s": round(now - e.heartbeat, 1) if e.heartbeat else None,
                               "offset": e.state["offset"] if e.state else None,
                               "restart_in_s": round(e.restart_at - now, 1) if e.restart_at else None} for e in self.engines],
                "failovers": self.failovers[-5:], "log_end": self.ctx.gateway.log.end,
                "lag": (self.ctx.gateway.log.end - self.leader.state["offset"]) if self.leader and self.leader.state else None}
