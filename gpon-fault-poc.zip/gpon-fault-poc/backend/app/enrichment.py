"""Alarm enrichment: topology context, device metadata and historical behaviour."""
from __future__ import annotations


def enrich(ctx, alarm: dict) -> dict:
    topo = ctx.topo
    eid = alarm["entity"]
    e = topo.entities[eid]
    impact = topo.impacted(eid)
    manager = topo.manager_of(eid)
    meta = dict(topo.entities.get(manager, {}).get("meta", {}))
    meta.update(e.get("meta", {}))
    hist = ctx.history.entity_stats(eid)
    olt = eid if e["class"] == "OLT" else topo.nearest(eid, "OLT")
    pon = eid if e["class"] == "PONPort" else topo.nearest(eid, "PONPort")
    splitter = topo.nearest(eid, "Splitter")
    path = topo.path_to_core(eid)
    services = impact["services"] if e["kind"] != "service" else [eid]
    return {
        "topology": {"class": e["class"], "layer": e["layer"], "domain": e["domain"], "olt": olt, "pon_port": pon,
                     "splitter": splitter, "path_to_core": path[:10], "managed_by": manager,
                     "site": meta.get("site")},
        "device": {k: meta[k] for k in ("vendor", "model", "sw", "installed", "role", "rate", "standard", "serial") if k in meta},
        "impact": {"services": services[:12], "service_count": len(services), "cell_sites": impact["cell_sites"],
                   "subscribers": impact["subscribers"] or int(e.get("meta", {}).get("subscribers", 0))},
        "history": hist,
    }
