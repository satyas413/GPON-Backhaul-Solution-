"""AI component: anomaly detection, fault prediction, topology-aware RCA and remediation ranking.

Models
* Telemetry anomaly detection: one IsolationForest per telemetry family (ONT, PON port, E1, PW, OLT),
  trained on healthy telemetry at start-up. A sample is anomalous when its score falls below a low
  quantile of the training scores for N consecutive samples; the most deviating feature is reported.
* Alarm-pattern anomaly: EWMA mean/variance of the alarm arrival rate -> storm detection (z-score).
* Fault prediction: per-ONT linear trend of downstream Rx power -> time-to-threshold, combined with a
  logistic-regression model (slope, residual noise, margin) that outputs P(fault within horizon).
* Correlation support: alarm-type co-occurrence (normalised PMI) learned from incident history.
* Root-cause analysis: Bayesian scoring of every candidate entity in the topological closure of the
  alarmed entities: prior(class) x prod P(alarm | candidate) x penalty(healthy observable dependents).
* Remediation ranking: playbooks matched to (root class, fault category, alarm pattern) ranked by
  Beta-smoothed historical success rate and similar-incident evidence.
"""
from __future__ import annotations

import math
import time
from collections import defaultdict, deque

import numpy as np
from sklearn.ensemble import IsolationForest
from sklearn.linear_model import LogisticRegression

from .history import HistoryStore
from .ontology import AlarmCatalog, Topology

FAMILIES = {
    "ONT": ["rx_power_dbm", "temp_c", "us_ber"],
    "PONPort": ["us_ber", "tx_bias_ma", "util_pct"],
    "E1Circuit": ["es", "ses", "slips"],
    "Pseudowire": ["jb_underruns", "loss_pct"],
    "OLT": ["cpu_pct", "temp_c"],
}
LOG_FEATURES = {"us_ber"}


class AIUnavailable(Exception):
    pass


def _vec(family: str, m: dict) -> list[float]:
    out = []
    for k in FAMILIES[family]:
        v = float(m.get(k, 0.0))
        out.append(math.log10(max(v, 1e-15)) if k in LOG_FEATURES else v)
    return out


class AIService:
    def __init__(self, topo: Topology, catalog: AlarmCatalog, history: HistoryStore, cfg: dict):
        self.topo = topo
        self.catalog = catalog
        self.history = history
        self.cfg = cfg
        self.up = True
        self.models: dict[str, IsolationForest] = {}
        self.thresholds: dict[str, float] = {}
        self.norm: dict[str, tuple[np.ndarray, np.ndarray]] = {}
        self.consec: dict[str, int] = defaultdict(int)
        self.normal_run: dict[str, int] = defaultdict(int)
        self.anomalous: dict[str, dict] = {}
        self.rx_hist: dict[str, deque] = defaultdict(lambda: deque(maxlen=40))
        self.predicted: dict[str, dict] = {}
        self.rate_mean = 0.0
        self.rate_var = 1.0
        self.rate_bucket: deque = deque()
        self.storm = {"active": False, "z": 0.0, "rate_per_s": 0.0}
        self.stats = {"inferences": 0, "anomalies_raised": 0, "predictions_raised": 0, "rca_runs": 0,
                      "last_latency_ms": 0.0, "trained_at": None}
        self.predictor: LogisticRegression | None = None

    # -------------------------------------------------------------- training
    def train(self, sampler) -> None:
        t0 = time.time()
        for fam in FAMILIES:
            X = np.array([_vec(fam, s) for s in sampler(fam, 3000)])
            model = IsolationForest(n_estimators=120, random_state=7).fit(X)
            scores = model.score_samples(X)
            self.models[fam] = model
            self.thresholds[fam] = float(np.quantile(scores, self.cfg["anomaly_quantile"])) - 0.02
            self.norm[fam] = (X.mean(axis=0), X.std(axis=0) + 1e-6)
        rng = np.random.default_rng(3)
        n = 3000
        # features: slope (dB/min), residual std (dB), margin to sensitivity (dB)
        pos = np.column_stack([rng.uniform(-6, -0.5, n), rng.uniform(0.05, 0.35, n), rng.uniform(0.3, 9, n)])
        neg = np.column_stack([rng.normal(0, 0.25, n), rng.uniform(0.05, 0.45, n), rng.uniform(2, 11, n)])
        conf = np.column_stack([rng.uniform(-0.6, -0.2, n // 3), rng.uniform(0.2, 0.5, n // 3), rng.uniform(6, 11, n // 3)])
        X = np.vstack([pos, neg, conf])
        y = np.concatenate([np.ones(n), np.zeros(n), np.zeros(n // 3)])
        self.predictor = LogisticRegression(max_iter=500).fit(X, y)
        self.stats["trained_at"] = time.time()
        self.stats["train_s"] = round(time.time() - t0, 2)

    def check(self) -> None:
        if not self.up:
            raise AIUnavailable("AI inference service unavailable")

    # ------------------------------------------------------------- telemetry
    def analyze_telemetry(self, ev: dict) -> list[dict]:
        """Return derived alarm events (AI_ANOMALY / PREDICTED_FAULT raise/clear)."""
        self.check()
        t0 = time.time()
        out: list[dict] = []
        for s in ev["samples"]:
            ent = s["entity"]
            fam = self.topo.cls(ent)
            if fam not in self.models:
                continue
            x = np.array([_vec(fam, s["metrics"])])
            score = float(self.models[fam].score_samples(x)[0])
            self.stats["inferences"] += 1
            mean, std = self.norm[fam]
            z = (x[0] - mean) / std
            if score < self.thresholds[fam]:
                self.consec[ent] += 1
                self.normal_run[ent] = 0
                if self.consec[ent] >= self.cfg["anomaly_consecutive"] and ent not in self.anomalous:
                    i = int(np.argmax(np.abs(z)))
                    feat = FAMILIES[fam][i]
                    raw_v = s["metrics"].get(feat)
                    detail = {"feature": feat, "value": raw_v, "z": round(float(z[i]), 1), "score": round(score, 3),
                              "model": "IsolationForest"}
                    self.anomalous[ent] = detail
                    self.stats["anomalies_raised"] += 1
                    out.append(self._derived(ent, "AI_ANOMALY", "raise", ev["ts"], detail))
            else:
                self.consec[ent] = 0
                self.normal_run[ent] += 1
                if ent in self.anomalous and self.normal_run[ent] >= 3:
                    del self.anomalous[ent]
                    out.append(self._derived(ent, "AI_ANOMALY", "clear", ev["ts"], {}))
            if fam == "ONT":
                out.extend(self._predict(ent, ev["ts"], s["metrics"]["rx_power_dbm"]))
        self.stats["last_latency_ms"] = round((time.time() - t0) * 1000, 2)
        return out

    def _predict(self, ent: str, ts: float, rx: float) -> list[dict]:
        h = self.rx_hist[ent]
        h.append((ts, rx))
        if len(h) < self.cfg["min_trend_samples"]:
            return []
        t = np.array([p[0] for p in h]) - h[0][0]
        y = np.array([p[1] for p in h])
        if t[-1] <= 0:
            return []
        slope, icpt = np.polyfit(t, y, 1)
        resid = y - (slope * t + icpt)
        r_std = float(resid.std())
        sens = self.cfg["rx_sensitivity_dbm"]
        current = float(slope * t[-1] + icpt)
        margin = current - sens
        feats = np.array([[slope * 60, r_std, margin]])
        prob = float(self.predictor.predict_proba(feats)[0, 1]) if self.predictor is not None else 0.0
        out = []
        if slope < -0.005 and margin > 0:
            tte = margin / -slope
            if tte < self.cfg["prediction_horizon_s"] and prob > 0.6 and ent not in self.predicted:
                detail = {"metric": "rx_power_dbm", "current": round(current, 2), "threshold": sens,
                          "slope_db_per_min": round(slope * 60, 2), "time_to_threshold_s": round(tte), "probability": round(prob, 2),
                          "model": "linear trend + logistic regression"}
                self.predicted[ent] = detail
                self.stats["predictions_raised"] += 1
                out.append(self._derived(ent, "PREDICTED_FAULT", "raise", ts, detail))
            elif ent in self.predicted:
                self.predicted[ent].update({"current": round(current, 2), "time_to_threshold_s": round(tte), "probability": round(prob, 2)})
        elif ent in self.predicted and (slope > -0.002 or margin > 6):
            del self.predicted[ent]
            out.append(self._derived(ent, "PREDICTED_FAULT", "clear", ts, {}))
        return out

    def _derived(self, ent: str, atype: str, state: str, ts: float, detail: dict) -> dict:
        return {"kind": "alarm", "id": f"ai:{atype}:{ent}:{state}:{ts:.3f}", "reporter": "AI", "entity": ent, "type": atype,
                "severity": self.catalog.get(atype)["severity"], "state": state, "ts": ts, "source": "ai",
                "detail": detail, "priority": 1}

    def reset_entity(self, ent: str) -> None:
        self.rx_hist.pop(ent, None)

    # --------------------------------------------------------- alarm pattern
    def observe_alarm(self, ts: float) -> None:
        self.rate_bucket.append(ts)

    def update_rate(self, now: float, dt: float = 2.0) -> None:
        while self.rate_bucket and self.rate_bucket[0] < now - dt:
            self.rate_bucket.popleft()
        rate = len(self.rate_bucket) / dt
        z = (rate - self.rate_mean) / math.sqrt(max(self.rate_var, 1.0))
        alpha = 0.05
        if z < 4:  # do not learn from storms
            d = rate - self.rate_mean
            self.rate_mean += alpha * d
            self.rate_var = (1 - alpha) * (self.rate_var + alpha * d * d)
        self.storm = {"active": bool(self.up and z > 6 and rate > 20), "z": round(float(z), 1), "rate_per_s": round(rate, 1)}

    # ------------------------------------------------------------ correlation
    def cooccurrence(self, a: str, types: set[str]) -> float:
        self.check()
        return max((self.history.cooccurrence(a, b) for b in types), default=0.0)

    # -------------------------------------------------------------------- RCA
    def rca(self, alarms: list[dict]) -> dict:
        self.check()
        self.stats["rca_runs"] += 1
        topo = self.topo
        if not alarms:
            return {"method": "ai-bayesian", "hypotheses": []}
        alarmed = {a["entity"] for a in alarms}
        cands = set(alarmed)
        for e in alarmed:
            cands |= set(topo.ancestors(e))
        cands = {c for c in cands if topo.entities[c]["kind"] != "service"}
        prior = self.history.class_prior
        scored = []
        for c in cands:
            ccls = topo.cls(c)
            ll = math.log(prior.get(ccls, 0.01))
            explained, evidence = 0, []
            for a in alarms:
                imp = self.catalog.implicates(a["type"], a.get("detail"))
                below = topo.descendants(a["entity"]).get(c)
                if a.get("reporter") == c:
                    L = 0.05  # an element that is still sending alarms is alive: weak candidate
                elif c == a["entity"] and ccls in imp:
                    L = imp[ccls]
                    evidence.append(f'{a["type"]}@{a["entity"]} directly implicates {ccls} ({L:.2f})')
                elif below is not None and below <= 2 and topo.entities[c]["kind"] in ("passive", "link") and ccls in imp:
                    L = imp[ccls]
                    evidence.append(f'{a["type"]}@{a["entity"]} implicates the {ccls} below it ({L:.2f})')
                elif c == a["entity"]:
                    L = 0.5
                elif topo.is_ancestor(c, a["entity"]):
                    L = 0.9
                else:
                    L = 0.02
                if L >= 0.25:
                    explained += 1
                ll += math.log(L)
            healthy = [d for d in topo.descendants(c) if topo.entities[d]["observable"]
                       and topo.entities[d]["kind"] in ("device", "port", "service", "logical") and d not in alarmed]
            ll += math.log(0.15) * min(len(healthy), 8)
            scored.append((ll, c, explained, healthy, evidence))
        scored.sort(reverse=True)
        top = scored[:6]
        mx = top[0][0]
        z = sum(math.exp(s[0] - mx) for s in scored)
        hyps = []
        for ll, c, explained, healthy, evidence in top:
            p = math.exp(ll - mx) / z
            hyps.append({"entity": c, "class": topo.cls(c), "confidence": round(p, 3),
                         "coverage": round(explained / len(alarms), 2), "healthy_dependents": len(healthy),
                         "prior": round(prior.get(topo.cls(c), 0.01), 3), "evidence": evidence[:3]})
        return {"method": "ai-bayesian", "hypotheses": hyps, "candidates_scored": len(scored)}

    # ------------------------------------------------------------- recommend
    def rank_playbooks(self, matches: list[dict], root_class: str, category: str) -> list[dict]:
        self.check()
        sim = self.history.similar(root_class, category)
        out = []
        for pb in matches:
            st = self.history.playbook_stats.get(pb["id"], {"rate": 0.5, "n": 0})
            spec = pb.get("_specificity", 1.0)
            out.append({**pb, "success_rate": round(st["rate"], 2), "history_n": st["n"],
                        "score": round(st["rate"] * spec, 3), "similar_incidents": sim})
        out.sort(key=lambda p: -p["score"])
        return out

    def snapshot(self) -> dict:
        return {"up": self.up, "storm": self.storm, "anomalies": dict(self.anomalous), "predictions": dict(self.predicted),
                "stats": dict(self.stats), "models": {f: "IsolationForest(120 trees)" for f in self.models} |
                {"rx_power_predictor": "LinearTrend + LogisticRegression"}}


def rule_based_rca(topo: Topology, alarms: list[dict]) -> dict:
    """Safe-mode fallback: pick the most upstream alarmed entity (classic topology suppression)."""
    alarmed = sorted({a["entity"] for a in alarms})
    if not alarmed:
        return {"method": "rule-based (safe mode)", "hypotheses": []}
    best = max(alarmed, key=lambda e: (sum(1 for o in alarmed if topo.is_ancestor(e, o)), -len(topo.ancestors(e))))
    cov = (1 + sum(1 for o in alarmed if topo.is_ancestor(best, o))) / len(alarmed)
    return {"method": "rule-based (safe mode)", "hypotheses": [
        {"entity": best, "class": topo.cls(best), "confidence": None, "coverage": round(cov, 2), "healthy_dependents": None,
         "prior": None, "evidence": ["most upstream alarmed entity"]}]}
