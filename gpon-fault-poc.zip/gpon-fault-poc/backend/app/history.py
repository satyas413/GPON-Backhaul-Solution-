"""Historical store (SQLite): past incidents, learned statistics and correlation-engine checkpoints.

On first start the store is seeded with 30 days of synthetic operating history: days 1-15 under a
traditional rule-based NOC process, days 16-30 under the AI closed loop. The AI component learns its
priors, alarm co-occurrence statistics and playbook success rates from this table, and every live
incident resolved during the demo is appended to it.
"""
from __future__ import annotations

import json
import math
import random
import sqlite3
import threading
import time
from collections import Counter, defaultdict
from pathlib import Path

from .ontology import Topology

DATA_DIR = Path(__file__).resolve().parent.parent / "data"

ROOT_MIX = [  # (class, category, share, alarm template, playbook, ai success rate)
    ("FiberSegment", "link_down", 0.22, ["ONT_LOSi", "SERVICE_SLA_BREACH"], "noc_investigation", 0.0),
    ("FiberSegment", "link_down", 0.06, ["PON_LOS", "ONT_LOSi", "ONT_LOSi", "ONT_LOSi", "PW_DOWN", "E1_AIS", "ABIS_LINK_DOWN", "SERVICE_SLA_BREACH"], "pon_type_b_switchover", 0.93),
    ("ONT", "equipment", 0.17, ["ONT_DYING_GASP", "SERVICE_SLA_BREACH"], "transient_watch", 0.95),
    ("ONT", "signal_degradation", 0.10, ["ONT_RX_POWER_LOW", "AI_ANOMALY", "PREDICTED_FAULT"], "ont_optical_proactive", 0.9),
    ("E1Circuit", "timing_sync", 0.12, ["E1_FRAME_SLIP", "PW_JITTER_BUFFER_UNDERRUN", "CALL_DROP_RATE_HIGH"], "e1_timing_relock", 0.88),
    ("PONPort", "signal_degradation", 0.08, ["PON_BER_SD", "ONT_SDi", "ONT_SDi", "E1_ERRORED_SECONDS", "SERVICE_DEGRADED", "AI_ANOMALY"], "pon_optics_recovery", 0.55),
    ("Splitter", "link_down", 0.03, ["PON_LOS", "ONT_LOSi", "ONT_LOSi", "SERVICE_SLA_BREACH"], "pon_type_b_switchover", 0.85),
    ("OLT", "equipment", 0.03, ["NE_UNREACHABLE", "ONT_LOSi", "ABIS_LINK_DOWN"], "noc_investigation", 0.0),
    ("EthernetUplink", "link_down", 0.04, ["LINK_DOWN", "NE_UNREACHABLE", "ABIS_LINK_DOWN", "SERVICE_SLA_BREACH"], "uplink_reroute", 0.8),
    ("E1Circuit", "link_down", 0.08, ["E1_LOS", "ABIS_LINK_DOWN"], "transient_watch", 0.9),
    ("AggregationSwitch", "performance", 0.05, ["HIGH_CPU"], "transient_watch", 0.97),
    ("Pseudowire", "timing_sync", 0.02, ["PW_JITTER_BUFFER_UNDERRUN", "CALL_DROP_RATE_HIGH"], "e1_timing_relock", 0.8),
]


class HistoryStore:
    def __init__(self, topo: Topology, path: Path | None = None):
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        self.path = path or DATA_DIR / "history.db"
        self.topo = topo
        self.lock = threading.Lock()
        self.db = sqlite3.connect(self.path, check_same_thread=False)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS incidents (
            id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, mode TEXT, root_entity TEXT, root_class TEXT,
            category TEXT, alarm_types TEXT, alarm_count INTEGER, playbook TEXT, outcome TEXT,
            mttd_s REAL, mttr_s REAL, resolved_by TEXT);
        CREATE INDEX IF NOT EXISTS ix_inc_root ON incidents(root_entity);
        CREATE TABLE IF NOT EXISTS checkpoints (name TEXT PRIMARY KEY, ts REAL, offset INTEGER, state TEXT);
        """)
        if self.db.execute("SELECT COUNT(*) FROM incidents").fetchone()[0] == 0:
            self.seed()
        self.refresh_stats()

    # ------------------------------------------------------------------ seed
    def seed(self, days: int = 30) -> None:
        rng = random.Random(42)
        now = time.time()
        by_class: dict[str, list[str]] = defaultdict(list)
        for eid, e in self.topo.entities.items():
            by_class[e["class"]].append(eid)
        rows = []
        weights = [m[2] for m in ROOT_MIX]
        for d in range(days):
            ai = d >= days // 2
            day_ts = (int(now // 86400) - (days - d)) * 86400  # UTC midnight, so each seeded day is one calendar day
            for _ in range(rng.randint(22, 34)):
                cls, cat, _, tmpl, pb, succ = rng.choices(ROOT_MIX, weights)[0]
                ent = rng.choice(by_class.get(cls) or ["unknown"])
                alarms = list(tmpl) + [rng.choice(tmpl) for _ in range(rng.randint(0, 6))]
                if ai:
                    ok = rng.random() < succ
                    auto = ok and pb not in ("noc_investigation",)
                    mttd = rng.lognormvariate(math.log(40), 0.5)
                    mttr = rng.lognormvariate(math.log(5 * 60), 0.6) if auto else rng.lognormvariate(math.log(48 * 60), 0.5)
                    outcome, by = ("success", "autonomous") if auto else ("manual", "human")
                    playbook = pb
                else:
                    mttd = rng.lognormvariate(math.log(9 * 60), 0.5)
                    mttr = rng.lognormvariate(math.log(115 * 60), 0.45)
                    outcome, by, playbook = "manual", "human", "manual_runbook"
                rows.append((day_ts + rng.uniform(0, 86399), "ai" if ai else "rule", ent, cls, cat, json.dumps(alarms),
                             len(alarms) * (1 if ai else 1), playbook, outcome, mttd, mttr, by))
        with self.lock:
            self.db.executemany("INSERT INTO incidents (ts, mode, root_entity, root_class, category, alarm_types, alarm_count,"
                                " playbook, outcome, mttd_s, mttr_s, resolved_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", rows)
            self.db.commit()

    # --------------------------------------------------------------- learned
    def refresh_stats(self) -> None:
        with self.lock:
            rows = self.db.execute("SELECT root_class, alarm_types, playbook, outcome, root_entity, ts, mode FROM incidents").fetchall()
        cls_count: Counter = Counter()
        type_count: Counter = Counter()
        pair_count: Counter = Counter()
        pb: dict[str, list[int]] = defaultdict(lambda: [0, 0])
        ent: dict[str, list[float]] = defaultdict(list)
        n = 0
        for cls, types_json, playbook, outcome, ent_id, ts, mode in rows:
            n += 1
            cls_count[cls] += 1
            types = set(json.loads(types_json))
            for t in types:
                type_count[t] += 1
            for a in types:
                for b in types:
                    if a < b:
                        pair_count[(a, b)] += 1
            if mode != "rule":
                pb[playbook][0 if outcome == "success" else 1] += 1
            ent[ent_id].append(ts)
        total = sum(cls_count.values()) or 1
        self.class_prior = {c: (cls_count.get(c, 0) + 0.5) / (total + 0.5 * len(self.topo.classes)) for c in self.topo.classes}
        self.cooc = {}
        for (a, b), c in pair_count.items():
            pmi = math.log((c * n) / (type_count[a] * type_count[b]))
            npmi = pmi / -math.log(c / n) if c < n else 1.0
            self.cooc[(a, b)] = max(0.0, npmi)
        self.playbook_stats = {k: {"success": v[0], "failed": v[1], "rate": (v[0] + 1) / (v[0] + v[1] + 2), "n": v[0] + v[1]}
                               for k, v in pb.items()}
        self.entity_ts = ent
        self.n_incidents = n

    def cooccurrence(self, a: str, b: str) -> float:
        if a == b:
            return 1.0
        return self.cooc.get((min(a, b), max(a, b)), 0.0)

    def entity_stats(self, eid: str) -> dict:
        ts = sorted(self.entity_ts.get(eid, []))
        now = time.time()
        recent = [t for t in ts if now - t < 30 * 86400]
        mtbf = None
        if len(ts) >= 2:
            mtbf = round((ts[-1] - ts[0]) / (len(ts) - 1) / 86400, 1)
        return {"incidents_30d": len(recent), "last_incident_days_ago": round((now - ts[-1]) / 86400, 1) if ts else None,
                "mtbf_days": mtbf}

    def similar(self, root_class: str, category: str) -> dict:
        with self.lock:
            rows = self.db.execute("SELECT playbook, outcome, mttr_s FROM incidents WHERE root_class=? AND category=? AND mode!='rule'",
                                   (root_class, category)).fetchall()
        if not rows:
            return {"count": 0}
        pbs = Counter(r[0] for r in rows)
        best = pbs.most_common(1)[0][0]
        succ = sum(1 for r in rows if r[0] == best and r[1] == "success")
        return {"count": len(rows), "top_playbook": best, "top_playbook_success": round(succ / pbs[best], 2),
                "median_mttr_min": round(sorted(r[2] for r in rows)[len(rows) // 2] / 60, 1)}

    # ----------------------------------------------------------------- write
    def record_incident(self, inc: dict) -> None:
        rca = (inc.get("rca") or {}).get("hypotheses") or [{}]
        root = rca[0].get("entity", "unknown")
        acts = inc["loop"].get("actions", [])
        with self.lock:
            self.db.execute("INSERT INTO incidents (ts, mode, root_entity, root_class, category, alarm_types, alarm_count, playbook,"
                            " outcome, mttd_s, mttr_s, resolved_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                            (time.time(), "live", root, self.topo.entities.get(root, {}).get("class", "unknown"),
                             inc.get("category") or "unknown", json.dumps(inc.get("alarm_types", [])), len(inc["alarms"]),
                             acts[-1]["playbook"] if acts else "none",
                             "success" if inc.get("resolved_by") == "autonomous" else "manual",
                             inc["metrics"].get("mttd_s"), inc["metrics"].get("mttr_s"), inc.get("resolved_by")))
            self.db.commit()

    def daily_trends(self) -> list[dict]:
        with self.lock:
            rows = self.db.execute("SELECT ts, mode, alarm_count, mttd_s, mttr_s, resolved_by FROM incidents WHERE mode!='live'"
                                   " ORDER BY ts").fetchall()
        days: dict[str, dict] = {}
        for ts, mode, ac, mttd, mttr, by in rows:
            d = time.strftime("%m-%d", time.gmtime(ts))
            x = days.setdefault(d, {"day": d, "mode": mode, "alarms": 0, "incidents": 0, "mttd": [], "mttr": [], "auto": 0})
            x["alarms"] += ac * (1 if mode == "ai" else 1)
            x["incidents"] += 1
            x["mttd"].append(mttd)
            x["mttr"].append(mttr)
            x["auto"] += 1 if by == "autonomous" else 0
        out = []
        for x in days.values():
            # under the rule-based process, many alarms became separate tickets (poor compression)
            tickets = x["incidents"] if x["mode"] == "ai" else int(x["alarms"] / 1.6)
            out.append({"day": x["day"], "mode": x["mode"], "raw_alarms": x["alarms"], "tickets": tickets,
                        "compression": round(x["alarms"] / max(tickets, 1), 1),
                        "mttd_min": round(sum(x["mttd"]) / len(x["mttd"]) / 60, 1),
                        "mttr_min": round(sum(x["mttr"]) / len(x["mttr"]) / 60, 1),
                        "auto_pct": round(100 * x["auto"] / x["incidents"], 0)})
        return out

    # ----------------------------------------------------------- checkpoints
    def save_checkpoint(self, name: str, offset: int, state: dict) -> None:
        blob = json.dumps(state, default=str)
        with self.lock:
            self.db.execute("INSERT OR REPLACE INTO checkpoints (name, ts, offset, state) VALUES (?,?,?,?)",
                            (name, time.time(), offset, blob))
            self.db.commit()

    def load_checkpoint(self, name: str) -> tuple[int, dict] | None:
        with self.lock:
            row = self.db.execute("SELECT offset, state FROM checkpoints WHERE name=?", (name,)).fetchone()
        if not row:
            return None
        return row[0], json.loads(row[1])

    def clear_checkpoint(self, name: str) -> None:
        with self.lock:
            self.db.execute("DELETE FROM checkpoints WHERE name=?", (name,))
            self.db.commit()
