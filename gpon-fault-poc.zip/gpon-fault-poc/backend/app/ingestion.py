"""Ingestion gateway: parse -> validate -> admission control -> de-duplicate -> re-order -> event log.

Fault-tolerance features
* Backpressure: a bounded queue with a high watermark. Above it, low-priority traffic (telemetry,
  info/warning) is shed; when full, everything is rejected with retry_after so sources back off.
* Retry: sources retry rejected submissions with exponential backoff + jitter (see sources.py).
* Duplicates: idempotency by event id (SNMP retransmissions, replays, at-least-once redelivery).
* Out-of-order: a time-windowed re-order buffer releases events in device-timestamp order; events
  that still arrive behind the watermark are flagged `late` and reconciled by the correlator.
* Malformed input goes to a dead-letter queue instead of crashing the pipeline.
"""
from __future__ import annotations

import asyncio
import heapq
import re
import time
from collections import OrderedDict, deque
from datetime import datetime

from .ontology import AlarmCatalog, Topology
from .sources import NUM_SEV, OID_TRAP

SYSLOG_RE = re.compile(
    r"^<(?P<pri>\d+)>1 (?P<ts>\S+) (?P<host>\S+) (?P<app>\S+) (?P<procid>\S+) (?P<msgid>\S+) "
    r"\[alarm@64999 (?P<sd>[^\]]*)\]\s*(?P<msg>.*)$")
SD_RE = re.compile(r'(\w+)="([^"]*)"')
LEGACY_SYSLOG_RE = re.compile(r"^<(?P<pri>\d+)>(?P<rest>.*)$")


def parse_ts(s) -> float:
    if isinstance(s, (int, float)):
        return float(s)
    return datetime.fromisoformat(str(s).replace("Z", "+00:00")).timestamp()


class EventLog:
    """Append-only, offset-addressed log (stands in for a Kafka topic)."""

    def __init__(self, retain: int = 60000):
        self.base = 0
        self.items: deque = deque()
        self.retain = retain

    @property
    def end(self) -> int:
        return self.base + len(self.items)

    def append(self, ev: dict) -> int:
        off = self.end
        ev["offset"] = off
        self.items.append(ev)
        if len(self.items) > self.retain:
            self.items.popleft()
            self.base += 1
        return off

    def read(self, offset: int, max_n: int) -> list[dict]:
        start = max(offset, self.base) - self.base
        stop = min(start + max_n, len(self.items))
        return [self.items[i] for i in range(start, stop)]


class IngestionGateway:
    def __init__(self, cfg: dict, catalog: AlarmCatalog, topo: Topology):
        self.cfg = cfg
        self.catalog = catalog
        self.topo = topo
        self.queue: deque = deque()
        self.capacity = cfg["queue_capacity"]
        self.log = EventLog()
        self.dedup: OrderedDict = OrderedDict()
        self.reorder: list = []
        self.watermark = 0.0
        self.max_seen_ts = 0.0
        self.dlq: deque = deque(maxlen=100)
        self.stats = {k: 0 for k in ("received", "accepted", "rejected_full", "shed_low_priority", "malformed",
                                     "duplicates", "reordered", "late", "logged", "telemetry_samples")}
        self.per_source: dict[str, int] = {}
        self.state = "normal"
        self.peak_depth = 0
        self._seq = 0

    # ------------------------------------------------------------- parsing
    def parse(self, source: str, raw) -> dict:
        if source == "snmp":
            vb = raw["varbinds"]
            atype = OID_TRAP.get(raw["trap_oid"]) or vb.get("gponAlarmType")
            if not atype:
                raise ValueError(f"unknown trap OID {raw['trap_oid']}")
            detail = {k.split(".", 1)[1]: v for k, v in vb.items() if k.startswith("gponAlarmDetail.")}
            return self._alarm(vb["gponAlarmId"], raw["agent"], vb["gponAlarmEntity"], atype,
                               NUM_SEV.get(int(vb["gponAlarmSeverity"]), "minor"),
                               "raise" if int(vb["gponAlarmState"]) == 1 else "clear",
                               parse_ts(vb["gponAlarmTime"]), source, detail)
        if source == "syslog":
            m = SYSLOG_RE.match(raw.strip())
            if not m:
                raise ValueError("not an RFC 5424 alarm syslog line")
            sd = dict(SD_RE.findall(m["sd"]))
            return self._alarm(sd["id"], m["host"], sd["entity"], m["msgid"], sd.get("severity", "minor"),
                               sd.get("state", "raise"), parse_ts(m["ts"]), source, {})
        if source == "stream":
            return self._alarm(raw["event_id"], raw["producer"], raw["entity"], raw["type"], raw.get("severity", "minor"),
                               raw.get("state", "raise"), parse_ts(raw["event_time"]), source, raw.get("attributes", {}))
        if source == "telemetry":
            ts = parse_ts(raw["ts"])
            samples = [s for s in raw["samples"] if s.get("entity") in self.topo.entities]
            return {"kind": "telemetry", "id": f'tm:{raw["producer"]}:{ts:.3f}', "producer": raw["producer"], "ts": ts,
                    "samples": samples, "source": source, "priority": 0}
        raise ValueError(f"unknown source type {source}")

    def _alarm(self, eid, reporter, entity, atype, severity, state, ts, source, detail) -> dict:
        if entity not in self.topo.entities:
            raise ValueError(f"unknown entity {entity}")
        if state not in ("raise", "clear"):
            raise ValueError(f"bad state {state}")
        if severity == "cleared":
            severity = self.catalog.get(atype)["severity"]
        prio = 2 if severity in ("critical", "major") or state == "clear" else 1
        return {"kind": "alarm", "id": str(eid), "reporter": reporter, "entity": entity, "type": atype,
                "severity": severity, "state": state, "ts": ts, "source": source, "detail": detail, "priority": prio}

    # ----------------------------------------------------------- admission
    def submit(self, source: str, raw) -> dict:
        """Synchronous admission decision. Returns accepted | rejected (retry) | invalid."""
        self.stats["received"] += 1
        self.per_source[source] = self.per_source.get(source, 0) + 1
        try:
            ev = self.parse(source, raw)
        except Exception as exc:  # noqa: BLE001 - anything malformed goes to the DLQ
            self.stats["malformed"] += 1
            self.dlq.append({"ts": time.time(), "source": source, "error": str(exc), "raw": str(raw)[:300]})
            return {"status": "invalid", "error": str(exc)}
        depth = len(self.queue)
        fill = depth / self.capacity
        if depth >= self.capacity:
            self.stats["rejected_full"] += 1
            self.state = "rejecting"
            return {"status": "rejected", "retry_after": 0.5}
        if fill >= self.cfg["high_watermark"] and ev["priority"] < 2:
            self.stats["shed_low_priority"] += 1
            self.state = "shedding"
            return {"status": "rejected", "retry_after": 1.0}
        ev["arrival"] = time.time()
        self.queue.append(ev)
        self.peak_depth = max(self.peak_depth, len(self.queue))
        self.stats["accepted"] += 1
        return {"status": "accepted"}

    # ---------------------------------------------------------- processing
    async def run(self) -> None:
        rate = self.cfg["process_rate_per_s"]
        tick = 0.05
        while True:
            budget = max(1, int(rate * tick))
            while self.queue and budget > 0:
                ev = self.queue.popleft()
                budget -= 1
                self._dedup_and_buffer(ev)
            self._release()
            depth = len(self.queue)
            if depth < self.capacity * self.cfg["high_watermark"] * 0.5:
                self.state = "normal"
            await asyncio.sleep(tick)

    def _dedup_and_buffer(self, ev: dict) -> None:
        now = time.time()
        key = ev["id"]
        if key in self.dedup:
            self.stats["duplicates"] += 1
            return
        self.dedup[key] = now
        ttl = self.cfg["dedup_ttl_s"]
        while self.dedup:
            k, t = next(iter(self.dedup.items()))
            if now - t > ttl or len(self.dedup) > 50000:
                self.dedup.popitem(last=False)
            else:
                break
        if ev["ts"] < self.max_seen_ts:
            self.stats["reordered"] += 1
        self.max_seen_ts = max(self.max_seen_ts, ev["ts"])
        self._seq += 1
        heapq.heappush(self.reorder, (ev["ts"], self._seq, ev))

    def _release(self) -> None:
        horizon = time.time() - self.cfg["reorder_window_s"]
        while self.reorder and self.reorder[0][0] <= horizon:
            ts, _, ev = heapq.heappop(self.reorder)
            if ts < self.watermark:
                ev["late"] = True
                self.stats["late"] += 1
            self.watermark = max(self.watermark, ts)
            if ev["kind"] == "telemetry":
                self.stats["telemetry_samples"] += len(ev["samples"])
            self.log.append(ev)
            self.stats["logged"] += 1

    def snapshot(self) -> dict:
        return {"state": self.state, "queue_depth": len(self.queue), "capacity": self.capacity,
                "high_watermark": int(self.capacity * self.cfg["high_watermark"]), "peak_depth": self.peak_depth,
                "reorder_buffer": len(self.reorder), "log_end": self.log.end, "stats": dict(self.stats),
                "per_source": dict(self.per_source), "dlq": list(self.dlq)[-10:]}
