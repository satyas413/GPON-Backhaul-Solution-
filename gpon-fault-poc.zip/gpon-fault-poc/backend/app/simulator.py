"""Physical network simulator for the G.702 + GPON backhaul.

The simulator holds the ground-truth fault state, derives the operational status of every entity by
propagating failures along `depends_on`, and turns status changes into the alarms each real element
would emit (OLT SNMP traps, CES gateway / PDH mux syslog, BSC / service-assurance / NMS event stream).
It also produces periodic PM telemetry and applies remediation actions to the network.

Nothing downstream reads the simulator's truth directly: the fault-management pipeline only sees the
raw messages the simulator emits, exactly as it would in a live network.
"""
from __future__ import annotations

import math
import random
import time
import uuid
from dataclasses import dataclass, field

from .ontology import AlarmCatalog, Topology

DOWN_FAULTS = {"cut", "fail", "power"}
DEGRADE_FAULTS = {"optics_degraded", "timing", "rx_drift"}

REPORTER_SOURCE = {"OLT": "snmp", "CESGateway": "syslog", "G702Mux": "syslog", "AggregationSwitch": "syslog",
                   "CoreRouter": "syslog", "BSC": "stream"}
VIRTUAL_REPORTERS = {"NMS": "stream", "SA": "stream"}


@dataclass
class Fault:
    entity: str
    type: str
    since: float
    params: dict = field(default_factory=dict)
    until: float | None = None  # auto-clear (transient faults)


class NetworkSim:
    def __init__(self, topo: Topology, catalog: AlarmCatalog, settings: dict):
        self.topo = topo
        self.catalog = catalog
        self.cfg = settings["simulation"]
        self.ai_cfg = settings["ai"]
        self.rng = random.Random(self.cfg.get("seed", 7))
        self.faults: dict[str, Fault] = {}
        self.mgmt_unreachable: set[str] = set()
        self.extra_alarms: dict[tuple, dict] = {}
        self.active: dict[tuple, dict] = {}
        self.seq: dict[str, int] = {}
        self.status: dict[str, tuple] = {}
        self.pending_jobs: list[tuple[float, str, str]] = []  # (due, kind, entity) e.g. field work
        self.base_rx = {e: -17.5 - (abs(hash(e)) % 35) / 10.0 for e, v in topo.entities.items() if v["class"] == "ONT"}
        self._recompute(time.time())

    # ---------------------------------------------------------------- faults
    def inject(self, entity: str, ftype: str, duration: float | None = None, **params) -> Fault:
        now = time.time()
        f = Fault(entity, ftype, now, params, now + duration if duration else None)
        self.faults[entity] = f
        return f

    def repair(self, entities) -> list[str]:
        fixed = []
        for e in list(entities):
            if e in self.faults:
                del self.faults[e]
                fixed.append(e)
        return fixed

    def repair_all(self) -> None:
        self.faults.clear()
        self.extra_alarms.clear()
        self.mgmt_unreachable.clear()
        self.pending_jobs.clear()
        for eid, e in self.topo.entities.items():
            prot = e.get("protection")
            if prot and e["depends_on"] != [prot["working"]]:
                self.topo.set_dependencies(eid, [prot["working"]])
            if e["class"] == "FiberSegment" and e.get("orig_depends_on"):
                self.topo.set_dependencies(eid, e.pop("orig_depends_on"))

    def truth_onset(self, entity: str) -> float | None:
        """Ground-truth fault start for KPI evaluation (MTTD/MTTR) only."""
        cands = [f.since for fe, f in self.faults.items()
                 if fe == entity or self.topo.is_ancestor(fe, entity)]
        return min(cands) if cands else None

    def rx_power(self, ont: str, now: float) -> float:
        base = self.base_rx.get(ont, -19.0)
        f = self.faults.get(ont)
        if f and f.type == "rx_drift":
            return base - f.params.get("rate_db_per_s", 0.08) * (now - f.since)
        return base

    # ----------------------------------------------------------------- status
    def _own(self, eid: str, now: float):
        f = self.faults.get(eid)
        if not f:
            return None
        if f.params.get("suppressed_until", 0) > now:
            return None
        if f.type in DOWN_FAULTS:
            return ("down", eid, f.type)
        if f.type == "rx_drift":
            rx = self.rx_power(eid, now)
            sens = self.ai_cfg["rx_sensitivity_dbm"]
            if rx < sens - 2.5:
                return ("down", eid, "rx_drift")
            if rx < sens:
                return ("degraded", eid, "rx_drift")
            return None
        return ("degraded", eid, f.type)

    def _recompute(self, now: float) -> None:
        st: dict[str, tuple] = {}
        rank = {"up": 0, "degraded": 1, "down": 2}

        def ev(eid: str):
            if eid in st:
                return st[eid]
            st[eid] = ("up", None, None)
            best = self._own(eid, now) or ("up", None, None)
            for p in self.topo.entities[eid]["depends_on"]:
                ps = ev(p)
                if rank[ps[0]] > rank[best[0]]:
                    best = ps
            st[eid] = best
            return best

        for eid in self.topo.entities:
            ev(eid)
        self.status = st

    def is_up(self, eid: str) -> bool:
        return self.status.get(eid, ("up",))[0] != "down"

    # ----------------------------------------------------------------- alarms
    def _expected_alarms(self) -> dict[tuple, dict]:
        topo, st = self.topo, self.status
        exp: dict[tuple, dict] = {}

        def add(reporter: str, entity: str, atype: str, **detail):
            if reporter not in VIRTUAL_REPORTERS and not self.is_up(reporter):
                return
            exp[(reporter, entity, atype)] = detail

        for eid, (s, origin, ftype) in st.items():
            e = topo.entities[eid]
            cls = e["class"]
            if cls == "PONPort":
                olt = e["depends_on"][0]
                feeders = [d for d in topo.dependents.get(eid, []) if topo.cls(d) == "FiberSegment"]
                if s == "down" and origin == eid:
                    add(olt, eid, "PON_PORT_FAIL")
                elif s == "degraded" and origin == eid and feeders:
                    add(olt, eid, "PON_BER_SD", tx_bias="high")
                elif s == "up":
                    for f in feeders:
                        spl = topo.entities[f]["b"]
                        active = f in topo.entities[spl]["depends_on"]
                        if not self.is_up(f):
                            add(olt, eid, "PON_LOS" if active else "PON_PROTECTION_UNAVAILABLE", laser_tx="ok")
                        elif active and not self.is_up(spl):
                            add(olt, eid, "PON_LOS", laser_tx="ok")
                continue
            if s == "up":
                continue
            if cls == "ONT":
                olt = topo.nearest(eid, "OLT")
                if s == "down":
                    if origin == eid and ftype == "power":
                        add(olt, eid, "ONT_DYING_GASP")
                    else:
                        add(olt, eid, "ONT_LOSi")
                elif origin == eid and ftype == "rx_drift":
                    add(olt, eid, "ONT_RX_POWER_LOW")
                else:
                    add(olt, eid, "ONT_SDi")
            elif cls == "OLT":
                add("NMS", eid, "NE_UNREACHABLE")
            elif cls in ("EthernetUplink", "CoreLink", "STM1Link", "E3Trunk") and origin == eid:
                add(e["a"], eid, "LINK_DOWN")
            elif cls in ("AggregationSwitch", "CoreRouter", "CESGateway", "G702Mux", "BSC") and origin == eid:
                add("NMS", eid, "NE_UNREACHABLE")
            elif cls == "E1Circuit":
                head = e["a"]
                if topo.cls(head) == "ONT":
                    olt = topo.nearest(eid, "OLT")
                    if s == "down":
                        if origin == eid:
                            add(olt, eid, "E1_LOS")
                        else:
                            add("CESGW-1", eid, "E1_AIS")
                    elif origin == eid and ftype == "timing":
                        add(olt, eid, "E1_FRAME_SLIP", slips_per_15min=40)
                    else:
                        add("CESGW-1", eid, "E1_ERRORED_SECONDS")
                else:
                    if s == "down" and origin == eid:
                        add(head, eid, "E1_LOS")
                    elif s == "degraded":
                        add(head, eid, "E1_ERRORED_SECONDS")
            elif cls == "Pseudowire":
                add("CESGW-1", eid, "PW_DOWN" if s == "down" else "PW_JITTER_BUFFER_UNDERRUN")
            elif e["kind"] == "service":
                if e["class"] == "MobileBackhaulService":
                    add("BSC-1", eid, "ABIS_LINK_DOWN" if s == "down" else "CALL_DROP_RATE_HIGH")
                else:
                    add("SA", eid, "SERVICE_SLA_BREACH" if s == "down" else "SERVICE_DEGRADED")
        now = time.time()
        for k, v in list(self.extra_alarms.items()):
            if v["until"] <= now:
                del self.extra_alarms[k]
            else:
                exp[k] = v.get("detail", {})
        return exp

    def tick(self) -> list[dict]:
        """Advance the network one step; return raise/clear alarm events (device view)."""
        now = time.time()
        for eid, f in list(self.faults.items()):
            if f.until and f.until <= now:
                del self.faults[eid]
        for job in list(self.pending_jobs):
            due, kind, ent = job
            if due <= now:
                self.pending_jobs.remove(job)
                if kind == "field_fix":
                    self.repair([ent])
        self._recompute(now)
        exp = self._expected_alarms()
        events = []
        for k, detail in exp.items():
            if k not in self.active:
                self.active[k] = {"id": str(uuid.uuid4()), "ts": now}
                events.append(self._event(k, "raise", now, detail))
        for k in list(self.active):
            if k not in exp:
                del self.active[k]
                events.append(self._event(k, "clear", now, {}))
        return events

    def _event(self, key: tuple, state: str, now: float, detail: dict) -> dict:
        reporter, entity, atype = key
        self.seq[reporter] = self.seq.get(reporter, 0) + 1
        cat = self.catalog.get(atype)
        return {"id": str(uuid.uuid4()), "reporter": reporter, "entity": entity, "type": atype,
                "severity": "cleared" if state == "clear" else cat["severity"], "state": state,
                "ts": now, "seq": self.seq[reporter], "detail": detail,
                "source": self.source_of(reporter)}

    def source_of(self, reporter: str) -> str:
        if reporter in VIRTUAL_REPORTERS:
            return VIRTUAL_REPORTERS[reporter]
        return REPORTER_SOURCE.get(self.topo.cls(reporter), "syslog")

    # -------------------------------------------------------------- telemetry
    def telemetry(self) -> list[dict]:
        now = time.time()
        g = self.rng.gauss
        msgs = []
        for olt, e in self.topo.entities.items():
            if e["class"] != "OLT" or not self.is_up(olt):
                continue
            samples = [{"entity": olt, "metrics": {"cpu_pct": round(g(22, 3), 1), "temp_c": round(g(48, 1), 1)}}]
            for port in self.topo.dependents.get(olt, []):
                if self.topo.cls(port) != "PONPort" or not self.is_up(port):
                    continue
                if not [d for d in self.topo.dependents.get(port, []) if self.topo.cls(d) == "FiberSegment"
                        and d in self.topo.entities[self.topo.entities[d]["b"]]["depends_on"]]:
                    continue
                s = self.status[port]
                bad = s[0] == "degraded" and s[1] == port
                samples.append({"entity": port, "metrics": {
                    "us_ber": 10 ** g(-5.3, 0.2) if bad else 10 ** g(-11, 0.3),
                    "tx_bias_ma": round(g(52, 2) if bad else g(28, 0.8), 2),
                    "util_pct": round(max(0.0, g(35, 5)), 1)}})
            for ont in self.topo.descendants(olt):
                oe = self.topo.entities[ont]
                if oe["class"] == "ONT" and self.is_up(ont):
                    s = self.status[ont]
                    degraded = s[0] == "degraded" and s[2] == "optics_degraded"
                    samples.append({"entity": ont, "metrics": {
                        "rx_power_dbm": round(self.rx_power(ont, now) + g(0, 0.12), 2),
                        "temp_c": round(g(45, 1.5), 1),
                        "us_ber": 10 ** g(-5.6, 0.3) if degraded else 10 ** g(-11.5, 0.3)}})
                elif oe["class"] == "E1Circuit" and self.is_up(ont):
                    s = self.status[ont]
                    timing = s[0] == "degraded" and s[2] == "timing"
                    deg = s[0] == "degraded" and s[2] == "optics_degraded"
                    samples.append({"entity": ont, "metrics": {
                        "es": self._pois(9 if timing else 4 if deg else 0.03),
                        "ses": self._pois(2 if timing else 1 if deg else 0.01),
                        "slips": self._pois(7 if timing else 0.01)}})
            msgs.append({"producer": olt, "ts": now, "samples": samples})
        if self.is_up("CESGW-1"):
            samples = []
            for pw, e in self.topo.entities.items():
                if e["class"] != "Pseudowire" or not self.is_up(pw):
                    continue
                s = self.status[pw]
                timing = s[0] == "degraded" and s[2] == "timing"
                deg = s[0] == "degraded" and s[2] == "optics_degraded"
                samples.append({"entity": pw, "metrics": {
                    "jb_underruns": self._pois(14 if timing else 0.05),
                    "loss_pct": round(abs(g(0.9 if deg else 0.002, 0.2 if deg else 0.002)), 4)}})
            msgs.append({"producer": "CESGW-1", "ts": now, "samples": samples})
        return msgs

    def _pois(self, lam: float) -> int:
        if lam <= 0:
            return 0
        L, k, p = math.exp(-lam), 0, 1.0
        while True:
            p *= self.rng.random()
            if p <= L:
                return k
            k += 1

    def normal_samples(self, family: str, n: int) -> list[dict]:
        """Draw healthy telemetry for model training."""
        g, out = self.rng.gauss, []
        for _ in range(n):
            if family == "ONT":
                out.append({"rx_power_dbm": -17.5 - self.rng.random() * 3.5 + g(0, 0.12), "temp_c": g(45, 1.5), "us_ber": 10 ** g(-11.5, 0.3)})
            elif family == "PONPort":
                out.append({"us_ber": 10 ** g(-11, 0.3), "tx_bias_ma": g(28, 0.8), "util_pct": max(0.0, g(35, 5))})
            elif family == "E1Circuit":
                out.append({"es": self._pois(0.03), "ses": self._pois(0.01), "slips": self._pois(0.01)})
            elif family == "Pseudowire":
                out.append({"jb_underruns": self._pois(0.05), "loss_pct": abs(g(0.002, 0.002))})
            elif family == "OLT":
                out.append({"cpu_pct": g(22, 3), "temp_c": g(48, 1)})
        return out

    # ---------------------------------------------------------------- actions
    def apply_action(self, action: str, target: str) -> dict:
        """Apply a remediation action to the network. Returns what the element reported back."""
        now = time.time()
        topo = self.topo
        f = self.faults.get(target)
        if action == "pon_protection_switch":
            for eid, e in topo.entities.items():
                prot = e.get("protection")
                if prot and topo.entities[prot["working"]]["depends_on"][0] == target or (prot and eid == target):
                    standby = prot["standby"]
                    if not self.is_up(standby):
                        return {"ok": False, "message": f"standby feeder {standby} not available"}
                    topo.set_dependencies(eid, [standby])
                    return {"ok": True, "message": f"{eid} switched to standby feeder {standby}"}
            return {"ok": False, "message": "no protection group on target"}
        if action == "pon_protection_revert":
            for eid, e in topo.entities.items():
                prot = e.get("protection")
                if prot and e["depends_on"] != [prot["working"]]:
                    topo.set_dependencies(eid, [prot["working"]])
            return {"ok": True, "message": "protection group reverted to working feeder"}
        if action == "e1_timing_relock":
            if f and f.type == "timing" and not f.params.get("needs_pw_reset"):
                self.repair([target])
            return {"ok": True, "message": f"{target}: clock source re-selected (ACR), jitter buffer re-centred"}
        if action == "pw_reset":
            e1 = topo.entities[target]["depends_on"][0] if topo.cls(target) == "Pseudowire" else target
            f1 = self.faults.get(e1)
            if f1 and f1.type == "timing":
                self.repair([e1])
            return {"ok": True, "message": f"pseudowire for {e1} re-signalled"}
        if action == "pon_optics_recalibrate":
            if f and f.type == "optics_degraded":
                if f.params.get("recoverable", False):
                    self.repair([target])
                else:
                    f.params["suppressed_until"] = now + 2.5  # brief improvement, then relapse
            return {"ok": True, "message": f"{target}: laser bias re-calibrated, ONTs re-ranged"}
        if action == "pon_port_migrate":
            spare = next((p for p, e in topo.entities.items() if e["class"] == "PONPort"
                          and "spare" in e["name"] and topo.entities[p]["depends_on"] == topo.entities[target]["depends_on"]), None)
            if not spare:
                return {"ok": False, "message": "no spare PON port on this OLT"}
            for fe in [d for d in topo.dependents.get(target, []) if topo.cls(d) == "FiberSegment"]:
                topo.entities[fe]["orig_depends_on"] = list(topo.entities[fe]["depends_on"])
                topo.set_dependencies(fe, [spare])
            return {"ok": True, "message": f"ONTs migrated from {target} to {spare}"}
        if action == "ont_reboot":
            if f and f.type in ("fail",) and f.params.get("soft"):
                self.repair([target])
            return {"ok": True, "message": f"{target} rebooted via OMCI"}
        if action == "dispatch_field_cleaning":
            self.pending_jobs.append((now + 5.0, "field_fix", target))
            return {"ok": True, "message": f"technician dispatched to {target} (work order completes in ~5 s in the simulator)"}
        if action == "uplink_reroute":
            return {"ok": False, "message": "no secondary uplink provisioned for this OLT"}
        if action in ("open_ticket", "watch"):
            return {"ok": True, "message": "no network change"}
        return {"ok": False, "message": f"unknown action {action}"}

    # ------------------------------------------------------------------ noise
    def noise_event(self) -> str | None:
        r = self.rng.random()
        now = time.time()
        if r < 0.45:
            onts = [e for e, v in self.topo.entities.items() if v["class"] == "ONT" and "ENT" in v["name"]
                    and e not in self.faults and self.is_up(e)]
            if onts:
                o = self.rng.choice(onts)
                self.inject(o, "power", duration=self.rng.uniform(6, 12))
                return f"customer power loss at {o}"
        elif r < 0.75:
            e1 = self.rng.choice(["E1-301", "E1-302"])
            if e1 not in self.faults:
                self.inject(e1, "fail", duration=self.rng.uniform(3, 6))
                return f"PDH microwave fade on {e1}"
        else:
            agg = self.rng.choice(["AGG-1", "AGG-2"])
            self.extra_alarms[(agg, agg, "HIGH_CPU")] = {"until": now + self.rng.uniform(5, 10), "detail": {"cpu_pct": 91}}
            return f"control-plane CPU spike on {agg}"
        return None
