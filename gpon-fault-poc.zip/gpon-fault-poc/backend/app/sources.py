"""Southbound sources: render events in their native wire formats and deliver them with retry.

* SNMP v2c traps (OLTs)            -> dict with trap OID + varbinds (as decoded by a trap receiver)
* RFC 5424 syslog (CES GW, mux, IP) -> text line with structured data
* Event stream (BSC, NMS, SA)       -> JSON records, Kafka-style
* Telemetry (OLT PM, CES GW PM)     -> batched samples, gNMI/PM-file style

Each source owns a bounded buffer and a sender task that retries rejected submissions with
exponential backoff + full jitter. Telemetry is latest-value-wins: stale samples are dropped
instead of retried.
"""
from __future__ import annotations

import asyncio
import random
import time
from collections import deque
from datetime import datetime, timezone

ENTERPRISE_OID = "1.3.6.1.4.1.64999"
TRAP_TYPES = ["PON_LOS", "PON_PORT_FAIL", "PON_BER_SD", "PON_PROTECTION_UNAVAILABLE", "ONT_LOSi", "ONT_SDi",
              "ONT_DYING_GASP", "ONT_RX_POWER_LOW", "E1_LOS", "E1_FRAME_SLIP", "E1_AIS", "E1_ERRORED_SECONDS"]
TRAP_OID = {t: f"{ENTERPRISE_OID}.2.0.{i + 1}" for i, t in enumerate(TRAP_TYPES)}
OID_TRAP = {v: k for k, v in TRAP_OID.items()}
SEV_NUM = {"critical": 1, "major": 2, "minor": 3, "warning": 4, "info": 5, "cleared": 6}
NUM_SEV = {v: k for k, v in SEV_NUM.items()}
SYSLOG_SEV = {"critical": 2, "major": 3, "minor": 4, "warning": 4, "info": 6, "cleared": 5}


def iso(ts: float) -> str:
    return datetime.fromtimestamp(ts, tz=timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def render(ev: dict) -> tuple[str, object]:
    """Render a device-view alarm event into its source wire format."""
    src = ev["source"]
    if src == "snmp":
        return "snmp", {
            "version": "v2c", "agent": ev["reporter"], "community": "public",
            "trap_oid": TRAP_OID.get(ev["type"], f"{ENTERPRISE_OID}.2.0.99"),
            "varbinds": {
                "gponAlarmId": ev["id"], "gponAlarmEntity": ev["entity"], "gponAlarmType": ev["type"],
                "gponAlarmSeverity": SEV_NUM.get(ev["severity"], 3), "gponAlarmState": 1 if ev["state"] == "raise" else 2,
                "gponAlarmTime": iso(ev["ts"]), "gponAlarmSeq": ev["seq"],
                **{f"gponAlarmDetail.{k}": v for k, v in ev.get("detail", {}).items()},
            },
        }
    if src == "syslog":
        pri = 8 * 16 + SYSLOG_SEV.get(ev["severity"], 5)  # facility local0
        sd = (f'[alarm@64999 id="{ev["id"]}" entity="{ev["entity"]}" state="{ev["state"]}" '
              f'severity="{ev["severity"]}" seq="{ev["seq"]}"]')
        text = f'{ev["type"]} {"raised" if ev["state"] == "raise" else "cleared"} on {ev["entity"]}'
        return "syslog", f'<{pri}>1 {iso(ev["ts"])} {ev["reporter"]} fmd - {ev["type"]} {sd} {text}'
    return "stream", {
        "event_id": ev["id"], "producer": ev["reporter"], "type": ev["type"], "entity": ev["entity"],
        "state": ev["state"], "severity": ev["severity"], "event_time": iso(ev["ts"]), "seq": ev["seq"],
        "attributes": ev.get("detail", {}),
    }


class SourceClient:
    """A source's outbound buffer + sender with exponential backoff and full jitter."""

    def __init__(self, name: str, gateway, cfg: dict, jitter_s: float = 0.0, latest_value_wins: bool = False):
        self.name = name
        self.gateway = gateway
        self.cfg = cfg
        self.jitter_s = jitter_s
        self.latest_value_wins = latest_value_wins
        self.buffer: deque = deque()
        self.capacity = cfg["source_buffer"]
        self.stats = {"sent": 0, "retries": 0, "dropped_overflow": 0, "dropped_stale": 0, "max_backoff_s": 0.0}
        self.backoff_s = 0.0
        self.recent: deque = deque(maxlen=300)  # for replay drills
        self._wake = asyncio.Event()
        self.rng = random.Random(hash(name) & 0xFFFF)

    def send(self, payload, delay: float | None = None) -> None:
        due = time.time() + (self.rng.uniform(0, self.jitter_s) if delay is None else delay)
        if len(self.buffer) >= self.capacity:
            self.buffer.popleft()
            self.stats["dropped_overflow"] += 1
        self.buffer.append((due, time.time(), payload))
        self._wake.set()

    async def run(self) -> None:
        attempt = 0
        while True:
            if not self.buffer:
                self._wake.clear()
                await self._wake.wait()
                continue
            # deliver anything that is due (jitter makes delivery order differ from creation order)
            now = time.time()
            idx = next((i for i, item in enumerate(self.buffer) if item[0] <= now), None)
            if idx is None:
                await asyncio.sleep(0.02)
                continue
            due, created, payload = self.buffer[idx]
            if self.latest_value_wins and now - created > 5.0:
                del self.buffer[idx]
                self.stats["dropped_stale"] += 1
                continue
            res = self.gateway.submit(self.name, payload)
            if res["status"] == "rejected":
                attempt += 1
                self.stats["retries"] += 1
                cap = min(self.cfg["retry_cap_s"], self.cfg["retry_base_s"] * (2 ** attempt))
                self.backoff_s = self.rng.uniform(0, cap)  # full jitter
                self.stats["max_backoff_s"] = max(self.stats["max_backoff_s"], round(self.backoff_s, 2))
                await asyncio.sleep(max(self.backoff_s, res.get("retry_after", 0) * 0.5))
                continue
            attempt = 0
            self.backoff_s = 0.0
            del self.buffer[idx]
            self.stats["sent"] += 1
            self.recent.append(payload)
            if self.stats["sent"] % 200 == 0:
                await asyncio.sleep(0)

    def snapshot(self) -> dict:
        return {"name": self.name, "buffered": len(self.buffer), "backoff_s": round(self.backoff_s, 2), **self.stats}
