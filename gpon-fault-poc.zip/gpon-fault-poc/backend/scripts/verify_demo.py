"""End-to-end check of the demo scenarios and fault-tolerance drills against a running backend.

Usage:  python scripts/verify_demo.py [--base http://localhost:8000]
Exit code 0 when every check passes.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
import urllib.request

BASE = "http://localhost:8000"


def call(method: str, path: str, body: dict | None = None) -> dict:
    data = json.dumps(body or {}).encode() if method != "GET" else None
    req = urllib.request.Request(BASE + path, data=data, method=method, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.loads(r.read())


def snap() -> dict:
    return call("GET", "/api/snapshot")


def wait_for(pred, timeout: float, what: str):
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            s = snap()
            v = pred(s)
            if v:
                return v
        except Exception:  # noqa: BLE001 - backend may be failing over
            pass
        time.sleep(0.5)
    raise AssertionError(f"timeout waiting for: {what}")


def incident_for(s: dict, root: str, kinds=("reactive",)):
    for i in s["incidents"]:
        if i.get("impact") and i["impact"]["root"] == root and i["kind"] in kinds:
            return i
    return None


results = []


def check(name: str, ok: bool, detail: str = "") -> None:
    results.append((name, ok, detail))
    print(f"[{'PASS' if ok else 'FAIL'}] {name} {detail}")


def main() -> int:
    global BASE
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default=BASE)
    BASE = ap.parse_args().base
    call("POST", "/api/noise/off")
    call("POST", "/api/reset", {"full": True})
    time.sleep(3)

    # 1. cascading failure -> one incident, root cause = silent feeder fibre, awaiting approval
    call("POST", "/api/scenarios/cascade_fiber_cut")
    inc = wait_for(lambda s: (lambda i: i if i and i["phase"] in ("awaiting_approval", "escalated") else None)(incident_for(s, "F-A1")),
                   25, "cascade incident analysed")
    check("cascade: root cause is feeder fibre F-A1", inc["rca"]["hypotheses"][0]["entity"] == "F-A1",
          f'(confidence {inc["rca"]["hypotheses"][0]["confidence"]})')
    check("cascade: alarms compressed into one incident", len(inc["alarms"]) >= 10, f'({len(inc["alarms"])} alarms)')
    check("cascade: supervised action awaiting approval", inc["phase"] == "awaiting_approval", inc["phase"])
    call("POST", f'/api/incidents/{inc["id"]}/approve', {"note": "verify script"})
    done = wait_for(lambda s: next((i for i in s["incidents"] if i["id"] == inc["id"] and i["status"] == "resolved"), None), 30,
                    "cascade resolved after approval")
    check("cascade: protection switch verified and resolved", done["resolved_by"] == "operator", f'MTTR {done["metrics"].get("mttr_s")} s')

    # 2. autonomous E1 timing fix
    call("POST", "/api/scenarios/autonomous_e1_timing")
    inc = wait_for(lambda s: (lambda i: i if i and i["status"] == "resolved" else None)(incident_for(s, "E1-102")), 40,
                   "E1 timing resolved")
    check("autonomous: E1-102 resolved without a human", inc["resolved_by"] == "autonomous",
          f'MTTD {inc["metrics"].get("mttd_s")} s, MTTR {inc["metrics"].get("mttr_s")} s')

    # 3. escalation on failed verification
    call("POST", "/api/scenarios/escalation_pon_optics")
    inc = wait_for(lambda s: (lambda i: i if i and i["phase"] == "escalated" else None)(incident_for(s, "PON-B2")), 50,
                   "PON optics escalated")
    acts = inc["loop"]["actions"]
    check("escalation: autonomous action failed verification", bool(acts) and acts[0]["verification"]["status"] == "failed")
    check("escalation: escalated with proposed high-risk step", inc["loop"]["escalation"]["proposed"] == "pon_port_migrate",
          inc["loop"]["escalation"]["reason"])
    call("POST", f'/api/incidents/{inc["id"]}/resolve', {"note": "SFP replaced"})
    wait_for(lambda s: next((i for i in s["incidents"] if i["id"] == inc["id"] and i["status"] == "resolved"), None), 25,
             "escalated incident resolved by human")
    check("escalation: human field fix closes the incident", True)

    # 4. prediction
    call("POST", "/api/scenarios/predictive_rx_drift")
    inc = wait_for(lambda s: next((i for i in s["incidents"] if i["kind"] == "predictive" and i["status"] != "resolved"
                                   and i.get("impact")), None), 60, "predictive incident")
    pred = next((a for a in snap()["alarms"] if a["type"] == "PREDICTED_FAULT"), None)
    check("prediction: fault predicted before any device alarm", pred is not None,
          f'(time to threshold {pred["detail"].get("time_to_threshold_s") if pred else "?"} s)')
    call("POST", f'/api/incidents/{inc["id"]}/execute')
    wait_for(lambda s: next((i for i in s["incidents"] if i["id"] == inc["id"] and i["status"] == "resolved"), None), 40,
             "predictive incident resolved")
    check("prediction: proactive dispatch verified", True)

    # 5. fault tolerance: engine crash -> failover, no incidents lost
    before = {i["id"] for i in snap()["incidents"]}
    call("POST", "/api/drills/crash_correlation_engine")
    s = wait_for(lambda s: s if s["correlation"]["failovers"] and s["correlation"]["leader"] else None, 20, "failover")
    after = {i["id"] for i in s["incidents"]}
    check("failover: standby took over", s["correlation"]["leader"] == "corr-b", json.dumps(s["correlation"]["failovers"][-1]))
    check("failover: no incidents lost", before <= after, f"({len(before)} before, {len(after)} after)")

    # 6. duplicates / out-of-order
    call("POST", "/api/drills/duplicates_out_of_order")
    time.sleep(6)
    r = snap()["drills"]["last"]["duplicates_out_of_order"]
    check("replay: duplicates dropped", r.get("duplicates_dropped", 0) > 0, json.dumps(r))

    # 7. backpressure storm
    call("POST", "/api/drills/alarm_storm")
    r = wait_for(lambda s: s["drills"]["last"].get("alarm_storm"), 40, "storm drill result")
    check("storm: backpressure engaged", r["shed_low_priority"] + r["rejected_full"] > 0, json.dumps(r))
    check("storm: real fault alarm still delivered", r["critical_alarm_delivered"])

    # 8. AI outage -> safe mode
    call("POST", "/api/drills/ai_outage")
    call("POST", "/api/scenarios/autonomous_e1_timing")
    inc = wait_for(lambda s: (lambda i: i if i and i["status"] != "resolved" and i["phase"] not in ("detected",) else None)(
        incident_for(s, "E1-102")), 30, "safe-mode incident")
    check("safe mode: rule-based RCA and advisory ceiling", inc["rca"]["method"].startswith("rule") and inc["phase"] == "advisory",
          f'{inc["rca"]["method"]} / {inc["phase"]}')
    call("POST", "/api/drills/ai_outage")
    call("POST", f'/api/incidents/{inc["id"]}/execute')
    wait_for(lambda s: next((i for i in s["incidents"] if i["id"] == inc["id"] and i["status"] == "resolved"), None), 30,
             "safe-mode incident resolved by operator")

    # 9. device unreachable -> breaker + escalation
    call("POST", "/api/drills/device_unreachable")
    call("POST", "/api/scenarios/escalation_pon_optics")
    inc = wait_for(lambda s: (lambda i: i if i and i["phase"] == "escalated" and i["status"] != "resolved" else None)(
        incident_for(s, "PON-B2")), 60, "unreachable escalation")
    check("unreachable: action not executed, escalated", "unreachable" in inc["loop"]["escalation"]["reason"],
          inc["loop"]["escalation"]["reason"])
    call("POST", "/api/drills/device_unreachable")
    call("POST", "/api/reset", {})
    call("POST", "/api/noise/on")

    failed = [r for r in results if not r[1]]
    print(f"\n{len(results) - len(failed)}/{len(results)} checks passed")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
