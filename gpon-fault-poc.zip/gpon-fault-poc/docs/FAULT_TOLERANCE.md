# Fault tolerance

Every mode below is demonstrable from *Autonomy & resilience → Fault-tolerance drills*, and all of them are
asserted by `backend/scripts/verify_demo.py`.

## Ingestion backpressure and retry

* **Bounded queue** (600) between the gateway and the event log, drained at a fixed processing rate
  (450 events/s, deliberately low so the effect is visible).
* **Priority-aware admission**: above the high watermark (60 %), low-priority traffic (telemetry,
  minor/warning raises) is shed with `retry_after`; critical/major alarms and all clears are still admitted.
  When full, everything is rejected with `retry_after`. The HTTP endpoint maps this to **429 + Retry-After**.
* **Source-side retry**: each source keeps a bounded buffer and retries with exponential backoff and full
  jitter (base 0.15 s, cap 4 s). Telemetry is latest-value-wins: samples older than 5 s are dropped rather
  than retried, so a backlog never replays stale PM data.
* **Dead-letter queue** for malformed or unknown-entity messages; the pipeline never stops on bad input.

*Drill "Alarm storm"*: ~3,500 messages (telemetry, flapping CPU syslog, retransmitted high-priority traps)
in under a second plus a real dying-gasp fault. Typical result: peak queue ≈ 580/600, low-priority traffic
shed, a few full-queue rejections, source retries, hundreds of stale telemetry samples dropped, and the real
fault's alarm **delivered and correlated**.

## Duplicate and out-of-order events

* **Idempotency** by event id (SNMP retransmissions, replays, at-least-once redelivery) with a TTL cache.
* **Re-order buffer**: events are held for 1 s and released in device-timestamp order; anything arriving
  behind the watermark is flagged `late`.
* **Per-alarm-key reconciliation** in the correlator: an event older than the last state change for the
  same entity + alarm type is ignored, so a delayed clear can never cancel a newer raise. Repeats of an
  active alarm increment its count; a re-raise inside an open incident is recorded as a flap.

*Drill "Duplicate & out-of-order replay"*: re-sends the recent traps/syslog/events twice, shuffled, plus
stale clears timestamped 30 s before their raises. Result: every duplicate dropped, stale clears ignored,
active alarms unchanged.

## Correlation engine failover

* Two engine instances, **active/standby**. The leader processes the log by offset, heartbeats every 0.25 s
  and checkpoints its full state (alarms, incidents, loop state) with the log offset to SQLite every second.
* If the leader's heartbeat is older than 2.5 s, the standby **restores the latest checkpoint and replays
  the log** from the checkpointed offset. Idempotency and per-key reconciliation make the replay safe
  (effectively-once processing).
* While no leader exists, the closed loop pauses; results of device actions that complete during the gap
  are queued and applied to the new leader's state. The dashboard shows a failover banner.
* A crashed instance rejoins as standby after 12 s.

*Drill "Correlation engine failover"*: detection ≈ 2.5 s, restore + replay ≈ 0.3 s, no incident lost.

## AI component unavailable (safe mode)

When the AI service is down every caller falls back deterministically:

| Function | Fallback |
|---|---|
| Correlation | same subtree (topology affinity ≥ 0.5) within 60 s |
| RCA | most upstream alarmed entity |
| Playbook ranking | match specificity only |
| Telemetry anomaly / prediction | skipped (raw telemetry still stored) |
| Autonomy | capped at `safe_mode_level` (advisory) |

The header turns red, a safe-mode banner appears and every decision records "AI unavailable: safe-mode
ceiling". Restoring the AI re-enables the policy immediately.

## Downstream device unreachable

* The device adapter resolves the managing element (e.g. ONT actions go through the OLT) and executes with
  a timeout (2.5 s) and retries (2).
* A **circuit breaker** per element opens after 2 failures and stays open for 30 s (then half-open), so the
  loop stops hammering an unreachable management plane.
* A failed or blocked action changes nothing in the network; the incident is **escalated** with
  "device unreachable – safe mode, no change made" and the proposed action, ready for a human to retry.

*Drill "OLT-B management unreachable"* + the PON optics scenario shows the breaker opening and the
escalation.

## Dashboard

The dashboard keeps the last good snapshot when the API is unreachable and shows a "link lost" banner; it
never blanks the operator's view.
