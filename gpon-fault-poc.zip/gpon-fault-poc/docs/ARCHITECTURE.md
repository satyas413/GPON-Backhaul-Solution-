# Architecture

## Components and data flow

```mermaid
flowchart LR
  subgraph Network["Network (simulator.py)"]
    OLT[OLT-A / OLT-B\nSNMP traps + PM]
    CES[CES gateway / PDH mux\nsyslog]
    BSC[BSC, NMS, service assurance\nevent stream]
  end
  subgraph Ingest["Ingestion service (sources.py, ingestion.py)"]
    SRC[Source clients\nbuffer + backoff/jitter retry]
    GW[Gateway\nparse, validate, admission control]
    DD[De-dup + re-order buffer]
    LOG[(Event log\noffset addressed)]
    DLQ[(Dead-letter queue)]
  end
  subgraph Corr["Correlation service (correlation.py)"]
    A[Engine corr-a]
    B[Engine corr-b]
    CK[(Checkpoints\nSQLite)]
  end
  AI[AI service (ai.py)\nanomaly, prediction, RCA, ranking]
  CL[Closed-loop controller (closed_loop.py)\npolicy, guardrails, verify, escalate]
  DA[Device adapter\nretries, timeouts, circuit breaker]
  H[(History store\nSQLite)]
  API[FastAPI (main.py)]
  UI[React dashboard]

  OLT & CES & BSC --> SRC --> GW --> DD --> LOG
  GW -. malformed .-> DLQ
  LOG --> A
  LOG -. replay on failover .-> B
  A <--> CK
  B <--> CK
  A <--> AI
  A --> CL
  CL <--> AI
  CL --> DA --> Network
  H --> AI
  CL --> H
  API --> UI
  A & CL & GW --> API
```

1. **Simulator** holds ground truth, propagates faults along `depends_on`, and emits what each real element
   would emit: OLT SNMP traps (PON LOS, ONT LOSi/SDi, E1 slips via OMCI CES PM), CES-gateway syslog (PW down,
   E1 AIS, jitter-buffer underruns), PDH-mux syslog, BSC / NMS / service-assurance events, and PM telemetry.
   It also adds realistic noise: customer power loss (dying gasp), PDH microwave fades, CPU spikes, SNMP trap
   retransmissions and random delivery delay.
2. **Source clients** render each event in its wire format and deliver it with a bounded buffer and
   exponential backoff with full jitter when the gateway pushes back.
3. **Ingestion gateway** parses and validates (malformed input goes to the DLQ), applies admission control
   (bounded queue, high-watermark shedding of low-priority traffic, 429 + Retry-After when full), drops
   duplicates by event id, holds events in a re-order window and releases them in device-timestamp order
   into the offset-addressed **event log**.
4. **Correlation engine** (leader of an active/standby pair) consumes the log by offset: alarm lifecycle,
   stale-event reconciliation, enrichment, correlation into incidents, incident merging, and telemetry
   fan-out to the AI service. It checkpoints its full state with the log offset every second.
5. **AI service** scores telemetry for anomalies, forecasts faults, supplies co-occurrence statistics to the
   correlator, runs RCA and ranks playbooks. It can be switched off (safe mode) and every caller has a
   deterministic fallback.
6. **Closed-loop controller** drives each incident through detect → analyze → decide → act → verify, applies
   the autonomy policy and guardrails, executes through the **device adapter**, verifies against fresh
   telemetry and alarm state, and escalates to the NOC when needed.
7. **History store** (SQLite) holds 30 days of seeded history, learned statistics and checkpoints; every
   resolved live incident is appended, so the statistics keep learning.
8. **FastAPI** exposes the dashboard API, operator actions, policy changes, scenarios, drills and northbound
   ingestion; the **React dashboard** polls a single snapshot endpoint every second and shows a "link lost"
   banner, keeping the last good state, if the backend is unreachable.

## From PoC process to deployed services

For a stakeholder demo everything runs as cooperating asyncio tasks in one Python process, so it starts
with one command and no infrastructure. The boundaries are the ones you would deploy separately:

| PoC component | Production deployment | Interface used in the PoC |
|---|---|---|
| `SourceClient` + `IngestionGateway` | collectors (snmptrapd/pysnmp, rsyslog, Kafka consumers, gNMI/PM collectors) + ingestion service, horizontally scaled | `submit()` admission contract, same as `POST /api/ingest/{source}` |
| `EventLog` | Kafka / Redpanda topic partitioned by OLT | offset-addressed `read(offset, n)` |
| `CorrelationEngine` pair + supervisor | two replicas with leader election (Kubernetes lease, etcd, or Kafka consumer-group rebalance) | checkpoint + offset replay |
| `HistoryStore` | PostgreSQL / TimescaleDB | SQL |
| `AIService` | model-serving service (REST/gRPC) with its own scaling | `AIUnavailable` exception = circuit-broken remote call |
| `ClosedLoopController` + `DeviceAdapter` | orchestration service talking NETCONF/RESTCONF to OLTs, OMCI via the OLT, TL1 to PDH/CES, ticketing and workforce APIs | async `execute(action, target)` |

## Configuration

All behaviour is driven by YAML in `backend/config/`:

| File | Contents |
|---|---|
| `topology.yaml` | ontology classes and relationships + every device, link, pseudowire and service instance |
| `alarm_catalog.yaml` | normalised alarm types, category, severity, standard reference, RCA evidence weights |
| `playbooks.yaml` | remediation playbooks, steps, risk, protocol, verification KPI, follow-ups |
| `policy.yaml` | autonomy matrix and guardrails (also editable live in the UI) |
| `settings.yaml` | timings, queue sizes, watermarks, retry/backoff, failover, verification windows, model thresholds |
