# Metrics

Computed in [`runtime.py`](../backend/app/runtime.py) (`Runtime.kpis`) from the active engine's state, and
in [`history.py`](../backend/app/history.py) for the 30-day trends.

## Per incident

| Metric | Definition |
|---|---|
| **MTTD** | incident creation − fault onset. Onset is the earliest device timestamp of its alarms; in the simulator the injected fault time is used when known, so ingestion delay, the re-order window and correlation are all included |
| Time to analyze / decide / act | from incident creation to RCA, to the policy decision, to the first action |
| **MTTR** | service restoration − fault onset. Restoration is the first moment of the successful verification window, or the moment all alarms cleared after a human fix |
| Prediction lead time | device threshold alarm time − prediction time (predictive incidents) |
| Correlated alarms | raw alarms grouped into the incident (after de-duplication) |

## Live KPIs (header strip)

| KPI | Definition |
|---|---|
| MTTD (live) | mean MTTD over reactive incidents this session, with the rule-based baseline from history |
| MTTR (live) | mean MTTR over incidents remediated by automation or people (self-cleared transients excluded); autonomous MTTR shown separately |
| Alarm compression | unique raw alarms raised ÷ incidents |
| Resolved autonomously | autonomously resolved ÷ remediated incidents; plus the verification pass rate of executed actions |
| Open incidents, awaiting approval, escalations, predicted faults | counts |
| Duplicates suppressed | gateway duplicate drops + repeats of already-active alarms |

## Historical trends (Trends & KPIs)

Daily from the seeded history: MTTR, MTTD, raw alarms per ticket/incident (under the rule-based process
alarms became separate tickets at about 1.6 alarms per ticket), share resolved without a human, raw alarm
volume. The comparison table contrasts days 1–15 (rule-based), days 16–30 (AI loop) and this live session.
The seed is synthetic and labelled as such; the live session is measured, but the simulator compresses
hours of real repair work into seconds.

## Operational telemetry of the platform itself

Ingestion rate, alarm rate, queue depth, shed/rejected counts, duplicates, re-ordered and late events,
source retries and backoff, consumer lag, failovers (detection time, replayed events, restore time), AI
inference counts and latency, circuit-breaker state and DLQ contents are all shown in *Autonomy &
resilience* and in the live charts.
