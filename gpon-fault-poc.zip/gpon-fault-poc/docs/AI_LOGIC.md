# AI logic

Source: [`backend/app/ai.py`](../backend/app/ai.py), correlation scoring in
[`correlation.py`](../backend/app/correlation.py). Every AI call can raise `AIUnavailable`; each caller has a
deterministic fallback (see [Fault tolerance](FAULT_TOLERANCE.md#ai-component-unavailable--safe-mode)).

## 1. Learning from history

On start-up the history store (SQLite) is seeded with 30 days of incidents: days 1–15 under a rule-based
NOC, days 16–30 under the AI loop. From it the AI learns:

* **Root-cause priors** P(class): how often each entity class was the root cause (fibre ≈ 27 %, ONT ≈ 27 %,
  E1 ≈ 20 %, PON port ≈ 8 %, splitter ≈ 3 %, ...), Laplace-smoothed.
* **Alarm co-occurrence**: normalised pointwise mutual information (NPMI) between alarm types that appear
  in the same incident, clipped to [0, 1].
* **Playbook success rates**: Beta(1, 1)-smoothed success / (success + failure) per playbook.
* **Per-entity history** for enrichment: incidents in the last 30 days, MTBF, days since the last incident.

Every incident resolved during the demo is appended, so these statistics keep updating.

## 2. Topology- and time-aware correlation

When a new alarm arrives, the engine scores it against every open incident active in the last 180 s:

```
score = 0.6 · topology_affinity + 0.25 · exp(-Δt / 30 s) + 0.15 · NPMI(alarm type, incident alarm types)
```

* `topology_affinity` is the maximum affinity between the alarm's entity and the incident's anchor entities
  (plus its RCA root once known): 1/(1+0.1·d) along a dependency path, 0.9^(d1+d2) through a shared-risk
  ancestor (splitter, feeder, PON port). Affinity below 0.45 vetoes the join.
* Non-service-affecting warnings (e.g. CPU spikes) only join incidents on the same entity and never act as
  anchors, so a noisy CPU alarm cannot glue unrelated faults together.
* The alarm joins the best incident above 0.5; if it also scores above 0.5 for other incidents that have not
  acted yet, those are **merged** (cascades often start as several fragments).
* Otherwise a new incident opens. Its detection time is MTTD's end point.

AI-derived alarms (`AI_ANOMALY`, `PREDICTED_FAULT`) are correlated the same way, so a telemetry anomaly on a
PON port lands in the same incident as the OLT's BER alarm and becomes RCA evidence.

## 3. Root-cause analysis (Bayesian, topology-aware)

Candidates = every alarmed entity plus all of its ancestors (≈ 25–60 entities). For each candidate *c*:

```
log score(c) = log P(class(c))
             + Σ_alarms log P(alarm | c)
             + min(#healthy observable dependents of c, 8) · log 0.15
```

`P(alarm | c)`:

| Situation | Likelihood |
|---|---|
| *c* is the element **reporting** the alarm (it must be alive) | 0.05 |
| alarm is on *c* and its catalogue entry implicates class(c) | the catalogue weight, e.g. `PON_BER_SD` → PONPort 0.7 |
| *c* is a passive element ≤ 2 hops below the alarmed port and the alarm implicates its class | catalogue weight, e.g. `PON_LOS` → FiberSegment 1.0, Splitter 0.45 |
| alarm is on *c* (no specific evidence) | 0.5 |
| *c* is upstream of the alarmed entity (the alarm is a consequence) | 0.9 |
| otherwise (alarm unexplained by *c*) | 0.02 |

Evidence weights can depend on alarm attributes, e.g. `PON_LOS` with `laser_tx=ok` lowers the PON port to
0.2, and `PON_BER_SD` with `tx_bias=high` raises it to 1.0. The **healthy-dependents penalty** is the key
topology signal: OLT-A cannot be the root of a fibre cut on PON-A1 because ONTs on PON-A2 are still
reporting. Scores are normalised with a softmax into confidences, and the top six hypotheses are returned
with coverage, prior and evidence strings shown in the UI.

Worked example (fibre cut on F-A1, 14 alarms): F-A1 ≈ 89 %, PON-A1 ≈ 7 %, SPL-A1 ≈ 4 %, OLT-A ≈ 0 %.
The safe-mode rule ("most upstream alarmed entity") would pick PON-A1 and send a technician to the OLT
card instead of the fibre.

## 4. Anomaly detection

* **Telemetry**: one `IsolationForest` (120 trees) per telemetry family, trained at start-up on 3,000
  healthy samples each.
  * ONT: Rx power, temperature, log10 upstream BER
  * PON port: log10 BER, laser bias current, utilisation
  * E1: errored seconds, severely errored seconds, slips
  * Pseudowire: jitter-buffer underruns, packet loss
  * OLT: CPU, temperature
  A sample is anomalous when its score falls below the 0.15 % quantile of the training scores (minus a
  margin) for two consecutive samples. The most deviating feature (z-score against the training data) is
  reported, e.g. `PON-B2 tx_bias_ma z=+33`. Three normal samples clear it.
* **Alarm patterns**: an EWMA of the alarm arrival rate and its variance; z > 6 with more than 20 alarms/s
  flags an alarm storm (header chip). Storm periods are excluded from learning.

## 5. Fault prediction

For each ONT the last 40 Rx-power samples are fitted with a linear trend. Features (slope in dB/min,
residual noise, margin to the −27 dBm class B+ sensitivity) feed a `LogisticRegression` trained on
synthetic degrading and healthy windows. A `PREDICTED_FAULT` is raised when the slope is negative, the
time-to-threshold is inside the 240 s horizon and P(fault) > 0.6. The predictive incident records the
forecast; if the device alarm later appears, the incident records the **prediction lead time**.

## 6. Remediation ranking

Playbooks match on alarm pattern (e.g. dying gasp → transient watch), else on RCA root class and fault
category, with a wildcard NOC-investigation fallback. Type-B switchover is only offered when the root sits
in a protected ODN. Matches are ranked by `historical success rate × match specificity` and shown with the
number of similar past incidents and their median MTTR. In safe mode ranking falls back to specificity only.
