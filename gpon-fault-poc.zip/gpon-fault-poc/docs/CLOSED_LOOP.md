# Closed-loop control

Source: [`backend/app/closed_loop.py`](../backend/app/closed_loop.py). The controller runs every 0.5 s over
the incidents owned by the active correlation engine. All loop state lives inside the incident record, so it
survives an engine failover.

## Phases

```mermaid
stateDiagram-v2
  [*] --> detected: first alarm (MTTD stops)
  detected --> resolved: alarms clear during hold-down (self-cleared)
  detected --> analyzed: hold-down (3 s quiet, max 8 s)
  analyzed --> watching: transient pattern
  analyzed --> advisory: level = advisory
  analyzed --> awaiting_approval: level = supervised
  analyzed --> acting: level = autonomous, inside guardrails
  analyzed --> escalated: outside autonomy boundary / no playbook
  advisory --> acting: operator Execute
  awaiting_approval --> acting: operator Approve
  escalated --> acting: operator approves proposed step
  acting --> verifying: action executed
  acting --> escalated: device unreachable / action failed
  verifying --> resolved: service alarms clear + KPI met for the window (MTTR stops)
  verifying --> acting: verification failed, next step allowed
  verifying --> escalated: verification failed, no step left or next step out of bounds
  watching --> resolved: cleared
  watching --> escalated: persisted beyond 45 s
  escalated --> resolved: human field fix, alarms clear
```

1. **Detect**: the correlation engine opens the incident. A hold-down lets the cascade settle so RCA sees
   the whole burst.
2. **Analyze**: AI RCA (or the rule-based fallback), impact (services, cell sites, subscribers, blast
   radius), fault category, and ranked playbooks. If new alarms join before an action runs, the incident is
   re-analysed.
3. **Decide**: the policy cell `policy_class(root) × fault category` gives the configured level; guardrails
   adjust it (below).
4. **Act**: the device adapter executes the step over the element's management protocol (NETCONF for OLT
   ports and protection, OMCI via the OLT for ONT/E1 CES ports, TL1 for the CES gateway, workforce/ticketing
   APIs for field work) with retries, timeouts and a per-element circuit breaker.
5. **Verify**: for the playbook's verification window (8 s, 45 s for transient watches) the loop checks that
   every service-affecting alarm of the incident is clear **and** the playbook KPI holds on telemetry that is
   newer than the action (e.g. `slips = 0` on E1-102, `us_ber ≤ 1e-9` on a PON port, `rx_power ≥ −25 dBm` on
   an ONT). A relapse inside the window (alarms clear, then return) fails verification. MTTR is taken at the
   moment service was restored, not at the end of the window.
6. **On failure**: run the step's rollback if it has one, try the next playbook step through the same
   decision logic, or escalate.

## Autonomy levels

| Level | Behaviour |
|---|---|
| advisory | The AI recommends; a human presses **Execute** |
| supervised | The AI prepares the exact action; it runs after **Approve** |
| autonomous | The AI executes, verifies and closes, or escalates |

Configured per **device class** (OLT, ONT, ODN, G702, Aggregation, Core, Service) × **fault category**
(link_down, signal_degradation, timing_sync, equipment, configuration, performance) in
[`policy.yaml`](../backend/config/policy.yaml) and editable live in *Autonomy & resilience*.

## Guardrails (autonomy boundaries)

Applied on top of an autonomous cell:

| Guardrail | Default | Effect |
|---|---|---|
| max_risk_autonomous | medium | a riskier step (e.g. port migration = high) is **escalated** |
| max_blast_radius_autonomous | 4 services | larger incidents are **escalated** for approval |
| min_rca_confidence_autonomous | 0.6 | below it the step is **downgraded to supervised** |
| max_actions_per_device_per_hour | 4 | rate limit; beyond it the loop **escalates** |
| safe_mode_level | advisory | ceiling while the AI component is unavailable |

Escalations open a NOC ticket with the reason, the full RCA, impact and enrichment, and, where one exists,
the proposed next action, which the operator can approve from the incident drawer.

## Scenario outcomes

| Scenario | Policy cell | Path through the loop |
|---|---|---|
| Feeder fibre cut | ODN × link_down = supervised (blast radius 5 > 4 would also block autonomy) | awaiting approval → switchover → verified → resolved + field follow-up ticket |
| E1 timing slips | G702 × timing_sync = autonomous | act → verified (`slips=0`) → resolved autonomously |
| PON optics ageing | OLT × signal_degradation = autonomous | re-calibrate → **relapse, verification failed** → next step is high risk → **escalated** |
| ONT Rx drift | ONT × signal_degradation = advisory | predictive incident → operator executes dispatch → verified |
| OLT uplink failure | Aggregation × link_down = advisory | AI recommends a high-risk reroute; if the operator executes it, it fails (no secondary uplink) and the loop escalates |
| Dying gasp / PDH fade / CPU spike (noise) | transient-watch playbook | watched, auto-closed when cleared |
