# Windows: create the virtual environment (first run only) and start the backend on :8000.
Set-Location "$PSScriptRoot\backend"
if (-not (Test-Path .venv)) {
  python -m venv .venv
  .\.venv\Scripts\pip install -r requirements.txt
}
.\.venv\Scripts\uvicorn app.main:app --host 0.0.0.0 --port 8000
