# GPON · G.702 Backhaul — AI Fault & Alarm Management PoC

A runnable, clickable proof of concept for **topology-aware, closed-loop AI fault management** on a mobile
backhaul built from **GPON** (OLT → PON port → feeder fibre → splitter → drop → ONT) and **G.702 TDM**
(E1 2048 kbit/s circuits, E3 PDH multiplexing, CESoPSN pseudowires, BSC). No Docker: a Python virtual
environment for the backend and npm for the dashboard.

![Operations view](docs/screenshots/01-operations.png)

## What it shows

| Capability | Where to see it |
|---|---|
| G.702 + GPON ontology with devices, ports, passive ODN, links, pseudowires and services as first-class entities | Operations → topology (click any node or link), [`backend/config/topology.yaml`](backend/config/topology.yaml) |
| Ingestion from SNMP traps, RFC 5424 syslog, event stream and OLT / CES-gateway PM telemetry | Alarm feed "Reporter · source" column; `POST /api/ingest/{snmp,syslog,stream,telemetry}`; UDP syslog on :5514 |
| Topology + temporal + learned co-occurrence correlation into incidents | ~15 alarms from a fibre cut become one incident |
| Bayesian root-cause analysis that infers **silent passive elements** (a cut fibre never alarms) | Incident drawer → Root cause analysis |
| Impact assessment and alert enrichment (topology, device metadata, 30-day history) | Incident drawer → Impact; click an alarm row for its enrichment |
| Anomaly detection (IsolationForest), alarm-storm detection, fault prediction (trend + logistic regression) | Autonomy & resilience → AI component; the Rx-drift scenario |
| Closed loop: detect → analyze → decide → act → verify, with escalation | Closed loop tab and the stepper in each incident |
| Autonomy level per device class × fault category, plus guardrails | Autonomy & resilience → matrix (edit live) |
| Fault tolerance: backpressure/retry, de-dup, re-ordering, engine failover, AI safe mode, unreachable devices | Autonomy & resilience → drills |
| MTTD / MTTR, compression, auto-resolution, verification pass rate, trends vs a rule-based baseline | KPI strip and Trends & KPIs tab |

## Quick start

Prerequisites: **Python 3.10+** and **Node.js 18+** (tested with Python 3.13 and Node 22).

```bash
# terminal 1 - backend (creates backend/.venv on first run, then serves http://localhost:8000)
./run_backend.sh

# terminal 2 - dashboard (installs node_modules on first run, then serves http://localhost:5173)
./run_frontend.sh
```

Or `./run_all.sh` to start both. On Windows use `run_backend.ps1` and `run_frontend.ps1`.

Manual equivalent:

```bash
cd backend
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt        # Windows: .venv\Scripts\pip
.venv/bin/uvicorn app.main:app --port 8000

cd ../frontend
npm install
npm run dev                                       # open http://localhost:5173
```

Single-port option: `cd frontend && npm run build`, then restart the backend; it serves the built dashboard
at http://localhost:8000.

The first backend start seeds `backend/data/history.db` (30 days of synthetic operating history) and trains
the models in about a second. Delete that file to re-seed.

## Five-minute demo script

1. **Cascading failure.** Click *Cascading fibre cut*. Within ~4 s about 15 alarms from the OLT (SNMP),
   CES gateway (syslog), BSC and service assurance (event stream) collapse into **one incident**. The AI names
   **feeder fibre F-A1** as root cause (~89 %), even though a fibre cannot raise an alarm; a rule-based
   system would blame the PON port. Blast radius is 5 services and 2 cell sites, above the autonomy limit,
   so the Type-B protection switchover **waits for approval**. Open the incident and press *Approve*: the
   loop switches to the standby feeder, verifies the service alarms clear, resolves the incident and opens a
   field ticket for the fibre repair.
2. **Autonomous fix.** Click *E1 timing slips*. G.822 slips on E1-102 plus CES jitter-buffer underruns
   are correlated, the policy cell *G702 × timing_sync* is autonomous, the loop re-locks the E1 clock,
   checks `slips = 0` on fresh telemetry and closes the incident with no human (MTTR ≈ 7–10 s).
3. **Escalation.** Click *PON optics degradation*. The AI ranks the PON-B2 transceiver over the fibre (laser
   bias anomaly), auto-runs a re-calibration, and **verification fails** when BER relapses. The next step
   (migrate ONTs to the spare port) is high risk, which is outside the autonomy boundary, so it **escalates** to the NOC
   with the full context. Approve the migration or press *Resolve (field fix applied)*.
4. **Prediction.** Click *ONT Rx drift*. No device alarm exists yet; after ~20 s the trend model forecasts
   the receiver-sensitivity crossing and opens a **predictive incident** with an advisory to dispatch a
   cleaning crew. *Execute* it and the loop verifies Rx power recovered.
5. **Fault tolerance.** In *Autonomy & resilience* run the drills: alarm storm (watch the queue gauge, shedding
   and retries while a real alarm still gets through), duplicate/out-of-order replay, **kill the correlation
   engine** (standby takes over from the checkpoint, nothing lost), AI outage (safe mode banner, rule-based
   RCA, advisory ceiling), and OLT-B management unreachable (breaker opens, loop escalates instead of acting).

*Guided demo* runs scenarios 1–4 and the engine failover back to back. *Repair network* clears faults;
*Reset all* also clears incidents. Tick *show simulator ground truth* to see where faults were really injected.

## Verify it works

With the backend running:

```bash
cd backend && .venv/bin/python scripts/verify_demo.py
```

It drives every scenario and drill through the API and checks the outcomes (17 checks: RCA result,
compression, approval flow, autonomous resolution, failed verification + escalation, prediction, failover
with no lost incidents, de-duplication, backpressure with the real alarm delivered, safe mode, breaker).

## Project layout

```
backend/
  app/
    ontology.py      G.702 + GPON ontology, topology graph (ancestors, impact, affinity, layout)
    simulator.py     physical network: fault propagation, alarms per element, PM telemetry, action effects
    sources.py       SNMP / syslog / stream / telemetry wire formats + retrying source clients
    ingestion.py     parse, admission control (backpressure), de-dup, re-order buffer, event log, DLQ
    correlation.py   correlation engine (alarm lifecycle, enrichment, incidents) + active/standby supervisor
    enrichment.py    topology, device metadata and history context per alarm
    ai.py            anomaly detection, prediction, Bayesian RCA, playbook ranking, rule-based fallback
    closed_loop.py   autonomy policy, guardrails, device adapter + circuit breaker, detect→verify loop
    history.py       SQLite history (seeded), learned statistics, engine checkpoints
    runtime.py       wiring, background loops, scenarios, drills, KPIs
    main.py          FastAPI REST API
  config/            topology.yaml, alarm_catalog.yaml, playbooks.yaml, policy.yaml, settings.yaml
  scripts/verify_demo.py
frontend/            React 18 + Vite + Recharts dashboard
docs/                architecture, ontology, AI logic, closed loop, fault tolerance, metrics, screenshots
```

## Documentation

* [Knowledge transfer guide](docs/KNOWLEDGE_TRANSFER.md): start here if you are new; step-by-step walkthrough of the domain, the code and how to change it
* [Architecture](docs/ARCHITECTURE.md): components, data flow, how it maps to separately deployed services
* [Topology ontology](docs/TOPOLOGY_ONTOLOGY.md): G.702 + GPON entity classes, relationships and alarm catalogue
* [AI logic](docs/AI_LOGIC.md): correlation scoring, Bayesian RCA, anomaly detection, prediction, ranking
* [Closed-loop control](docs/CLOSED_LOOP.md): phases, autonomy levels, guardrails, verification, escalation
* [Fault tolerance](docs/FAULT_TOLERANCE.md): every degradation mode and how to demonstrate it
* [Metrics](docs/METRICS.md): MTTD, MTTR and the other KPIs, and how each is computed

## API (selection)

| Method & path | Purpose |
|---|---|
| `GET /api/snapshot` | everything the dashboard shows (polled every second) |
| `GET /api/topology` | ontology, entities and layout |
| `GET /api/incidents/{id}` | incident with enriched alarm records |
| `POST /api/incidents/{id}/{approve\|execute\|reject\|ack\|resolve}` | operator actions |
| `PUT /api/policy/matrix` · `PUT /api/policy/guardrails` | change autonomy live |
| `POST /api/scenarios/{name}` · `POST /api/drills/{name}` | demo scenarios and fault-tolerance drills |
| `POST /api/ingest/{snmp\|syslog\|stream\|telemetry}` | external ingestion: 202 accepted, 429 + Retry-After, 400 dead-lettered |
| `GET /api/history/trends` | 30-day daily KPIs |

Interactive API docs: http://localhost:8000/docs

## Scope and honest limits

* The network is **simulated**; device actions (NETCONF, OMCI, TL1) act on the simulator. The ingestion,
  correlation, AI and closed-loop code only sees the raw messages the simulator emits, as it would with live
  equipment.
* SNMP traps arrive as decoded trap dictionaries (what a trap receiver such as snmptrapd/pysnmp hands over),
  not raw BER over UDP. Syslog has a real UDP listener on port 5514.
* The services run as cooperating asyncio components in one process. The event log is in memory and stands
  in for a Kafka topic; checkpoints go to SQLite. [Architecture](docs/ARCHITECTURE.md) explains how each
  component maps to a separately deployed service.
* The 30-day history is synthetic seed data, clearly labelled in the UI, used to train priors, co-occurrence
  statistics and playbook success rates.
