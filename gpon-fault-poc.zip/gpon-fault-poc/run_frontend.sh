#!/usr/bin/env bash
# Install the dashboard dependencies (first run only) and start the Vite dev server on :5173.
set -euo pipefail
cd "$(dirname "$0")/frontend"
[ -d node_modules ] || npm install
exec npm run dev -- --host 0.0.0.0
