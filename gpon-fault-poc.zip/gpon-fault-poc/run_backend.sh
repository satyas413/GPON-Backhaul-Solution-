#!/usr/bin/env bash
# Create the Python virtual environment (first run only) and start the FastAPI backend on :8000.
set -euo pipefail
cd "$(dirname "$0")/backend"
PY=${PYTHON:-python3}
if [ ! -d .venv ]; then
  "$PY" -m venv .venv
  .venv/bin/pip install --upgrade pip >/dev/null
  .venv/bin/pip install -r requirements.txt
fi
exec .venv/bin/uvicorn app.main:app --host 0.0.0.0 --port "${PORT:-8000}"
