# Windows: install dashboard dependencies (first run only) and start Vite on :5173.
Set-Location "$PSScriptRoot\frontend"
if (-not (Test-Path node_modules)) { npm install }
npm run dev -- --host 0.0.0.0
